"""Generic K actor version of accepted mask-projected real LiDAR GN11 priors."""
import os
os.environ['CUDA_VISIBLE_DEVICES']=''
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
from pathlib import Path
import json,sys,hashlib
import numpy as np
from PIL import Image
from scipy.spatial import cKDTree
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'infra'))
from data import _actual_body_from_selection
from waymo_numpy_cpu import save_ply
sid=sys.argv[1];scene=ROOT/'inputs'/sid;selection=ROOT/'reviewed_selections'/(sid+'.json')
reject_unreliable='--reject-unreliable-frame-priors' in sys.argv[2:]
sel=json.loads(selection.read_text());prep=json.loads((scene/'preparation_manifest.json').read_text());actors=sel['actors'];k=len(actors)
assert sel['status']=='visually_reviewed' and sel['GT_boxes_used_to_create_masks'] is False
assert all([r['frame_id'] for r in a['frames']]==[r['id'] for r in prep['frames']] for a in actors)
for p in ('dynamic_image/dynamic_image_0','dynamic_masks/dynamic_mask_0','dynamic_actor_assets'):
    assert not (scene/p).exists();(scene/p).mkdir(parents=True)
clouds=[[] for _ in actors];times=[[] for _ in actors];source=[{} for _ in actors];reports=[]
for i,a in enumerate(actors):
    (scene/f'dynamic_actor_assets/actor_{i}/body_masks').mkdir(parents=True)
    reports.append({'actor_index':i,'raw_track_id':a['raw_track_id'],'description':a['description'],'frames':[]})
for fi,row in enumerate(prep['frames']):
    fid=row['id'];rgb=np.array(Image.open(scene/'image/image_0'/f'{fid}.png').convert('RGB'));labels=np.array(Image.open(scene/'mask/mask_0/Annotations'/f'{fid}.png'))
    lidar=np.fromfile(scene/'velodyne'/f'{fid}.bin',np.float32).reshape(-1,6);xyz=lidar[:,:3].astype(np.float64);hom=np.c_[xyz,np.ones(len(xyz))]
    pose=np.loadtxt(scene/'pose'/f'{fid}.txt');cal={s.split(':',1)[0]:np.fromstring(s.split(':',1)[1],sep=' ') for s in (scene/'calib'/f'{fid}.txt').read_text().splitlines() if ':' in s}
    cam=hom@cal['Tr_velo_to_cam_0'].reshape(3,4).T;positive=np.flatnonzero(np.isfinite(cam).all(1)&(cam[:,2]>.01))
    uvw=np.c_[cam[positive],np.ones(len(positive))]@cal['P0'].reshape(3,4).T;uv=np.floor(uvw[:,:2]/uvw[:,2:3]+.5).astype(np.int64)
    h,w=labels.shape;inside=(uv[:,0]>=0)&(uv[:,0]<w)&(uv[:,1]>=0)&(uv[:,1]<h);idx=positive[inside];uv=uv[inside];depth=cam[idx,2]
    bins=(uv[:,1]//2)*((w+1)//2)+uv[:,0]//2;nearest=np.full(((h+1)//2)*((w+1)//2),np.inf);np.minimum.at(nearest,bins,depth)
    union=np.zeros((h,w),bool)
    ann=json.loads((scene/'annotations'/f'{fid}.json').read_text())
    for i,a in enumerate(actors):
        body=_actual_body_from_selection(scene,fid,labels,a['frames'][fi]);assert not (union&body).any();union|=body
        hit=body[uv[:,1],uv[:,0]];retained=idx[hit&(depth<=nearest[bins]+.5)];before=len(retained);rejection=None;dominant_fraction=None
        if before:
            edges=cKDTree(xyz[retained]).query_pairs(.5,output_type='ndarray');graph=coo_matrix((np.ones(len(edges),np.uint8),(edges[:,0],edges[:,1])),shape=(before,before))
            _,component=connected_components(graph,directed=False);counts=np.bincount(component);dominant=component==counts.argmax()
            dominant_fraction=float(dominant.mean())
            if dominant.sum()<before*.5:
                if not reject_unreliable:raise AssertionError(f'No dominant body component {fid} actor{i}')
                rejection='entire_frame_prior_rejected_no_dominant_component_under_unchanged0.5m_rule'
                retained=retained[:0]
            else:retained=retained[dominant]
        world=(hom[retained]@pose.T)[:,:3].astype(np.float32);clouds[i].append(world);times[i].append(np.full(len(world),row['model_time'],np.float32));source[i][fid]=retained.astype(np.int32)
        gt=next(x for x in ann['laser_labels'] if x['id']==a['raw_track_id']);b=gt['box'];center=(pose@np.array([b['center_x'],b['center_y'],b['center_z'],1]))[:3]
        bound=np.linalg.norm([b['length'],b['width'],b['height']])/2+2
        distance=np.linalg.norm(world.astype(float)-center,axis=1)
        rejected_max_distance=None
        if len(distance) and distance.max()>bound:
            if not reject_unreliable:raise AssertionError(f'Wrong real point geometry {fid} actor{i}')
            rejected_max_distance=float(distance.max());rejection='entire_frame_prior_rejected_failed_unchanged_physical_geometry_QA'
            # Reject the entire unreliable observation, never retain only
            # GT-box-inside points or invent a seed. RGB/mask/pose stay present.
            retained=retained[:0];world=world[:0];distance=distance[:0]
            clouds[i][-1]=world;times[i][-1]=times[i][-1][:0];source[i][fid]=retained.astype(np.int32)
        Image.fromarray(body.astype(np.uint8)*255).save(scene/f'dynamic_actor_assets/actor_{i}/body_masks'/f'{fid}.png')
        reports[i]['frames'].append({'frame_id':fid,'pixels':int(body.sum()),'projected_points':int(hit.sum()),'visible_before_component':before,'retained_real_points':len(world),
           'whole_frame_prior_rejection':rejection,'dominant_fraction':dominant_fraction,'rejected_frame_component_max_distance_m':rejected_max_distance,
           'diagnostic_max_distance_to_raw_center_m':float(distance.max()) if len(distance) else None,'diagnostic_bound_m':float(bound)})
    Image.fromarray(union.astype(np.uint8)*255).save(scene/'dynamic_masks/dynamic_mask_0'/f'{fid}.png')
    dynamic=np.zeros_like(rgb);dynamic[union]=rgb[union];Image.fromarray(dynamic).save(scene/'dynamic_image/dynamic_image_0'/f'{fid}.png')
    assert np.array_equal(np.array(Image.open(scene/'dynamic_image/dynamic_image_0'/f'{fid}.png')),dynamic)
for i in range(k):
    xyz=np.concatenate(clouds[i]);ts=np.concatenate(times[i]);assert len(xyz)>0
    save_ply(scene/f'points3d_dynamic_{i}.ply',xyz,ts);np.savez_compressed(scene/f'dynamic_actor_assets/actor_{i}/source_lidar_indices.npz',**source[i]);reports[i]['total_real_points']=len(xyz)
result={'status':'PASS_GENERIC_REAL_K_ACTOR_PRIORS','scene':str(scene),'actors':reports,'frames':49,'GPU_used':False,'selection':str(selection),
    'selection_sha256':hashlib.sha256(selection.read_bytes()).hexdigest(),'geometry':'same accepted2x2px nearest depth.5m then.5m dominant component; exact real sensor subset; GT boxes diagnostic only',
    'GT_boxes_used_to_filter_individual_points':False,'GT_geometry_QA_may_reject_entire_observation':reject_unreliable,
    'whole_frame_prior_rejection_policy': 'reject unreliable observation as a whole, preserve49RGB/masks/GTposes; no change to nearest-depth/component/QA thresholds' if reject_unreliable else None,
    'all_vertex_sources_saved':True,'dynamic_RGB_and_union_exact':True,'old_assets_modified':False}
(scene/'dynamic_multi_actor_preparation.json').write_text(json.dumps(result,indent=2));(scene/'dynamic_multi_actor_validation.json').write_text(json.dumps(result,indent=2))
print(json.dumps({'scene':sid,'actor_count':k,'real_points':[r['total_real_points'] for r in reports]}))
