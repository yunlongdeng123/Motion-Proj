"""Resume each reviewed 3k pilot to total30k, restore/audit, export deletion pairs, package small assets."""
from pathlib import Path
import os,json,subprocess,time,shutil,tarfile,io,hashlib
ROOT=Path(__file__).resolve().parent
PY='/root/autodl-tmp/envs/drivingeditor/bin/python'
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
def state(s,**kw):
    p=ROOT/'rigid_full_status.json.partial';p.write_text(json.dumps({'state':s,'pid':os.getpid(),'unix_time':time.time(),**kw},indent=2),encoding='utf-8')
    p.replace(ROOT/'rigid_full_status.json')
def stage(sid,name,cmd):
    state('running',scene=sid,stage=name,command=cmd)
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONOPTIMIZE='0',CUDA_VISIBLE_DEVICES='0',
      OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4',MKL_NUM_THREADS='4',
      TORCH_HOME='/root/autodl-tmp/drivingeditor_repro/cache/torch',PYTORCH_CUDA_ALLOC_CONF='expandable_segments:True')
    env['PATH']='/root/autodl-tmp/envs/drivingeditor/bin:/usr/local/cuda-11.8/bin:'+env.get('PATH','')
    env['LD_LIBRARY_PATH']='/usr/local/cuda-11.8/lib64:/root/autodl-tmp/envs/drivingeditor/lib:'+env.get('LD_LIBRARY_PATH','')
    with (ROOT/(sid+'_full_'+name+'.log')).open('x') as log:
        p=subprocess.run(['nice','-n','10',PY,'-B','-u',*cmd],env=env,stdout=log,stderr=subprocess.STDOUT)
    if p.returncode:raise RuntimeError(sid+' '+name+' failed; inspect preserved assets, no automatic zero restart')
try:
    gate=read(ROOT/'rigid_pilot_gate.json')
    assert gate['engineering_admission_passed'] is True and gate['actual_panels_viewed']==16
    assert gate['human_quality_verdict'] is None and gate['final_quality_accepted'] is False
    assert not (ROOT/'rigid_post30k').exists(),'Preserve prior outputs'
    assert shutil.disk_usage(ROOT).free>25*1024**3,'Insufficient headroom; preserve assets, do not delete old experiments'
    for sid in ('scene0017_079_127','scene0008_089_137'):
        specpath=ROOT/'rigid_specs'/(sid+'.json');spec=read(specpath)
        run=ROOT/'rigid_runs'/sid;full=run/'full30k';post=ROOT/'rigid_post30k'/sid
        assert not full.exists()
        assert read(run/'pilot_3000/status.json')=={'state':'complete','step':3000,'training_reconstruction_only':True,'edit_visual_acceptance':'pending','restoration_verified':False}
        assert read(run/'restore_pilot/receipt.json')['runtime_restoration_verified']
        stage(sid,'train',[str(ROOT/'infra/train.py'),'--spec',str(specpath),'--output',str(full),
          '--resume',str(run/'pilot_3000/checkpoint_003000.pt'),'--iterations','30000','--seed','0','--joint-background','--run'])
        s=read(full/'status.json');assert s['state']=='complete' and s['step']==30000,'Priority yield is not completion'
        assert read(full/'resume_policy_contract.json')['first_step']==3001
        assert read(full/'runtime_restore_contract.json')['runtime_restoration_verified']
        post.mkdir(parents=True)
        for step in (10000,20000,30000):
            stage(sid,'restore_%06d'%step,[str(ROOT/'infra/check_full_restore.py'),'--spec',str(specpath),
              '--checkpoint',str(full/('checkpoint_%06d.pt'%step)),'--expected-step',str(step),
              '--output',str(run/('restore_%06d'%step))])
        common=['--spec',str(specpath),'--checkpoint',str(full/'checkpoint_030000.pt'),'--expected-step','30000']
        anchor='0017098' if sid.startswith('scene0017') else '0008101'
        stage(sid,'evaluate',[str(ROOT/'infra/evaluate_scene.py'),*common,'--fixed-camera-frame',anchor,'--output',str(post/'evaluation'),'--run'])
        selection=read(ROOT/'reviewed_selections'/(sid+'.json'))
        for k,a in enumerate(selection['actors']):
            stage(sid,'actor%d_delete'%k,[str(ROOT/'infra/render_edits.py'),*common,'--track',a['raw_track_id'],
              '--operation','delete','--output',str(post/'edits'/('actor%d_delete'%k)),'--run'])
        stage(sid,'CPU_delete_audit',[str(ROOT/'audit_deletions.py'),'--scene',sid])
        evidence=post/'evidence';evidence.mkdir()
        for p in (specpath,ROOT/'rigid_pilot_gate.json',ROOT/'rigid_runtime_preparation.json',
                  full/'effective_config.json',full/'resume_policy_contract.json',full/'runtime_restore_contract.json',
                  full/'memory_summary.json',ROOT/'rigid_prepared'/sid/'preparation_report.json'):
            shutil.copy2(p,evidence/p.name)
        for step in (3000,10000,20000,30000):
            p=run/('restore_pilot' if step==3000 else 'restore_%06d'%step)/'receipt.json'
            shutil.copy2(p,evidence/('restore_%06d.json'%step))
        assert read(post/'deletion_audit.json')['engineering_contract']['verified_FP32_pairs']==len(selection['actors'])*49
    state('packaging')
    postroot=ROOT/'rigid_post30k';seen={};copies={};files=[]
    for p in sorted(postroot.rglob('*')):
        if not p.is_file() or p.suffix not in ('.png','.json') or 'input_sidecar' in p.parts:continue
        rel=p.relative_to(postroot).as_posix()
        if p.suffix=='.png':
            data=p.read_bytes();h=hashlib.sha256(data).hexdigest()
            if h in seen and data==(postroot/seen[h]).read_bytes():copies[rel]=seen[h];continue
            seen[h]=rel
        files.append(p)
    package=ROOT/'nearby_actors30k_PNG_metadata.tar.gz';assert not package.exists()
    with tarfile.open(package,'w:gz',compresslevel=1) as tar:
        for p in files:tar.add(p,arcname=p.relative_to(postroot).as_posix())
        data=json.dumps({'copies':copies,'basis':'byte-identical PNGs; no image edits'},indent=2).encode()
        info=tarfile.TarInfo('exact_copies.json');info.size=len(data);tar.addfile(info,io.BytesIO(data))
    state('complete_awaiting_local_visual_review_and_HTML',package=str(package),package_bytes=package.stat().st_size,
      package_sha256=hashlib.sha256(package.read_bytes()).hexdigest(),observed_frames=98,fixed_frames=98,
      delete_pairs=245,final_quality_accepted=False,human_quality_verdict=None,
      shutdown_performed=False,next_step='Download light assets, actually inspect all49 frames per scene, publish unified HTML; only then consider authorized shutdown')
except BaseException as e:
    state('failed',error=repr(e),assets_preserved=True,automatic_restarts=False,shutdown_performed=False)
    raise
