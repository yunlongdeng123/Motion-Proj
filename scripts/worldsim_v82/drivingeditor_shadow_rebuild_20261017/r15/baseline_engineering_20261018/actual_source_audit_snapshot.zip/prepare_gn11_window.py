"""Actual CPU reader/mask/SGCM binding plus frozen same-GN11 single-window preparation."""
import os
os.environ['CUDA_VISIBLE_DEVICES']='';os.environ['PYTHONDONTWRITEBYTECODE']='1'
for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[k]='1'
from pathlib import Path
import sys,json,importlib.util,hashlib,random
import numpy as np
ROOT=Path(__file__).resolve().parent;BASE=Path('/root/autodl-tmp/drivingeditor_repro');OLD=BASE/'campaign/followup_scene_prep_20261013';TOOLS=OLD/'tools/followup'
sid=sys.argv[1];scene=ROOT/'inputs'/sid;dest=ROOT/'metadata'/sid;dest.mkdir(parents=True,exist_ok=False)
sys.path.insert(0,str(OLD/'tools'))
loader_spec=importlib.util.spec_from_file_location('old_CPU_helper',OLD/'tools/prepare_scene0008_cpu.py');helper=importlib.util.module_from_spec(loader_spec);loader_spec.loader.exec_module(helper)
reference=json.loads((BASE/'campaign/hybrid30k_20261012/configs/GN11.json').read_text());config=dict(reference)
prep=json.loads((scene/'preparation_manifest.json').read_text());lo,hi=prep['raw_training_range'];ids=[r['id'] for r in prep['frames']]
config.update(source_path=str(scene),model_path=str(ROOT/'runs'/f'{sid}_hybrid_30000_seed0_GN11'),start_frame=lo,end_frame=hi)
cpu=dict(config,data_device='cpu',sgcm_guard_enabled=False)
source=OLD/'frozen_repository';torch,loader,sgcm,graphics,masks,helpers=helper.import_cpu_reader(source)
from omegaconf import OmegaConf
random.seed(0);np.random.seed(0);info=loader.readWaymoInfo_add(OmegaConf.create(cpu))
assert not torch.cuda.is_initialized() and len(info.train_cameras)==49 and len(info.test_cameras)==0
assert [c.image_name for c in info.train_cameras]==ids
assert np.allclose([c.timestamp for c in info.train_cameras],[r['model_time'] for r in prep['frames']],rtol=0,atol=1e-12)
transform=np.loadtxt(scene/'transform_matrix.txt');actual_scale=sgcm.validate_similarity(transform)
assert np.isfinite(actual_scale) and actual_scale>0
views,mask_rows=helper.cpu_views(info,scene,torch,graphics,masks,helpers)
control=sgcm.create_sgcm_controller(str(scene),OmegaConf.create(cpu));assert not torch.cuda.is_initialized()
priors=sorted(scene.glob('points3d_dynamic_*.ply'));assert len(priors)==len(prep['selected_real_track_ids'])
spec={'scene_id':sid,'source_path':str(scene),'frame_ids':ids,'frame_count':49,'camera':'FRONT','raw_frame_range':[lo,hi],
  'resolution_scale':4,'original_WH':[1920,1280],'render_WH':[480,320],'fixed_pose_anchor':ids[10],'fixed_pose_camera_index':10,
  'model_timestamp_values':[float(c.timestamp) for c in info.train_cameras],'actor_PLY_paths':[str(p) for p in priors],
  'selected_genuine_raw_track_ids':prep['selected_real_track_ids'],'screenshot_anchor_raw':prep['screenshot_anchor_raw']}
ready={'status':'PASS_CPU_PREPARATION_TRAINING_GATED','gpu_used':False,'cuda_initialized':False,'training_started':False,'training_ready':False,
  'scene_copy':str(scene),'train_cameras':49,'test_cameras':0,'fixed_pose_anchor':ids[10],
  'static_points_after_exact0p1m_exclusion':len(info.static_point_cloud.points),'dynamic_points':len(info.dynamic_point_cloud.points),
  'canonical_full_mask_validation':mask_rows,'transform_matrix':transform.tolist(),'actual_meter_to_model_scale':float(actual_scale),'SGCM_geometry':control.metadata,
  'SGCM_view_inputs':{'count':49,'ids':[Path(v['id']).stem for v in views]},'training_guard_enabled_in_candidate_config':True,'cpu_geometry_guard_enabled':False,
  'human_quality_verdict':None,'new_window_visual_quality_accepted':False,'evaluation_scope':'49observedtrain; noheldout'}
def write(p,v):
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x') as f:json.dump(v,f,indent=2)
write(dest/'scene_spec.json',spec);write(dest/'CPU_readiness.json',ready);write(dest/'reference_GN11.json',reference)
sys.path.insert(0,str(TOOLS))
from contracts import scene_spec,build_config,readiness_contract,gate_contract
from prepare_followup import prepare
canonical=scene_spec(spec);readiness_contract(ready,canonical);cfg=build_config(reference,canonical,ROOT)
paths={'campaign_root':str(ROOT),'source_repository':str(source),'matrix_tools_dir':str(BASE/'campaign/hybrid30k_20261012/tools'),
   'scene_spec':str(dest/'scene_spec.json'),'readiness_file':str(dest/'CPU_readiness.json'),'reference_config':str(dest/'reference_GN11.json')}
receipt=prepare(paths,cfg,canonical,ready['status'])
old_gate=OLD/'metadata/GN11_gate_passed.json';gatepath=ROOT/'metadata/GN11_reference_acceptance_authorization.json'
if not gatepath.exists():
    gate=json.loads(old_gate.read_text());gate['allowed_scene_ids']=['scene0017_079_127','scene0008_089_137']
    gate['extension_authorization']={'source':'current human request, same scenes screenshot-nearby windows; latest ranges restricted to all49 genuine tracks',
      'reference_acceptance_only':True,'new_window_quality_passed':False,'new_window_human_verdict':None,
      'inherited_gate_path':str(old_gate),'inherited_gate_sha256':hashlib.sha256(old_gate.read_bytes()).hexdigest()}
    write(gatepath,gate)
gate_evidence=gate_contract(gatepath,canonical,reference,True)
write(dest/'inherited_GN11_gate_recheck.json',gate_evidence)
print(json.dumps({'scene':sid,'state':receipt['status'],'actual_CPU_cameras':49,'dynamic_seed_points':len(info.dynamic_point_cloud.points),'SGCM':control.metadata['status'],'new_window_quality_accepted':False}))
