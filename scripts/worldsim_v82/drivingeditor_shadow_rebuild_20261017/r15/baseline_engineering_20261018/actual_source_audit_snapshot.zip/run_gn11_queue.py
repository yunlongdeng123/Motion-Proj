"""Run only two explicitly bound new-window GN11 baselines; preserve all failures/assets."""
from pathlib import Path
import json,os,subprocess,time
ROOT=Path(__file__).resolve().parent;BASE=Path('/root/autodl-tmp/drivingeditor_repro');PY='/root/autodl-tmp/envs/drivingeditor/bin/python'
RUNNER=BASE/'campaign/followup_scene_prep_20261013/tools/followup/run_scene_gn11.py'
def state(s,**kw):
    p=ROOT/'GN11_queue_status.json.partial';p.write_text(json.dumps({'state':s,'pid':os.getpid(),'unix_time':time.time(),**kw},indent=2));p.replace(ROOT/'GN11_queue_status.json')
try:
    for sid in ('scene0017_079_127','scene0008_089_137'):
        m=ROOT/'metadata'/sid;out=ROOT/'runs'/f'{sid}_hybrid_30000_seed0_GN11'
        assert not out.exists(),'Preserve prior training; do not silently restart'
        cmd=[PY,'-B','-u',str(RUNNER),'--run','--verify-paired-steps','--scene-spec',str(m/'scene_spec.json'),
          '--readiness-file',str(m/'CPU_readiness.json'),'--reference-config',str(m/'reference_GN11.json'),
          '--source-repository',str(BASE/'campaign/followup_scene_prep_20261013/frozen_repository'),
          '--matrix-tools-dir',str(BASE/'campaign/hybrid30k_20261012/tools'),'--campaign-root',str(ROOT),
          '--gate-file',str(ROOT/'metadata/GN11_reference_acceptance_authorization.json')]
        state('running',scene=sid,command=cmd)
        env=dict(os.environ,CUDA_VISIBLE_DEVICES='0',PYTHONDONTWRITEBYTECODE='1',PYTHONOPTIMIZE='0',OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4',MKL_NUM_THREADS='4',
           PYTORCH_CUDA_ALLOC_CONF='expandable_segments:True',TORCH_HOME=str(BASE/'cache/torch'))
        env['PATH']='/root/autodl-tmp/envs/drivingeditor/bin:/usr/local/cuda-11.8/bin:'+env.get('PATH','')
        env['LD_LIBRARY_PATH']='/usr/local/cuda-11.8/lib64:/root/autodl-tmp/envs/drivingeditor/lib:'+env.get('LD_LIBRARY_PATH','')
        with (ROOT/(sid+'_GN11.log')).open('x') as log:p=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
        if p.returncode:raise RuntimeError(sid+' GN11 worker failed; preserve and diagnose, no automatic zero restart')
        actual=json.loads((out/'status.json').read_text());assert actual['status']=='complete' and actual['iteration']==30000
    state('both_GN11_30k_complete',next_stage='rigid3k pilot with actual complete GN11 prior, then reviewed resume to total30k')
except BaseException as exc:state('failed',error=repr(exc),automatic_restarts=False,assets_preserved=True);raise
