"""CPU only: bind the two newly authorized 49-frame windows to genuine GT rigid actors."""
import os
os.environ['CUDA_VISIBLE_DEVICES']=''
os.environ['PROTOCOL_BUFFERS_PYTHON_IMPLEMENTATION']='python'
for key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[key]='1'
from pathlib import Path
import sys,json
import numpy as np
ROOT=Path(__file__).resolve().parent
sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT/'infra'))
from data import prepare_scene
WINDOWS={'scene0017_079_127':(79,127,2),'scene0008_089_137':(89,137,3)}
sid=sys.argv[1]
lo,hi,count=WINDOWS[sid]
scene=ROOT/'inputs'/sid
selection=ROOT/'reviewed_selections'/(sid+'.json')
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
manifest=read(scene/'preparation_manifest.json')
selected=read(selection)
ids=[a['raw_track_id'] for a in selected['actors']]
assert len(ids)==count and len(set(ids))==count
assert selected['status']=='visually_reviewed'
assert [r['source_index'] for r in manifest['frames']]==list(range(lo,hi+1))
assert len(manifest['frames'])==49 and manifest['model_frame_interval']==.02
assert manifest['selected_real_track_ids']==ids
result=prepare_scene(scene,ROOT/'rigid_prepared'/sid,annotations=scene/'annotations',
    normalization_path=scene/'transform_matrix.txt',selection_path=selection,
    instance_ids=ids,padding_m=0,scale_prior_m=.02,strict_existing_scene=False)
with np.load(ROOT/'rigid_prepared'/sid/'instances.npz',allow_pickle=False) as b:
    assert b['valid'].shape==(49,count) and b['valid'].all()
    assert b['mask_known'].all() and b['instance_ids'].tolist()==ids
    assert b['frame_ids'].tolist()==[r['id'] for r in manifest['frames']]
    assert np.allclose(b['normalization'],np.loadtxt(scene/'transform_matrix.txt'),rtol=0,atol=1e-12)
    per_actor=[int((b['point_ids']==i).sum()) for i in range(count)]
    assert min(per_actor)>0
result['authorized_new_window_binding']={'raw_range':[lo,hi],'frame_count':49,'all_GT_poses_valid':True,
    'selected_raw_track_ids':ids,'real_rigid_LiDAR_points_per_actor':per_actor,
    'method':'inherited rigid GT OBB real LiDAR initialization; not the mask-derived GN11 prior',
    'strict_historical_window_registry_bypassed_only_for_explicitly_asserted_authorized_new_windows':True,
    'background_seed_box_filtered_asset_is_not_used_to_delete_any_trained_background_Gaussian':True}
p=ROOT/'rigid_prepared'/sid/'preparation_report.json'
p.write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps({k:result[k] for k in ('instance_count','real_instance_points','world_scale','source_raw_window','full_mask_supervision_ready','authorized_new_window_binding')}))
