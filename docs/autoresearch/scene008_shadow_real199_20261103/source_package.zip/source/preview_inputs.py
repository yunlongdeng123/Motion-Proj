"""Evidence preview only, not a predicted edit or a quality result."""
import sys,json
from pathlib import Path
import numpy as np
from PIL import Image,ImageDraw
RUN=Path(__file__).resolve().parent.parent

def main():
    d=np.load(RUN/'inputs_final/views_current/105.npz');rgb=d['observed'].copy();valid=d['valid'];route=d['route']
    panels=[]
    def panel(array,label):
        canvas=Image.new('RGB',(480,354),'#131b26')
        canvas.paste(Image.fromarray(np.uint8(np.round(np.clip(array,0,1)*255))),(0,34))
        ImageDraw.Draw(canvas).text((10,10),label,fill='white');return canvas
    panels.append(panel(rgb,'raw105 observed RGB (not deletion GT)'))
    reference=rgb.copy();reference[valid]=d['reference'][valid]
    panels.append(panel(reference,'Full199 road reference on qualified cells'))
    coverage=rgb.copy();coverage[valid]=.55*coverage[valid]+.45*np.array([1.,.65,.05])
    coverage[route]=.45*rgb[route]+.55*np.array([.05,1.,.5])
    panels.append(panel(coverage,'GREEN repair interior / AMBER qualified edge'))
    mask=d['shadow_proxy'];shadow=rgb.copy()
    shadow[mask&d['domain_a5']]=[1.,.2,.2];shadow[mask&d['domain_a37']]=[.7,.15,1.]
    panels.append(panel(shadow,'Shadow proxy: a5 red / a37 purple (overlap possible)'))
    out=Image.new('RGB',(960,708))
    for k,p in enumerate(panels):out.paste(p,((k%2)*480,(k//2)*354))
    out.save(RUN/'input_evidence_raw105.png')
    print('Saved input_evidence_raw105.png; optimizer updates=0')

if __name__=='__main__':main()
