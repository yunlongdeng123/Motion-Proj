"""Record CPU readiness only after exact source/input/weight dry-run checks."""
import datetime,json,subprocess,sys
from pathlib import Path
RUN=Path(__file__).resolve().parent.parent

def main():
    assert not (RUN/'execution_ledger.json').exists(),'Training ledger exists; cannot assert zero updates'
    with (RUN/'cpu_dryrun.log').open('x') as log:
        subprocess.run([sys.executable,str(RUN/'source/run_experiment.py')],stdout=log,stderr=subprocess.STDOUT,check=True)
    import road_runtime
    import imageio_ffmpeg
    import torch
    ffmpeg=imageio_ffmpeg.get_ffmpeg_exe()
    subprocess.run([ffmpeg,'-version'],capture_output=True,check=True)
    geometry=json.loads((RUN/'surface_geometry_check.json').read_text())
    views=json.loads((RUN/'inputs_final/view_summary_current.json').read_text())
    receipt=dict(status='CPU_READY_WAITING_FOR_USER_GPU',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        four_B_weights_SHA256_verified=True,all_199_sensor_frames_verified=True,
        all_49_views_verified=True,engine_and_source_hashes_verified=True,actor_bindings_verified=True,
        analytic_geometry_check=geometry,runtime_import_passed=True,ffmpeg_verified=ffmpeg,
        cuda_available=bool(torch.cuda.is_available()),GPU_smoke_executed=False,optimizer_updates=0,
        waiting_daemon_started=False,training_started=False,shutdown_performed=False,
        primary_shadow_proxy_pixels={alias:sum(r['actors'][alias]['shadow_proxy'] for r in views['rows']) for alias in ['5','37']},
        next_action='After user opens GPU, run source/run_experiment.py --execute')
    (RUN/'cpu_ready_receipt.json').write_text(json.dumps(receipt,indent=2))
    print(json.dumps(receipt,indent=2))

if __name__=='__main__':main()
