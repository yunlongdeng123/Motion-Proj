"""Start the authorized queue detached from SSH, with concrete launch receipt."""
import datetime,json,os,subprocess,sys
from pathlib import Path
RUN=Path(__file__).resolve().parent.parent

def main():
    receipt=RUN/'launch_direct.json'
    assert not receipt.exists() and not (RUN/'execution_ledger.json').exists()
    cmd=[sys.executable,str(RUN/'source/run_experiment.py'),'--execute']
    with (RUN/'controller_direct.log').open('x') as log:
        process=subprocess.Popen(cmd,cwd=RUN,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    result=dict(pid=process.pid,command=cmd,launched_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        formal_updates=1000,smoke_updates=0,restore_replay_updates=0)
    receipt.write_text(json.dumps(result,indent=2));print(json.dumps(result))

if __name__=='__main__':main()
