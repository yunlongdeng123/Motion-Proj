"""Explicit GPU entry point; never waits for, starts, or shuts down a GPU host."""
import argparse,fcntl,hashlib,json,os,subprocess,sys,threading,time
from pathlib import Path
RUN=Path(__file__).resolve().parent.parent
SOURCE=Path(__file__).resolve().parent

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda:f.read(8*1024*1024),b''):h.update(chunk)
    return h.hexdigest()

def write(path,data):
    Path(path).write_text(json.dumps(data,indent=2,allow_nan=False),encoding='utf-8')

def compare_restore(a,b,out):
    import numpy as np
    import torch
    left=torch.load(a,map_location='cpu',weights_only=False);right=torch.load(b,map_location='cpu',weights_only=False)
    assert left['step']==right['step']==1001
    values={k:float((v-right['road'][k]).abs().max()) for k,v in left['road'].items() if v.dtype!=torch.bool}
    def tensors(x,y,prefix=''):
        results={}
        if torch.is_tensor(x):results[prefix]=float((x-y).abs().max()) if x.numel() else 0.
        elif isinstance(x,dict):
            assert x.keys()==y.keys()
            for k in x:results.update(tensors(x[k],y[k],prefix+'/'+str(k)))
        elif isinstance(x,(list,tuple)):
            assert len(x)==len(y)
            for k,(i,j) in enumerate(zip(x,y)):results.update(tensors(i,j,prefix+'/'+str(k)))
        elif isinstance(x,(int,float,str,type(None))):assert x==y,(prefix,x,y)
        return results
    optimizer=tensors(left['optimizer'],right['optimizer'])
    maxabs=max(list(values.values())+list(optimizer.values())+[0.])
    result=dict(step=1001,road_parameter_maxabs=values,optimizer_maxabs=max(optimizer.values(),default=0.),
        sampler_exact=torch.equal(left['sampler'],right['sampler']),torch_rng_exact=torch.equal(left['torch_rng'],right['torch_rng']),
        cuda_rng_exact=all(torch.equal(i,j) for i,j in zip(left['cuda_rng'],right['cuda_rng'])),
        numpy_rng_exact=np.array_equal(left['numpy_rng'][1],right['numpy_rng'][1]),
        python_rng_exact=left['python_rng']==right['python_rng'],
        strict_bitwise_equal=maxabs==0.,next_update_tolerance=1e-6,next_update_maxabs=maxabs)
    write(out,result)
    assert maxabs<=1e-6 and all(result[k] for k in ['sampler_exact','torch_rng_exact','cuda_rng_exact','numpy_rng_exact','python_rng_exact']),result

def main():
    p=argparse.ArgumentParser();p.add_argument('--execute',action='store_true',help='Run only after GPU is opened')
    p.add_argument('--continue-run',action='store_true',help='Continue only completed phases; partial phases are preserved for exact manual resume')
    args=p.parse_args();contract=json.loads((RUN/'contract.json').read_text())
    pre=json.loads((RUN/'inputs/preflight.json').read_text())
    assert len(list((RUN/'inputs_final/views_current').glob('*.npz')))==49
    assert sha(RUN/'inputs_final/road_reference_199.npz')==contract['reference_sha256']
    assert sha(contract['actor_preparation_path'])==contract['actor_preparation_sha256']
    assert all(sha(RUN/'inputs_final/views_current'/('%03d.npz'%int(k)))==v for k,v in contract['input_view_sha256'].items())
    assert all(sha(SOURCE/k)==v for k,v in contract['source_sha256'].items()),'Source changed since contract'
    assert all(sha(k)==v for k,v in contract['engine_sha256'].items()),'B engine changed since contract'
    # Read all four source weights, not just their filenames or timestamps.
    for row in pre['checkpoint'].values():assert sha(row['path'])==row['sha256'],row['path']
    if not args.execute:
        print(json.dumps(dict(status='CPU_READY_GPU_NOT_STARTED',contract=contract),indent=2));return
    import torch
    assert torch.cuda.is_available(),'Open the GPU before --execute'
    active=subprocess.run(['nvidia-smi','--query-compute-apps=pid,process_name,used_gpu_memory','--format=csv,noheader'],capture_output=True,text=True,check=True).stdout.strip()
    assert not active,'Existing GPU compute process: '+active
    lock=(RUN/'execution.lock').open('a+');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    ledger_path=RUN/'execution_ledger.json';ledger=json.loads(ledger_path.read_text()) if ledger_path.exists() else []
    if ledger and not args.continue_run:raise RuntimeError('Preserve previous run; inspect ledger before --continue-run')
    done={r['name'] for r in ledger if r.get('exit_code')==0}
    stopped=threading.Event();peak=[0]
    def memory_watch():
        with (RUN/'gpu_memory_samples.jsonl').open('a') as stream:
            while not stopped.is_set():
                result=subprocess.run(['nvidia-smi','--query-gpu=uuid,name,memory.total,memory.used,utilization.gpu','--format=csv,noheader,nounits'],text=True,capture_output=True)
                stream.write(json.dumps(dict(time=time.time(),query=result.stdout.strip(),exit_code=result.returncode))+'\n');stream.flush()
                if result.returncode==0:
                    try:peak[0]=max(peak[0],int(result.stdout.split(',')[3]))
                    except (ValueError,IndexError):pass
                stopped.wait(1.)
    watcher=threading.Thread(target=memory_watch,daemon=True);watcher.start()
    def phase(name,arguments,updates):
        if name in done:return
        dest=RUN/name
        if dest.exists():raise RuntimeError('Partial phase retained at '+str(dest)+'; use exact checkpoint resume, do not overwrite')
        dest.mkdir();start=time.time()
        command=[sys.executable,str(SOURCE/'road_runtime.py')]+arguments+['--output',str(dest)]
        with (dest/'console.log').open('x') as log:
            process=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
        ledger.append(dict(name=name,command=command,exit_code=process.returncode,seconds=time.time()-start,
            planned_updates=updates,account='formal' if name=='formal' else 'evaluation'))
        write(ledger_path,ledger)
        if process.returncode:raise RuntimeError(name+' failed; inspect '+str(dest/'console.log'))
    try:
        # User explicitly waived smoke for this bounded 1000-update experiment.
        # Initial/final renders retain paired native B baselines at zero updates.
        assert contract['smoke_training_updates']==0 and contract['restore_replay_updates']==0
        phase('formal',['train','--steps',str(contract['formal_updates'])],contract['formal_updates'])
        phase('final_evaluation',['evaluate','--checkpoint',str(RUN/('formal/checkpoint%06d.pth'%contract['formal_updates']))],0)
        metrics=json.loads((RUN/'final_evaluation/all49/metrics.json').read_text())['aggregates']
        improvement={alias:metrics[alias]['shadow_MAE']['sample_weighted_mean'] is not None and
            metrics[alias]['shadow_MAE']['sample_weighted_mean']<metrics[alias]['baseline_shadow_MAE']['sample_weighted_mean'] for alias in ['5','37']}
        # Native 10Hz, identical camera/frame on both sides, all 49 frames.
        frames=RUN/'final_evaluation/all49'
        import imageio_ffmpeg
        subprocess.run([imageio_ffmpeg.get_ffmpeg_exe(),'-hide_banner','-loglevel','error','-n','-framerate','10','-start_number','89',
            '-i',str(frames/'%03d_baseline_delete5.png'),'-framerate','10','-start_number','89',
            '-i',str(frames/'%03d_repaired_delete5.png'),'-filter_complex','hstack=inputs=2','-frames:v','49',
            '-c:v','libx264','-pix_fmt','yuv420p',str(RUN/'delete5_before_after49.mp4')],check=True)
        for row in pre['checkpoint'].values():assert sha(row['path'])==row['sha256']
        write(RUN/'completion.json',dict(GPU_phases_complete=True,parent_SHA256_unchanged=True,
            formal_updates=contract['formal_updates'],smoke_training_updates=0,restore_replay_updates=0,
            both_actor_shadow_MAE_improved=all(improvement.values()),actor_shadow_MAE_improved=improvement,
            quality_accepted=False,needs_local_retrieval_and_visual_review=True,shutdown_performed=False))
    finally:
        stopped.set();watcher.join(timeout=5)
        write(RUN/'gpu_memory_peak.json',dict(NVML_peak_MiB=peak[0],sample_file='gpu_memory_samples.jsonl'))

if __name__=='__main__':main()
