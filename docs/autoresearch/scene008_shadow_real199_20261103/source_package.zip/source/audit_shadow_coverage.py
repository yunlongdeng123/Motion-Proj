"""Count fixed shadow-proxy samples covered by repair authority before GPU."""
import json
from pathlib import Path
import numpy as np
RUN=Path(__file__).resolve().parent.parent

def main():
    rows=[]
    for raw in range(89,138):
        d=np.load(RUN/'inputs_final/views_current'/('%03d.npz'%raw));actors={}
        for alias in ['5','37']:
            shadow=d['shadow_proxy']&d['domain_a'+alias]
            actors[alias]=dict(qualified_shadow_pixels=int(shadow.sum()),routed_shadow_pixels=int((shadow&d['route']).sum()))
        rows.append(dict(raw=raw,actors=actors))
    totals={alias:{k:sum(row['actors'][alias][k] for row in rows) for k in ['qualified_shadow_pixels','routed_shadow_pixels']} for alias in ['5','37']}
    (RUN/'target_shadow_coverage.json').write_text(json.dumps(dict(rows=rows,totals=totals,
        input_only=True,all_199_build_inputs=True,optimizer_updates=0,coverage_is_not_repair_success=True),indent=2))
    print(json.dumps(dict(totals=totals,raw105=next(r for r in rows if r['raw']==105)),indent=2))

if __name__=='__main__':main()
