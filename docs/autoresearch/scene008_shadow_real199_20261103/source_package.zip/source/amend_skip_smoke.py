"""Apply the user's explicit 1k-only instruction; preserve the prior seal."""
import datetime,hashlib,json,shutil
from pathlib import Path
RUN=Path(__file__).resolve().parent.parent

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main():
    p=RUN/'contract.json';previous=RUN/'contract.before_user_skip_smoke_20261103.json'
    assert not previous.exists() and not (RUN/'execution_ledger.json').exists()
    shutil.copy2(p,previous);c=json.loads(p.read_text())
    assert c['formal_updates']==1000 and c['smoke_training_updates']==1001
    c['status']='AUTHORIZED_DIRECT_FORMAL_1000'
    c['smoke_training_updates']=0;c['restore_replay_updates']=0
    c['formal_initialization']='fresh addon; smoke waived by latest explicit user instruction'
    c['execution_amendment']=dict(time_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        source='latest explicit user request',user_instruction='GPU开好了，开始跑吧。应该不用smoke了，总共才1k步。',
        previous_contract_sha256=sha(previous),previous_contract_file=previous.name,
        total_planned_optimizer_updates=1000,smoke_and_restore_training_updates=0,
        method_data_LR_seed_formal_budget_unchanged=True)
    c['source_sha256']['run_experiment.py']=sha(RUN/'source/run_experiment.py')
    c['acceptance']['smoke_finite_loss_gradients']='waived; formal loop checks finite loss/gradients'
    c['acceptance']['resume_loaded_exact']='zero-update checkpoint reload during final evaluation'
    c['acceptance']['resume_next_step_maxabs']='not run; user total budget is 1000'
    p.write_text(json.dumps(c,indent=2,ensure_ascii=False),encoding='utf-8')
    print(json.dumps(dict(formal_updates=1000,smoke_updates=0,restore_updates=0,previous_seal_preserved=True)))

if __name__=='__main__':main()
