"""Fixed 49-frame evaluation masks from the full-199 measured road surface."""
import os
os.environ['CUDA_VISIBLE_DEVICES']=''
for key in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS']:
    os.environ[key]='1'
import sys,json,time
from pathlib import Path
import numpy as np
from PIL import Image
from scipy.ndimage import binary_dilation
sys.path.insert(0,'/root/autodl-tmp')
from fullclip_road_cpu_20261026 import loadmeta
from repair_surface import FixedSurface

ROOT=Path('/root/autodl-tmp/drivingeditor_repro/campaign')
FULL=ROOT/'r15_gn11_fullclip_cpu_20261026'
DENSE=ROOT/'r15_gn11_stage1_v41_20261023_dense_r7/frames'

def linear(x):return np.where(x<=.04045,x/12.92,((x+.055)/1.055)**2.4)

def main():
    out=Path(sys.argv[1]); dest=out/'views_current';dest.mkdir(exist_ok=True)
    a=dict(np.load(Path(__file__).resolve().parent.parent/'inputs/expanded/evidence.npz'));ref=dict(np.load(out/'road_reference_199.npz'))
    m,anchor,inv,plane=loadmeta()
    surface=FixedSurface(m,dict(keys=a['keys'],world=a['world_xyz'],surface_supported=a['surface_supported'],
        provenance=ref['active'].astype(np.uint8),base_weight=a['source_valid'],normal_world=a['normal_world'],cell_m=a['cell_m']))
    rows=[]; started=time.time()
    for raw in range(89,138):
        path=dest/('%03d.npz'%raw)
        if path.exists():
            rows.append(json.loads(path.with_suffix('.json').read_text()));continue
        f=np.load(FULL/'frames'/('%03d.npz'%raw)); d=np.load(DENSE/('0008%03d.npz'%raw))
        r=surface.camera(f['K'],f['w2l']@inv)
        uid=r['unit_id'].reshape(320,480);safe=np.maximum(uid,0)
        supported=r['supported'].reshape(320,480)&(uid>=0)
        reference=ref['reference_srgb'][safe]; reference_linear=ref['reference_linear'][safe]
        # Five selected labels are 1..5. Sixth body mask is all other vehicles.
        other=binary_dilation(d['vehicle_body'][5]|d['vehicle_edge'][5],iterations=2)
        observed=np.asarray(Image.open(FULL/'rgb'/('%03d.png'%raw)),np.float32)/255.
        obslinear=linear(observed);luma=obslinear@np.array([.2126,.7152,.0722])
        refluma=reference_linear@np.array([.2126,.7152,.0722])
        chroma=np.std(np.log(np.maximum(obslinear/np.maximum(reference_linear,.015),.02)),axis=2)
        route=supported&ref['route_interior'][safe]&~other
        valid=supported&ref['active'][safe]&~other
        # This is a diagnostic proxy: frame guard excludes observed car bodies.
        shadow=valid&~f['guard']&(luma<.70*np.maximum(refluma,.01))&(chroma<.55)
        def current_domain(alias):
            box=m['frames']['0008%03d'%raw]['selected_boxes_model'][m['actors'].index(alias)]
            local=(ref['model_xyz']-np.asarray(box['center']))@np.asarray(box['axes'])/m['meter_to_model']
            gap=np.maximum(np.abs(local[:,:2])-np.asarray(box['half'])[:2]/m['meter_to_model'],0)
            domain=np.linalg.norm(gap,axis=1)<=2.
            return supported&domain[safe]
        domain5=current_domain(5)
        domain37=current_domain(37)
        # Exclude strong road-marking edges from shadow attribution.
        edge=np.zeros((320,480),bool)
        edge[:,1:]|=np.abs(np.diff(refluma,axis=1))>.07
        edge[1:]|=np.abs(np.diff(refluma,axis=0))>.07
        shadow&=~binary_dilation(edge,iterations=1)
        np.savez_compressed(path,unit_id=uid,depth_m=r['depth'].reshape(320,480),
            route=route,valid=valid,reference=reference,reference_linear=reference_linear,
            domain_a5=domain5,domain_a37=domain37,shadow_proxy=shadow,
            other_vehicle_guard=other,actor_labels=d['actor_labels'],observed=observed)
        row=dict(raw=raw,valid=int(valid.sum()),route=int(route.sum()),
            actors={str(alias):dict(domain=int(domain.sum()),qualified=int((valid&domain).sum()),
                route=int((route&domain).sum()),shadow_proxy=int((shadow&domain).sum()))
                for alias,domain in [(5,domain5),(37,domain37)]})
        path.with_suffix('.json').write_text(json.dumps(row,indent=2));rows.append(row)
        print(json.dumps(row),flush=True)
    summary=dict(frames=len(rows),range=[89,137],rows=rows,seconds=time.time()-started,
        proxy_not_independent_gt=True,all_199_are_build_inputs=True,
        outside_domain_preservation_required=True,optimizer_updates=0,gpu_used=False)
    (out/'view_summary_current.json').write_text(json.dumps(summary,indent=2))

if __name__=='__main__':main()
