"""Zero-update audit of the two requested under-car residual regions."""
import json
from pathlib import Path
import numpy as np
import torch
from road_runtime import Experiment,RUN,write,linear
from editor_common import cpu,road_kwargs,raster,save

@torch.no_grad()
def main():
    e=Experiment();ck=torch.load(RUN/'formal/checkpoint001000.pth',map_location='cuda',weights_only=False)
    assert ck['step']==1000 and ck['contract']==e.contract;e.road.load_state_dict(ck['road'])
    dest=RUN/'target_visibility_audit';dest.mkdir(exist_ok=False);rows=[]
    for raw in [101,105,137]:
        d=e.view(raw);c=e.camera(raw);o=e.render(raw)
        road=raster(c,e.n.args,0,road_kwargs(c,e.road,e.n.args,precomputed_color=True),e.n.bg)
        actual=cpu(o['contribution'][0]);alpha=cpu(road['alpha'][0]);areas={}
        for alias,box in [('5',(20,240,150,315)),('37',(205,265,325,320))]:
            x0,y0,x1,y1=box;roi=np.zeros((320,480),bool);roi[y0:y1,x0:x1]=True
            mask=roi&d['route'];proxy=d['shadow_proxy']&d['domain_a'+alias]
            def stats(m):
                return dict(pixels=int(m.sum()),standalone_alpha_mean=float(alpha[m].mean()) if m.any() else None,
                    actual_road_contribution_mean=float(actual[m].mean()) if m.any() else None,
                    actual_contribution_lt005=int((actual[m]<.05).sum()),
                    standalone_alpha_ge05_but_actual_lt005=int(((alpha[m]>=.5)&(actual[m]<.05)).sum()))
            areas[alias]=dict(fixed_image_box=list(box),repair_interior=stats(mask),qualified_shadow_proxy=stats(proxy),
                routed_shadow_proxy=stats(proxy&d['route']))
        points={}
        for x,y in [(90,255),(255,300),(260,290)]:
            points['%d,%d'%(x,y)]=dict(route=bool(d['route'][y,x]),reference_valid=bool(d['valid'][y,x]),
                standalone_road_alpha=float(alpha[y,x]),actual_road_alpha_T=float(actual[y,x]),
                repaired_rgb=cpu(o['rgb'][:,y,x]).tolist(),native_deleted_rgb=cpu(o['base'][:,y,x]).tolist())
        save(dest/('%03d_standalone_road.png'%raw),road['rgb']);save(dest/('%03d_actual_road_alpha_T.png'%raw),o['contribution'].expand(3,-1,-1))
        rows.append(dict(raw=raw,areas=areas,points=points))
    write(dest/'audit.json',dict(updates=0,rows=rows,parent_unchanged=e.unchanged(),
        physical_shadow_ground_truth=False,fixed_regions_are_diagnostic_only=True,
        interpretation='High standalone alpha with low joint alpha*T demonstrates compositor occlusion; it does not identify semantic ownership or true shadow geometry.',
        cuda_peak_allocated=torch.cuda.max_memory_allocated(),cuda_peak_reserved=torch.cuda.max_memory_reserved()))
    print(json.dumps(rows,indent=2))

if __name__=='__main__':main()
