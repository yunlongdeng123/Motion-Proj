"""Build an independent 49-frame review and an evidence-bounded result report."""
import hashlib,html,json,tarfile,zipfile
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'outputs/shadow_a5_a37_199_20261103'
RUN=OUT/'run'
STAGE=Path(__file__).resolve().parent

def font(size):return ImageFont.truetype('C:/Windows/Fonts/msyh.ttc',size)

def panels():
    frames=RUN/'final_evaluation/all49';initial=RUN/'formal/initial'
    names=[('原 B · 删五车',frames/'105_baseline_delete5.png'),('道路初始化 · 0步',initial/'105_repaired_delete5.png'),('道路修复 · 1000步',frames/'105_repaired_delete5.png')]
    canvas=Image.new('RGB',(1440,366),'#132235');d=ImageDraw.Draw(canvas)
    for i,(title,path) in enumerate(names):
        canvas.paste(Image.open(path),(i*480,46));d.text((i*480+14,10),title,font=font(20),fill='white')
    canvas.save(OUT/'raw105_comparison.png')
    crop=Image.new('RGB',(1260,590),'#132235');draw=ImageDraw.Draw(crop)
    for row,(alias,box) in enumerate([('a5',(20,240,150,315)),('a37',(205,265,325,320))]):
        for col,(title,path) in enumerate(names):
            image=Image.open(path).crop(box);image=image.resize((image.width*3,image.height*3),Image.Resampling.NEAREST)
            x=col*420;y=row*295
            draw.text((x+10,y+10),alias+' · '+title,font=font(18),fill='white');crop.paste(image,(x+10,y+50))
    crop.save(OUT/'raw105_target_crops.png')

def main():
    bundle=RUN/'result_bundle_20261103.tar.gz'
    digest=hashlib.sha256(bundle.read_bytes()).hexdigest()
    assert digest=='a308f700cdfb4b869374493dd43abd960bc7b1aef33c7f48256e3dc76123e4a4'
    with tarfile.open(bundle) as tar:
        for member in tar.getmembers():
            assert (RUN/member.name).resolve().is_relative_to(RUN.resolve())
            assert not member.issym() and not member.islnk()
        tar.extractall(RUN,filter='data')
    summary=json.loads((OUT/'result_summary.json').read_text());metrics=json.loads((RUN/'final_evaluation/all49/metrics.json').read_text())
    audit=json.loads((RUN/'target_visibility_audit/audit.json').read_text())
    assert len(metrics['rows'])==49
    assert all((RUN/'final_evaluation/all49'/('%03d_%s_delete5.png'%(raw,mode))).exists() for raw in range(89,138) for mode in ['baseline','repaired'])
    panels()
    rows=''
    for alias in ['5','37']:
        a=summary['actors'][alias]
        rows+=f"<tr><td>a{alias}</td><td>{a['shadow_MAE_before']:.5f}</td><td>{a['shadow_MAE_after']:.5f}</td><td>{a['shadow_MAE_relative_reduction']:.1%}</td><td>{a['shadow_valid_frames']}/49 · {a['shadow_samples']:,} 像素样本</td><td>{a['road_MAE_before']:.5f} → {a['road_MAE_after']:.5f}</td></tr>"
    worst=''.join(f"<tr><td>a{alias}</td><td>raw{summary['actors'][alias]['worst_shadow_raw']}</td><td>{summary['actors'][alias]['worst_shadow_MAE']:.5f}</td><td>{summary['actors'][alias]['shadow_improved_frames']} / {summary['actors'][alias]['shadow_valid_frames']}</td><td>{summary['actors'][alias]['dark_residual_before']:.1%} → {summary['actors'][alias]['dark_residual_after']:.1%}</td></tr>" for alias in ['5','37'])
    frame_data=json.dumps(metrics['rows'],ensure_ascii=False)
    page='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>scene-008 · a5/a37 道路修复 1k 结果</title>
    <style>body{margin:0;background:#edf2f6;color:#1e3448;font:16px/1.7 "Microsoft YaHei",sans-serif}main{max-width:1180px;margin:auto;padding:24px}section{background:#fff;border-radius:12px;padding:22px;margin:18px 0}h1{font-size:28px}h2{font-size:21px}img,video{max-width:100%;border-radius:8px}.notice{padding:16px;background:#fff0d5;border-left:5px solid #dd9723}table{width:100%;border-collapse:collapse;font-size:14px}th,td{text-align:left;padding:9px;border-bottom:1px solid #d9e2ea}.grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}figure{margin:0}figcaption,.small{font-size:14px;color:#526b80}button{padding:7px 14px;border:1px solid #a6bacc;background:#f3f8fc;border-radius:6px;cursor:pointer}.controls{display:flex;gap:9px;align-items:center;flex-wrap:wrap}input{width:100%}code{font-size:12px;overflow-wrap:anywhere}a{color:#1762ac}pre{white-space:pre-wrap;background:#edf3f7;padding:12px}@media(max-width:650px){.grid{grid-template-columns:1fr}main{padding:12px}section{padding:15px}}</style>
    <main><h1>scene-008 · a5 / a37 道路修复 1k</h1><p>2026-11-03 · v41 B 30k · 全199帧道路证据 · 删五车</p>
    <p class="notice"><b>1,000 步已完成，smoke / 恢复重放均为 0。</b>有效参考域的误差下降，两处大块残影仍然可见；本轮不能认定已完成去影。人工 verdict 保持空，quality_accepted=false。</p>
    <section><h2>同一 raw105：原 B、0步初始化与1k</h2><img src="raw105_comparison.png" alt="同一帧三状态对照"><img src="raw105_target_crops.png" alt="a5与a37关注区域三状态放大"><p class="small">三列均删同样五车，使用同一相机与时刻。放大框是用户关注区域的诊断窗口，未当作真实阴影分割标签。残留黑块可能包含原静态车形外观。</p></section>
    <section><h2>固定参考域的量化结果</h2><table><tr><th>对象</th><th>阴影 MAE · 原 B</th><th>阴影 MAE · 1k</th><th>下降</th><th>有效分母</th><th>道路 MAE · 原 B → 1k</th></tr>TABLE_ROWS</table>
    <p>口径：合格阴影代理域、线性RGB、逐像素加权。a5只有18帧有有效阴影参考，空域不算0；a37为49帧。全部199帧都参与BUILD，49帧也参与相机采样，不能宣称未见帧泛化。该域不覆盖所有肉眼可见残影。</p>
    <table><tr><th>对象</th><th>最差帧</th><th>最差阴影 MAE</th><th>改善帧 / 有效帧</th><th>暗残留比例*</th></tr>WORST_ROWS</table>
    <p class="small">* 合格阴影域内，相对参考平均线性RGB暗差超过0.06的像素比例。帧等权阴影MAE：a5 0.07348 → 0.04527；a37 0.06776 → 0.03910。<a href="result_summary.json">汇总原值</a> · <a href="run/final_evaluation/all49/metrics.json">完整逐帧原值</a></p></section>
    <section><h2>完整49帧同步查看</h2><div class="controls"><button id="prev">←</button><button id="play">播放</button><button id="next">→</button><button data-raw="96">a5最差 raw96</button><button data-raw="105">关注 raw105</button><button data-raw="137">a37最差 raw137</button><b id="frame-label"></b></div><input id="timeline" type="range" min="0" max="48" value="16"><div class="grid"><figure><figcaption>原 B · 删五车</figcaption><img id="before" alt="原B删五车"></figure><figure><figcaption>道路修复1k · 删五车</figcaption><img id="after" alt="道路修复1k删五车"></figure></div><p id="frame-metric" class="small"></p>
    <video controls preload="metadata" src="run/delete5_before_after49.mp4"></video><p class="small">视频左侧原 B，右侧1k，同步49帧、原生10Hz。</p></section>
    <section><h2>两类限制已被直接观察到</h2><p><b>部分关键像素没有进入修复输出。</b>raw105 的 (90,255) 有合格参考，但被边界路由排除，最终RGB逐值等于原 B；(255,300) 没有合格参考且独立道路alpha为0，也返回原 B。训练道路颜色无法改变这些被排除的像素。</p>
    <p><b>已启用道路也受到原静态表达遮挡。</b>raw105 的 a37 关注窗口内，1,565个修复内部像素的道路独立alpha均值0.922，联合渲染实际道路贡献均值只有0.283；其中300像素独立alpha≥0.5、联合贡献&lt;0.05。这证明合成可见性仍受限，不能据此给旧高斯赋予车辆或道路的归属真值。</p>
    <p>因此，本轮证据支持“恢复参考与稳定时间分支能改善一部分道路”，也显示资格路由、未知区域和原静态遮挡仍限制目标残影消除。没有追加训练或扩大方法。<a href="run/target_visibility_audit/audit.json">三锚零更新贡献审计</a></p></section>
    <section><h2>时间约束与执行验收</h2><img src="architecture.svg" alt="原B当前时间与独立稳定道路修复组件图"><p>固定 raw105 相机，切换到 raw89/105/137 的时间：道路修复分支最大RGB差均为0；原静态全图相对首时刻的MAE为0 / 0.03307 / 0.04006。因此整条原静态分支没有冻结到某一帧。修复域外与当前时刻原 B 的最大误差为0。</p>
    <p>正式训练 TRAIN_SECONDS 秒，日志恰好1,000条更新；保存的Adam步数均为1,000。无smoke、无恢复重放；三个锚帧从保存checkpoint独立进程重载后的PNG逐字节一致。原 B 四份权重校验保持不变。主运行NVML显存峰值 NVML_GIB GiB，训练CUDA分配器峰值 ALLOC_GIB GiB / 保留 RESERVED_GIB GiB。</p>
    <p><a href="run/final_evaluation/temporal_audit.json">时间核验</a> · <a href="run/execution_ledger.json">实际执行账</a> · <a href="run/formal/loss_from0.jsonl">1000步loss</a> · <a href="run/formal/checkpoint001000.pth">道路修复checkpoint</a> · <a href="run/completion.json">主运行收据</a></p></section>
    <section><h2>复查与恢复</h2><p><a href="experiment_plan.html">实验单与原始输入覆盖</a> · <a href="contract.json">当前合同</a> · <a href="contract.before_user_skip_smoke_20261103.json">取消smoke前合同</a> · <a href="source_package.zip">入口源码</a> · <a href="run/result_bundle_20261103.tar.gz">完整新实验快照（约239MiB）</a></p>
    <p>快照包含新道路参考、全部49帧资格图、checkpoint、逐帧结果、代码与日志。回放仍依赖原 B30k 四份权重和原V3坐标bundle，远端原件保持保留。</p><pre>/root/autodl-tmp/drivingeditor_repro/campaign/shadow_a5_a37_199_20261103</pre>
    <p class="small">failure_ledger_refs=[V82-F01,V82-F06]；failure_ledger_delta=none。独立阴影层未加入；没有纠正或重新训练原 B 的对象归属。</p></section></main>
    <script id="frame-data" type="application/json">FRAME_DATA</script><script>
    const rows=JSON.parse(document.getElementById('frame-data').textContent), $=id=>document.getElementById(id);let i=16,timer=null;
    const fmt=x=>x===null?'无有效参考':x.toFixed(5);
    function stop(){if(timer)clearInterval(timer);timer=null;$('play').textContent='播放'}
    function draw(){const r=rows[i],raw=String(r.raw).padStart(3,'0');$('timeline').value=i;$('frame-label').textContent=`raw${r.raw} · ${i+1}/49`;$('before').src=`run/final_evaluation/all49/${raw}_baseline_delete5.png`;$('after').src=`run/final_evaluation/all49/${raw}_repaired_delete5.png`;$('frame-metric').textContent=['5','37'].map(a=>`a${a} 阴影MAE ${fmt(r.actors[a].baseline_shadow_MAE)} → ${fmt(r.actors[a].shadow_MAE)}`).join('；')}
    $('prev').onclick=()=>{stop();i=Math.max(0,i-1);draw()};$('next').onclick=()=>{stop();i=Math.min(48,i+1);draw()};$('timeline').oninput=e=>{stop();i=+e.target.value;draw()};document.querySelectorAll('[data-raw]').forEach(b=>b.onclick=()=>{stop();i=+b.dataset.raw-89;draw()});$('play').onclick=()=>{if(timer){stop();return}if(i===48)i=0;$('play').textContent='暂停';draw();timer=setInterval(()=>{if(i===48){stop();return}i++;draw()},100)};draw();
    </script></html>'''
    page=page.replace('TABLE_ROWS',rows).replace('WORST_ROWS',worst).replace('FRAME_DATA',frame_data)
    page=page.replace('TRAIN_SECONDS',f"{summary['training_seconds']:.1f}").replace('NVML_GIB',f"{summary['NVML_peak_MiB']/1024:.2f}")
    page=page.replace('ALLOC_GIB',f"{summary['training_CUDA_peak_allocated']/2**30:.2f}").replace('RESERVED_GIB',f"{summary['training_CUDA_peak_reserved']/2**30:.2f}")
    (OUT/'result_report.html').write_text(page,encoding='utf-8')
    # Package all current entry and audit helpers without changing sealed training code.
    with zipfile.ZipFile(OUT/'source_package.zip','w',zipfile.ZIP_DEFLATED) as z:
        for path in STAGE.glob('*.py'):z.write(path,'source/'+path.name)
        z.write(OUT/'contract.json','contract.json')
    (OUT/'local_retrieval_receipt.json').write_text(json.dumps(dict(bundle_bytes=bundle.stat().st_size,
        bundle_sha256=digest,remote_archive_sha256_matched=True,frame_pairs_verified=49,
        checkpoint_present=(RUN/'formal/checkpoint001000.pth').exists(),source_and_reference_arrays_preserved=True),indent=2))
    print('Built',OUT/'result_report.html')

if __name__=='__main__':main()
