"""Read-only inventory of the exact B checkpoint and all 199 sensor frames."""
import hashlib, json, sys
from pathlib import Path
import numpy as np

ROOT = Path('/root/autodl-tmp/drivingeditor_repro')
CAMPAIGN = ROOT / 'campaign'
B = CAMPAIGN / 'r15_gn11_stage1_v41_20261023/arms/B/run30k'
FULL = CAMPAIGN / 'r15_gn11_fullclip_cpu_20261026'
V3 = CAMPAIGN / 'r15_gn11_stage1_v3_20261020/road_multiview_002'
ALIASES = {5: '3S_GJHyCGGK4ypFPVKOOqA', 26: 'mSiVqee7l7dfkt8HQhXZZw',
           18: 'Umybpe6eOenVBgQ_zgdVtw', 6: '7MxwK9zTRZ9g5lc_ZC0z6A',
           37: 'vBOasuXpjI7h7d-X_VEQdA'}

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def main():
    out = Path(sys.argv[1]); out.mkdir(parents=True, exist_ok=True)
    checkpoint = {}
    for prefix in ['chkpnt', 'dynamic_chkpnt', 'env_light_chkpnt', 'training_state']:
        p = B / (prefix + '30000.pth')
        checkpoint[prefix] = dict(path=str(p), bytes=p.stat().st_size, sha256=sha(p))
    missing = [str(FULL / folder / ('%03d' % raw + ext))
               for raw in range(199) for folder, ext in
               [('frames', '.npz'), ('frames', '.json'), ('rgb', '.png')]
               if not (FULL / folder / ('%03d' % raw + ext)).is_file()]
    assert not missing, missing
    a = dict(np.load(FULL / 'full199_initialization.npz'))
    assert np.array_equal(a['source_raw'], np.arange(199))
    bundle = json.loads((V3 / 'bundle.json').read_text())
    xyz = a['model_xyz']; scale = bundle['meter_to_model']
    actors = {}
    for alias in [5, 37]:
        distance = np.full(len(xyz), np.inf)
        sample = None
        for fid in bundle['frame_order']:
            boxes = bundle['frames'][fid]['selected_boxes_model']
            if sample is None:
                sample = boxes
        actors[str(alias)] = dict(track_id=ALIASES[alias], native_asset_index=list(ALIASES).index(alias))
    report = dict(scene='waymo-train-008', source_checkpoint='v41 B 30000', checkpoint=checkpoint,
                  B_config=json.loads((B/'effective_config.json').read_text()),
                  actors=actors, delete_aliases=list(ALIASES), evidence_raw_range=[0,198],
                  evidence_frames=199, frame_files_verified=597, all_199_source_raw_verified=True,
                  road_cells=len(xyz), supported=int(a['surface_supported'].sum()),
                  old_eligible=int(a['eligible'].sum()), source_valid_shape=list(a['source_valid'].shape),
                  bundle_boxes_sample=sample, cell_bounds_local=[a['local_xyz'].min(0).tolist(),a['local_xyz'].max(0).tolist()],
                  full199_sha256=sha(FULL/'full199_initialization.npz'),
                  full199_extraction=json.loads((FULL/'extraction.json').read_text())['segment'],
                  gpu_training_started=False, optimizer_updates=0)
    (out/'preflight.json').write_text(json.dumps(report,indent=2), encoding='utf-8')
    print(json.dumps({k:report[k] for k in ['scene','source_checkpoint','actors','evidence_frames','road_cells','supported','old_eligible','source_valid_shape','bundle_boxes_sample','cell_bounds_local']},indent=2))

if __name__ == '__main__': main()
