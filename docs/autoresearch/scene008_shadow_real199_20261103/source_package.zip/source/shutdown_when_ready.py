"""Apply standing AutoDL GPU shutdown authorization after all dependencies end.

Uses the installed AutoDL supervisor shutdown mechanism, without its unrelated
recursive Trash cleanup. Never runs while another compute/transfer/controller
or a scheduled command is present.
"""
import argparse,datetime,json,os,signal,subprocess,time
from pathlib import Path
RUN=Path(__file__).resolve().parent.parent

def command(args):
    try:return subprocess.run(args,capture_output=True,text=True)
    except FileNotFoundError:return None

def main():
    p=argparse.ArgumentParser();p.add_argument('--execute',action='store_true');a=p.parse_args()
    ready=json.loads((RUN/'closeout_ready.json').read_text())
    assert all(ready[k] for k in ['local_bundle_verified','report_and_video_verified','git_push_verified','no_remaining_remote_dependencies','GPU_mode_confirmed_by_user'])
    assert json.loads((RUN/'completion.json').read_text())['formal_updates']==1000
    apps=command(['nvidia-smi','--query-compute-apps=pid,process_name,used_gpu_memory','--format=csv,noheader'])
    assert apps and apps.returncode==0 and not apps.stdout.strip(),apps.stdout if apps else 'no GPU query'
    ancestors=set();pid=os.getpid()
    while pid>0 and pid not in ancestors:
        ancestors.add(pid)
        try:pid=int((Path('/proc')/str(pid)/'stat').read_text().split(') ',1)[1].split()[1])
        except (OSError,ValueError):break
    blockers=[];supervisors=[];base=[]
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit():continue
        pid=int(proc.name)
        try:
            comm=(proc/'comm').read_text().strip();raw=(proc/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace').strip()
            if comm=='supervisord':supervisors.append(pid)
            if pid in ancestors or pid==1 or not raw:continue
            exe=raw.split()[0].rsplit('/',1)[-1]
            if exe.startswith(('python','torchrun','accelerate','ffmpeg')):
                if '/root/miniconda3/bin/jupyter-lab ' in raw or '/root/miniconda3/bin/tensorboard ' in raw:
                    base.append(dict(pid=pid,name=comm));continue
                blockers.append(dict(pid=pid,name=comm,args=raw[:200]))
            elif exe in ['sleep','screen','tmux','scp','sftp-server']:
                blockers.append(dict(pid=pid,name=comm,args=raw[:200]))
            elif exe in ['bash','sh'] and str((proc/'cwd').resolve()).startswith('/root/autodl-tmp'):
                blockers.append(dict(pid=pid,name=comm,args=raw[:200]))
        except (OSError,PermissionError):continue
    assert not blockers,blockers
    for args in [['tmux','list-sessions'],['screen','-ls']]:
        r=command(args);assert r is None or r.returncode!=0,(args,r.stdout if r else '')
    for args in [['crontab','-l'],['atq']]:
        r=command(args)
        if r and r.returncode==0:
            assert not [line for line in r.stdout.splitlines() if line.strip() and not line.lstrip().startswith('#')],r.stdout
    assert len(supervisors)==1,supervisors
    installed=Path('/usr/bin/shutdown').read_text()
    assert 'supervisord' in installed and 'kill' in installed
    receipt=dict(time_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),standing_user_authorization=True,
        GPU_mode_confirmed=True,other_compute_transfer_or_scheduled_work=False,base_services=base,
        local_delivery_and_git_push_verified=True,supervisord_PID=supervisors[0],
        method='AutoDL installed supervisor SIGTERM sequence; no Trash cleanup',
        execute_requested=a.execute,cloud_control_plane_billing_state_verified=False)
    path=RUN/'shutdown_receipt.json';path.write_text(json.dumps(receipt,indent=2))
    print(json.dumps(receipt),flush=True)
    if a.execute:
        fd=os.open('/proc/1/fd/1',os.O_WRONLY);os.write(fd,b'User-authorized shutdown after completed scene008 1k delivery\n');os.close(fd)
        os.kill(supervisors[0],signal.SIGTERM)
        receipt['supervisor_shutdown_signal_sent']=True;path.write_text(json.dumps(receipt,indent=2))
        print(json.dumps(dict(supervisor_shutdown_signal_sent=True,pid=supervisors[0])),flush=True)

if __name__=='__main__':main()
