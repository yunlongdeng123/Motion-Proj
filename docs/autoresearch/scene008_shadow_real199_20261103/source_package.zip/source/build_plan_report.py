"""Local preparation report with architecture diagram and verified receipts."""
import html,json,zipfile,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'outputs/shadow_a5_a37_199_20261103'
STAGE=Path(__file__).resolve().parent

def main():
    contract=json.loads((OUT/'contract.json').read_text(encoding='utf-8'))
    ref=json.loads((OUT/'reference_summary_final.json').read_text(encoding='utf-8'))
    views=json.loads((OUT/'view_summary_final.json').read_text(encoding='utf-8'))
    expanded=json.loads((OUT/'expanded_geometry_summary.json').read_text(encoding='utf-8'))
    shadow=json.loads((OUT/'target_shadow_coverage.json').read_text(encoding='utf-8'))
    shadow105=next(r for r in shadow['rows'] if r['raw']==105)['actors']
    e=html.escape
    svg='''<svg xmlns="http://www.w3.org/2000/svg" width="1260" height="340" viewBox="0 0 1260 340">
    <defs><marker id="arrow" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0 0L8 4L0 8" fill="#536d84"/></marker></defs>
    <rect width="1260" height="340" rx="18" fill="#f1f5f9"/>
    <g font-family="Microsoft YaHei,Arial,sans-serif" font-size="18" fill="#163047" text-anchor="middle">
    <g stroke="#b0c3d3" stroke-width="2" fill="white">
    <rect x="25" y="36" width="210" height="78" rx="10"/><rect x="300" y="36" width="240" height="78" rx="10"/>
    <rect x="25" y="210" width="210" height="92" rx="10"/><rect x="300" y="210" width="240" height="92" rx="10"/>
    <rect x="605" y="210" width="225" height="92" rx="10" fill="#e0f4e9"/><rect x="895" y="110" width="225" height="124" rx="10"/>
    </g>
    <text x="130" y="68">scene-008</text><text x="130" y="96">v41 B · 30k</text>
    <text x="420" y="68">原静态表达 B(t)</text><text x="420" y="96">始终读取当前时间</text>
    <text x="130" y="242">完整 199 帧</text><text x="130" y="272">RGB ＋ LiDAR</text>
    <text x="420" y="242">实测几何与遮挡核验</text><text x="420" y="272">干净道路颜色共识</text>
    <text x="717" y="242">道路修复 R(x)</text><text x="717" y="272">仅此分支时间稳定</text>
    <text x="1008" y="145">局部道路替换</text><text x="1008" y="175">统一深度排序</text><text x="1008" y="207">范围外保持 B(t)</text>
    <text x="1170" y="157">删 5 车</text><text x="1170" y="191">a5 / a37</text>
    </g>
    <g stroke="#536d84" stroke-width="2.5" fill="none" marker-end="url(#arrow)">
    <path d="M235 75H300"/><path d="M540 75H1008V110"/><path d="M235 256H300"/>
    <path d="M540 256H605"/><path d="M830 256H855V195H895"/><path d="M1120 172H1240"/>
    </g></svg>'''
    (OUT/'architecture.svg').write_text(svg,encoding='utf-8')
    bindings=''.join('<tr><td>a%s</td><td>%s</td><td><code>%s</code></td></tr>'%(r['alias'],r['asset_index'],e(r['track_id'])) for r in contract['actor_binding'])
    stats=''
    for alias in ['5','37']:
        r=ref['actors'][alias];sample=next(v for v in views['rows'] if v['raw']==105)['actors'][alias]
        stats+='<tr><td>a%s</td><td>%s / %s</td><td>%s</td><td>%s</td><td>%s</td></tr>'%(alias,r['qualified_cells'],r['domain_cells'],r['source_frames_with_clean_evidence'],sample['shadow_proxy'],sample['route'])
    hashes=''.join('<tr><td>%s</td><td><code>%s</code></td><td>%s</td></tr>'%(e(name),e(r['sha256']),format(r['bytes'],',')) for name,r in contract['checkpoint'].items())
    body=f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>a5 / a37 · 199 帧道路修复实验单</title>
    <style>body{{font:16px/1.7 "Microsoft YaHei",sans-serif;color:#213547;background:#eef3f7;margin:0}}main{{max-width:1120px;margin:auto;padding:30px}}section{{background:white;border-radius:14px;padding:24px;margin:18px 0}}h1{{font-size:29px;margin-bottom:4px}}h2{{font-size:21px}}.status{{background:#d9ecff;padding:14px 18px;border-radius:10px}}table{{border-collapse:collapse;width:100%;font-size:14px}}td,th{{padding:9px;border-bottom:1px solid #dbe3eb;text-align:left}}code{{font-size:12px;overflow-wrap:anywhere}}img{{max-width:100%;border-radius:8px}}.small{{font-size:14px;color:#566b7d}}pre{{white-space:pre-wrap;overflow-wrap:anywhere;background:#f0f4f7;padding:16px}}a{{color:#1464b4}}</style>
    <main><h1>scene-008 · a5 / a37 阴影去除实验单</h1><p>2026-11-03 · 从 v41 B 30k 出发 · 只做已见收益的道路恢复路线</p>
    <p class="status"><b>用户已开启 GPU 并授权直接跑正式 1,000 步。</b>按最新指示跳过 smoke 与恢复重放，总优化预算为 1,000 步。实时结果和完成状态以本目录的结果报告为准。</p>
    <section><h2>本次实现边界</h2><img src="architecture.svg" alt="实验组件与数据流"/>
    <p>保留原 B 静态分支的当前时间求值。新增局部 3D 道路修复分支只学习道路颜色与 opacity，其位置、形状和颜色状态不随时间切换；不添加独立阴影层。</p>
    <p>局部修复渲染中，用新道路替换有实测支撑位置的薄道路表达；高于道路的原静态前景仍参加深度排序。只在合格道路内部使用该结果，范围外精确返回 B(t)。原 B 的四份 30k 权重只读。</p></section>
    <section><h2>输入与身份</h2><p>仍删除五车：<b>a5、a26、a18、a6、a37</b>。主要评价 a5 与 a37。已核验 B 实际训练输入中的五个原始 track ID；删除沿用 B 原生 all_dynamic 口径。</p>
    <table><tr><th>沟通代号</th><th>原资产索引</th><th>Waymo track ID</th></tr>{bindings}</table>
    <p>道路证据使用 raw0–198 全部 199 帧。原 B 的有效编辑时间范围保持 raw89–137，共 49 帧；扩充道路证据不会被表述成扩充了 B 的动态时间支持。</p></section>
    <section><h2>199 帧道路证据已重建</h2><p>输入预览发现旧网格未覆盖 a5 近端阴影，因此已从原始缓存实测回波扩展近端查询范围，并使用旧局部修复方案的 8cm 网格。新查询共 <b>{expanded['cells']:,}</b> 个单元；保留三角几何核验、遮挡检查、至少三份颜色一致观测和至少六帧时间跨度。</p>
    <table><tr><th>目标</th><th>合格 / 范围内道路单元</th><th>提供干净证据的帧数*</th><th>raw105 阴影代理像素</th><th>raw105 道路修复域像素</th></tr>{stats}</table>
    <p>raw105 合格阴影代理中，a5 的 {shadow105['5']['qualified_shadow_pixels']} 个像素有 {shadow105['5']['routed_shadow_pixels']} 个落在修复域；a37 的 {shadow105['37']['qualified_shadow_pixels']} 个有 {shadow105['37']['routed_shadow_pixels']} 个落在修复域。这里只核对输入覆盖，实际去影收益由 GPU 渲染验证。<a href="target_shadow_coverage.json">逐帧覆盖分母</a></p>
    <p class="small">* 两车均搜索全部 199 帧，可用帧数由真实可见性决定。道路参考和阴影区域是可审计代理标签；没有可靠参考的区域保持未知并单列。两车道路范围可能重叠。</p>
    <img src="input_evidence_raw105_final.png" alt="raw105 输入证据与道路修复资格预览"/><p class="small">这是输入证据预览，尚未执行编辑。绿色为可使用的道路内部，黄色为合格边缘；下右图显示分车阴影评价代理。</p></section>
    <section><h2>运行队列与预算</h2><table><tr><th>阶段</th><th>实际工作</th><th>更新记账</th></tr>
    <tr><td>原模型基线</td><td>原 B 删五车；记录两处阴影与完整 49 帧。另保存零步道路初始化结果。</td><td>0</td></tr>
    <tr><td>GPU smoke</td><td>按用户最新明确要求取消；正式过程保留 finite loss/gradient 和显存检查。</td><td>0</td></tr>
    <tr><td>恢复重放</td><td>不追加训练步；最终评价独立进程读取保存的 checkpoint。</td><td>0</td></tr>
    <tr><td>正式单一方案</td><td>从初始道路分支直接训练；均匀采样 49 个原 B 相机，使用完整199帧参考。</td><td><b>1000，全部训练预算</b></td></tr>
    <tr><td>完整验收</td><td>49帧删车对比、两处阴影裁切与视频、逐车指标和最坏帧；输入/源权重 hash 复核。</td><td>0</td></tr></table>
    <p>只训练道路 DC/opacity，学习率分别为 0.0025 / 0.05，seed=0。损失为合格道路线性 RGB L1、实际道路贡献不足项及轻量颜色/opacity 锚定。没有重新训练原 B，没有忽略阴影监督、投影阴影或放开道路时间自由度的额外消融。</p>
    <p>正式更新、耗时和 NVML/CUDA 显存峰单独记录，未额外训练 smoke。旧实验的 0.00665 用于选择路线；本次使用 v41 B 和新的双车199帧范围，需要重测基线和收益。</p></section>
    <section><h2>验收必须回答的事</h2><ol><li>a5、a37 分别报告道路 MAE、阴影代理 MAE、暗残留比例、有效覆盖、实际道路贡献与最坏帧；同时给帧平均和像素加权平均。</li>
    <li>固定相机切换原 B 时间：道路修复分支的 RGB 应保持一致，原静态分支继续使用当前时间。修复范围外与当时刻 B 的最大误差须为 0。</li>
    <li>检查完整49帧的道路接缝、车道线与其他车辆，不能只凭训练误差认定去影成功。四份 B 权重 SHA256 必须保持不变。</li>
    <li>质量评价失败时保留结果和失败原因；不自动增加新的研究分支。完成取回与依赖检查后再处理 GPU 资源收尾。</li></ol></section>
    <section><h2>启动与可复查资产</h2><p>远端独立目录：</p><pre>/root/autodl-tmp/drivingeditor_repro/campaign/shadow_a5_a37_199_20261103</pre>
    <p>正式运行入口：</p><pre>/root/autodl-tmp/envs/drivingeditor/bin/python \\
/root/autodl-tmp/drivingeditor_repro/campaign/shadow_a5_a37_199_20261103/source/run_experiment.py --execute</pre>
    <p><a href="contract.json">封存实验配置与 source hash</a> · <a href="preflight.json">原权重与199帧文件预检查</a> · <a href="reference_summary_final.json">双车证据计数</a> · <a href="view_summary_final.json">49帧评价域</a> · <a href="source_package.zip">启动源码包</a> · <a href="cpu_ready_receipt.json">CPU 就绪凭据</a></p>
    <details><summary>原 B30k 四份文件指纹</summary><table><tr><th>文件</th><th>SHA256</th><th>字节</th></tr>{hashes}</table></details></section></main></html>'''
    (OUT/'experiment_plan.html').write_text(body,encoding='utf-8')
    with zipfile.ZipFile(OUT/'source_package.zip','w',zipfile.ZIP_DEFLATED) as z:
        for name in contract['source_sha256']:z.write(STAGE/name,'source/'+name)
        z.write(STAGE/'finalize_cpu_ready.py','source/finalize_cpu_ready.py')
        z.write(STAGE/'audit_shadow_coverage.py','source/audit_shadow_coverage.py')
        z.write(OUT/'contract.json','contract.json')
    print(OUT/'experiment_plan.html')

if __name__=='__main__':main()
