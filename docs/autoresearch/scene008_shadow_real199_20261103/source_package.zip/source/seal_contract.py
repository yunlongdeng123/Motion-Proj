"""Seal exact inputs, one selected method, budgets and runnable source hashes."""
import hashlib,json
from pathlib import Path
import numpy as np
RUN=Path(__file__).resolve().parent.parent

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda:f.read(8*1024*1024),b''):h.update(chunk)
    return h.hexdigest()

def main():
    p=RUN/'contract.json'
    if p.exists():raise FileExistsError('Do not change a sealed experiment contract')
    pre=json.loads((RUN/'inputs/preflight.json').read_text())
    actor_preparation=Path(pre['B_config']['source_path'])/'dynamic_multi_actor_preparation.json'
    binding=json.loads(actor_preparation.read_text())['actors']
    expected=['3S_GJHyCGGK4ypFPVKOOqA','mSiVqee7l7dfkt8HQhXZZw','Umybpe6eOenVBgQ_zgdVtw','7MxwK9zTRZ9g5lc_ZC0z6A','vBOasuXpjI7h7d-X_VEQdA']
    assert [v['raw_track_id'] for v in binding]==expected
    ref=json.loads((RUN/'inputs_final/reference_summary.json').read_text())
    views=json.loads((RUN/'inputs_final/view_summary_current.json').read_text())
    assert views['frames']==49
    assert all(r['route']>0 for r in views['rows'])
    for raw in range(89,138):
        d=np.load(RUN/'inputs_final/views_current'/('%03d.npz'%raw))
        assert not (d['route']&~d['valid']).any()
        assert not (d['route']&d['other_vehicle_guard']).any()
        assert np.isfinite(d['reference'][d['valid']]).all()
    names=['preflight.py','build_expanded_evidence.py','repair_surface.py','prepare_reference.py','prepare_views.py','preview_inputs.py','check_surface_geometry.py','editor_common.py','road_runtime.py','run_experiment.py','seal_contract.py']
    engine=Path('/root/autodl-tmp/drivingeditor_repro/campaign/r15_gn11_stage1_v41_20261023/engine')
    contract=dict(experiment='SCENE008_V41_B30K_A5_A37_SHADOW_REAL199_20261103',
        status='CPU_PREPARED_GPU_SMOKE_PENDING',scene='waymo-train-008',
        checkpoint=pre['checkpoint'],delete_aliases=[5,26,18,6,37],primary_aliases=[5,37],
        actor_binding=[dict(alias=alias,asset_index=v['actor_index'],track_id=v['raw_track_id']) for alias,v in zip([5,26,18,6,37],binding)],
        actor_preparation_path=str(actor_preparation),actor_preparation_sha256=sha(actor_preparation),
        evidence_raws=list(range(199)),native_render_raws=list(range(89,138)),
        method='full199 stable clean-road consensus + local time-invariant thin 3D road repair',
        trainable_parameters=['road.dc','road.opacity'],geometry_fixed=True,
        original_B_weight_update=False,original_B_renders_at_current_timestamp=True,
        global_static_timestamp_override=False,independent_shadow_layer=False,
        local_replacement='thin native ground rows are suppressed inside the road branch; above-ground rows remain depth ordered; output only on measured route interior',
        formal_updates=1000,formal_initialization='fresh addon, not the smoke checkpoint',
        smoke_training_updates=1001,restore_replay_updates=1,
        seed=0,sampler_seed=20261103,camera_sampling='uniform raw89..137, 49 views',
        learning_rates=dict(road_dc=.0025,road_opacity=.05),
        losses=dict(qualified_linear_RGB_L1=1.,actual_road_alpha_shortfall_to_09=.1,road_DC_tether=.025,opacity_tether=.001),
        source_sha256={name:sha(RUN/'source'/name) for name in names},
        engine_sha256={str(path):sha(path) for path in engine.rglob('*.py')},
        reference_sha256=sha(RUN/'inputs_final/road_reference_199.npz'),
        expanded_geometry_sha256=sha(RUN/'inputs/expanded/evidence.npz'),
        road_grid_cell_m=ref['cell_m'],
        input_view_sha256={str(raw):sha(RUN/'inputs_final/views_current'/('%03d.npz'%raw)) for raw in range(89,138)},
        evaluation=dict(primary='per-actor road + shadow-proxy MAE, qualified coverage and worst frame',
            report_both=['valid-frame macro mean','sample weighted mean'],
            additional=['all49 videos/crops','actual road contribution','outside route maxabs','fixed-camera road time consistency','native full-image time changes','checkpoint/RNG/optimizer resume']),
        acceptance=dict(outside_route_maxabs=0.,road_only_fixed_camera_time_maxabs=0.,parent_weights_SHA256_unchanged=True,
            smoke_finite_loss_gradients=True,resume_loaded_exact=True,resume_next_step_maxabs=1e-6,
            both_actors_shadow_proxy_MAE_must_improve=True,report_unknowns=True,visual_review_required=True),
        evidence_summary=ref['actors'],CPU_view_contract_checks_passed=True,
        GPU_test_passed=False,quality_accepted=False,
        notes=['All199 frames are BUILD data; no unseen-frame generalization claim.',
            'Road reference and shadow masks are audited proxies, not independent counterfactual GT.',
            'Native B time range stays raw89..137; 199 evidence does not extend B dynamic time support.',
            'No training, waiting daemon, GPU power action or automatic shutdown started by preparation.'])
    p.write_text(json.dumps(contract,indent=2),encoding='utf-8')
    print(json.dumps(dict(status=contract['status'],formal_updates=1000,smoke_training_updates=1001,restore_replay_updates=1,
        source_files=len(names),CPU_view_contract_checks_passed=True),indent=2))

if __name__=='__main__':main()
