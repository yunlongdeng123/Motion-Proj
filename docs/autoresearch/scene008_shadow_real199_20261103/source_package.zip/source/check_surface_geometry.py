"""Independent analytic-plane check for the expanded 8cm ray/surface mapping."""
import os
for key in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[key]='1'
import json
from pathlib import Path
import numpy as np
from repair_surface import FixedSurface

def main():
    cell=.08;xx,yy=np.meshgrid(np.arange(6,251),np.arange(-60,61),indexing='ij')
    keys=np.c_[xx.ravel(),yy.ravel()];xy=(keys+.5)*cell
    xyz=np.c_[xy,.01*xy[:,0]+.02*xy[:,1]]
    normal=np.tile([-.01,-.02,1.],(len(keys),1));normal/=np.linalg.norm(normal,axis=1)[:,None]
    units=dict(keys=keys,world=xyz,surface_supported=np.ones(len(keys),bool),provenance=np.ones(len(keys),np.uint8),
        base_weight=np.ones((2,len(keys)),bool),normal_world=normal,cell_m=cell)
    surface=FixedSurface(dict(coordinate_anchor=np.eye(4)),units)
    K=np.array([[350.,0,240.],[0,350.,160.],[0,0,1.]])
    W=np.eye(4);W[:3,:3]=[[0,-1,0],[0,0,-1],[1,0,0]];W[:3,3]=[0,1.7,0]
    result=surface.camera(K,W)
    pixels=result['pixels'];du=(pixels[:,0]+.5-240)/350;dv=(pixels[:,1]+.5-160)/350
    analytic=1.7/(dv+.01-.02*du)
    good=result['supported'];error=np.abs(result['depth'][good]-analytic[good])
    assert good.sum()>10000 and error.max()<1e-8
    independent=np.c_[analytic,-analytic*du,1.7-analytic*dv]
    ids=surface.ids(np.floor(independent[:,:2]/cell).astype(np.int64))
    mismatch=good&(result['unit_id']!=ids)
    values=independent[:,:2]/cell
    boundary=np.min(np.abs(values-np.round(values)),axis=1)<1e-10
    # Exact analytic intersections on a cell boundary have two equivalent
    # neighbours under machine roundoff; require exact IDs everywhere else.
    assert not (mismatch&~boundary).any()
    assert np.max(np.abs(keys[result['unit_id'][mismatch]]-keys[ids[mismatch]]),initial=0)<=1
    # A missing measured corner cannot acquire replacement authority.
    query=np.array([[4.01,0.01]]);before=surface.height(query)[1]
    hole=np.flatnonzero((keys[:,0]==49)&(keys[:,1]==-1))[0];surface.supported[hole]=False
    after=surface.height(query)[1]
    assert before[0] and not after[0]
    report=dict(analytic_plane_pixels=int(good.sum()),depth_maxabs_m=float(error.max()),
        cell_roundtrip_exact_off_boundary=True,boundary_roundoff_pixels=int(mismatch.sum()),
        unsupported_corner_rejected=True,GPU_used=False,
        limitation='Checks expanded-grid geometry only; does not replace GPU smoke')
    (Path(__file__).resolve().parent.parent/'surface_geometry_check.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
