"""CPU acceptance and compact result facts; adds zero optimizer updates."""
import os
os.environ['CUDA_VISIBLE_DEVICES']=''
for key in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS']:os.environ[key]='1'
import hashlib,json,math
from pathlib import Path
import numpy as np
import torch
RUN=Path(__file__).resolve().parent.parent

def main():
    metrics=json.loads((RUN/'final_evaluation/all49/metrics.json').read_text())
    loss=[json.loads(r) for r in (RUN/'formal/loss_from0.jsonl').read_text().splitlines()]
    assert [r['step'] for r in loss]==list(range(1,1001))
    assert all(math.isfinite(r[k]) for r in loss for k in ['loss','road_photo','contribution_shortfall'])
    ck=torch.load(RUN/'formal/checkpoint001000.pth',map_location='cpu',weights_only=False)
    assert ck['step']==1000
    assert all(torch.isfinite(v).all() for v in ck['road'].values() if v.dtype!=torch.bool)
    optimizer_steps=[int(v['step']) for v in ck['optimizer']['state'].values()]
    assert optimizer_steps and set(optimizer_steps)=={1000}
    assert all(torch.isfinite(v).all() for s in ck['optimizer']['state'].values() for v in s.values() if torch.is_tensor(v))
    assert len(metrics['rows'])==49 and max(r['outside_maxabs'] for r in metrics['rows'])==0
    pngs={}
    for raw in [101,105,113]:
        p=RUN/'formal/step001000'/('%03d_repaired_delete5.png'%raw)
        q=RUN/'final_evaluation/all49'/p.name
        pngs[str(raw)]=p.read_bytes()==q.read_bytes()
    assert all(pngs.values())
    actors={}
    for alias in ['5','37']:
        aggregate=metrics['aggregates'][alias]
        rows=[r['actors'][alias] for r in metrics['rows']]
        shadow=[r for r in rows if r['shadow_MAE'] is not None]
        count=sum(r['shadow_proxy_pixels'] for r in shadow)
        before=aggregate['baseline_shadow_MAE']['sample_weighted_mean'];after=aggregate['shadow_MAE']['sample_weighted_mean']
        actors[alias]=dict(shadow_MAE_before=before,shadow_MAE_after=after,
            shadow_MAE_relative_reduction=(before-after)/before,shadow_valid_frames=len(shadow),shadow_samples=count,
            shadow_improved_frames=sum(r['shadow_MAE']<r['baseline_shadow_MAE'] for r in shadow),
            dark_residual_before=sum(r['baseline_dark_residual_fraction']*r['shadow_proxy_pixels'] for r in shadow)/count,
            dark_residual_after=sum(r['dark_residual_fraction']*r['shadow_proxy_pixels'] for r in shadow)/count,
            road_MAE_before=aggregate['baseline_road_MAE']['sample_weighted_mean'],
            road_MAE_after=aggregate['road_MAE']['sample_weighted_mean'],
            frame_macro_shadow_before=aggregate['baseline_shadow_MAE']['frame_macro_mean'],
            frame_macro_shadow_after=aggregate['shadow_MAE']['frame_macro_mean'],
            worst_shadow_raw=aggregate['shadow_MAE']['worst_frame_raw'],worst_shadow_MAE=aggregate['shadow_MAE']['worst_frame_MAE'])
    report=dict(experiment='SCENE008_V41_B30K_A5_A37_SHADOW_REAL199_20261103',
        optimizer_updates=1000,smoke_updates=0,restore_replay_updates=0,diagnostic_updates=0,
        saved_optimizer_steps=optimizer_steps,finite_loss_rows=1000,sampled_raw_frames=sorted(set(r['raw'] for r in loss)),
        mean_loss_first100=float(np.mean([r['loss'] for r in loss[:100]])),
        mean_loss_last100=float(np.mean([r['loss'] for r in loss[-100:]])),
        training_seconds=json.loads((RUN/'formal/receipt.json').read_text())['seconds'],
        NVML_peak_MiB=json.loads((RUN/'gpu_memory_peak.json').read_text())['NVML_peak_MiB'],
        training_CUDA_peak_allocated=max(r['cuda_peak_allocated'] for r in loss),
        training_CUDA_peak_reserved=max(r['cuda_peak_reserved'] for r in loss),
        saved_checkpoint_reloaded_three_anchor_PNGs_exact=pngs,
        outside_maxabs=0.,actors=actors,
        temporal_audit=json.loads((RUN/'final_evaluation/temporal_audit.json').read_text()),
        parent_SHA256_unchanged=json.loads((RUN/'completion.json').read_text())['parent_SHA256_unchanged'],
        metric_scope='Fixed qualified shadow proxies; sample-weighted linear RGB MAE; all199 used for BUILD, no heldout GT claim.',
        human_verdict=None,quality_accepted=False,failure_ledger_refs=['V82-F01','V82-F06'],failure_ledger_delta='none')
    (RUN/'result_summary.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
