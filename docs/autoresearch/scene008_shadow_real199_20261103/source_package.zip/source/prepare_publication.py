"""Prepare a portable light review; large replay inputs stay in verified bundle."""
import shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'outputs/shadow_a5_a37_199_20261103'
STAGE=Path(__file__).resolve().parent/'publication'
DEST=STAGE/'scene008_shadow_real199_20261103'

def main():
    DEST.mkdir(exist_ok=False)
    for pattern in ['*.html','*.json','*.png','*.svg','source_package.zip']:
        for src in OUT.glob(pattern):
            if ('.before_' in src.name and src.suffix!='.json') or src.name=='input_evidence_raw105.png':continue
            shutil.copy2(src,DEST/src.name)
    selected=['final_evaluation','formal/initial','formal/step000100','formal/step001000','target_visibility_audit']
    for folder in selected:shutil.copytree(OUT/'run'/folder,DEST/'run'/folder)
    for name in ['delete5_before_after49.mp4','completion.json','execution_ledger.json','launch_direct.json','gpu_memory_peak.json','gpu_memory_samples.jsonl']:
        target=DEST/'run'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(OUT/'run'/name,target)
    for name in ['checkpoint001000.pth','loss_from0.jsonl','receipt.json','console.log']:
        shutil.copy2(OUT/'run/formal'/name,DEST/'run/formal'/name)
    page=DEST/'result_report.html'
    text=page.read_text(encoding='utf-8').replace('<a href="run/result_bundle_20261103.tar.gz">完整新实验快照（约239MiB）</a>','完整新实验快照约239MiB已在用户本地及远端保留')
    page.write_text(text,encoding='utf-8')
    index=STAGE/'EXPERIMENTS.md';text=index.read_text(encoding='utf-8')
    row='| SCENE008_V41_B30K_A5_A37_SHADOW_REAL199_20261103 | 完整199帧证据、局部时间稳定道路、删五车；用户取消smoke，正式1000步；代理阴影MAE下降40.0%/23.2%，大块残影仍在，未通过去影；原静态时间保留 | [结果、49帧视频与组件](autoresearch/scene008_shadow_real199_20261103/result_report.html) |'
    marker='|---|---|---|'
    assert marker in text and 'SCENE008_V41_B30K_A5_A37_SHADOW_REAL199_20261103' not in text
    index.write_text(text.replace(marker,marker+'\n'+row,1),encoding='utf-8')
    (DEST/'README.md').write_text('# scene-008 · 199帧道路修复1k\n\n![组件图](architecture.svg)\n\n[完整结果与49帧对比](result_report.html)。正式1000更新，按用户要求跳过smoke。代理指标改善但两处大块残影仍在，quality_accepted=false，human_verdict=null。\n\n大体积真实道路证据和49帧资格图位于远端同名campaign与用户本地239MiB完整快照；本目录保留轻量审阅、checkpoint、入口源码与原始指标。回放需要原B30k四件权重及V3坐标bundle。failure_ledger_delta=none。\n',encoding='utf-8')
    print('Publication files:',sum(1 for p in DEST.rglob('*') if p.is_file()),'bytes:',sum(p.stat().st_size for p in DEST.rglob('*') if p.is_file()))

if __name__=='__main__':main()
