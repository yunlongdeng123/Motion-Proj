"""四组真实独立zero-update49完成后，仅打包PNG与顶层凭据。CPU-only。"""
from pathlib import Path
import argparse,datetime,fcntl,gzip,hashlib,io,json,os,struct,subprocess,tarfile

ARMS=['full','real_only','prior_only','ownership_only']
CHANNELS=['gt','full','dynamic','static','delete_all','dynamic_alpha','static_alpha']
FRAMES=[f'0008{i:03d}' for i in range(89,138)]
FINAL_QUEUE='THREE_ABLATIONS_TRAINING_COMPLETE_AWAITING_ZERO_UPDATE49_AND_REPORT'

def read(p):return json.loads(p.read_text(encoding='utf-8'))

def digest(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for data in iter(lambda:f.read(1024*1024),b''):h.update(data)
    return h.hexdigest()

def package(C):
    C=C.resolve();registry=read(C/'ablations/registry.json')
    if registry['status']!=FINAL_QUEUE or registry['pending_arms']:
        raise RuntimeError('all authorized training must have finished first')
    lock=(C.parent/'gpu_slot.lock').open('a+')
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    apps=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid','--format=csv,noheader,nounits'],text=True).strip()
    if apps:raise RuntimeError('preserve current GPU work; packaging requires final idle stage')
    archive=C/'final_full49_delivery.tar.gz';receipt_path=C/'final_full49_delivery.json'
    partial=archive.with_name(archive.name+'.partial');receipt_partial=receipt_path.with_name(receipt_path.name+'.partial')
    if partial.exists() or receipt_partial.exists():raise FileExistsError('preserve previous partial and diagnose')
    entries=[];sources={};png_count=0
    def add(path,name,png=False):
        if path.is_symlink():raise RuntimeError('source symlink is not an ordinary deliverable')
        path=path.resolve()
        if not path.is_file() or path.is_symlink():raise RuntimeError('expected ordinary source file')
        before=path.stat()
        if png:
            with path.open('rb') as f:header=f.read(24)
            if header[:8]!=b'\x89PNG\r\n\x1a\n' or struct.unpack('>II',header[16:24])!=(480,320):
                raise RuntimeError('full-frame PNG contract differs')
        hash_value=digest(path);after=path.stat()
        if (before.st_size,before.st_mtime_ns)!=(after.st_size,after.st_mtime_ns):raise RuntimeError('source changed during read')
        entries.append(dict(path=name,source=str(path),bytes=before.st_size,mtime_ns=before.st_mtime_ns,sha256=hash_value))
    for arm in ARMS:
        campaign=C if arm=='full' else C/'ablations'/arm
        run=campaign/'run30k';out=campaign/'full49';status=read(run/'status.json')
        if status['status']!='complete' or status['iteration']!=30000 or any(status['optimizer_step_counts'][k]!=30000 for k in ['static','dynamic','environment']):
            raise RuntimeError('actual four complete30K counters required')
        result=read(out/'receipt.json');restore=read(out/'restore_receipt.json');progress=read(out/'progress.json')
        if (result['state']!='COMPLETE_V2_NATIVE_FIVE_ID_FULL49_REQUIRES_VISUAL_REVIEW' or result['frames']!=49 or
            result['parameter_updates']!=0 or not result['all_full_frame'] or result['ROI'] or result['image_wh']!=[480,320] or
            set(result['channels'])!=set(CHANNELS) or result['individual_actor_assets'] or set(result['dynamic_scope'])!={6,37,5,26,18} or
            not result['source_checkpoints_unchanged'] or not result['all_inputs_are_training_views']):
            raise RuntimeError('independent final evaluation receipt differs')
        if sorted(x['frame_id'] for x in result['records'])!=FRAMES:raise RuntimeError('exact unique49 frame identities required')
        if restore['status']!='PASSED_ACTUAL_30K_MODEL_ADAM_RNG_SAMPLER_SGCM_RESTORE' or restore['parameter_updates']!=0 or Path(restore['source_run']).resolve()!=run.resolve():
            raise RuntimeError('actual source/restore contract differs')
        if progress['frames']!=49 or progress['total']!=49 or progress['parameter_updates']!=0:
            raise RuntimeError('final progress receipt incomplete')
        if set(result['source_components'])!={'chkpnt30000.pth','dynamic_chkpnt30000.pth','env_light_chkpnt30000.pth','training_state30000.pth'}:
            raise RuntimeError('actual complete30K component metadata required')
        for name,expected in result['source_components'].items():
            p=run/name;s=p.stat()
            if {'bytes':s.st_size,'mtime_ns':s.st_mtime_ns}!=expected:raise RuntimeError('checkpoint metadata changed after evaluation')
        for fid in FRAMES:
            folder=out/fid
            if {p.name for p in folder.iterdir()}!={c+'.png' for c in CHANNELS}:raise RuntimeError('unexpected frame directory contents')
            for channel in CHANNELS:
                p=folder/(channel+'.png');p.resolve().relative_to(out.resolve())
                add(p,arm+'/'+fid+'/'+channel+'.png',png=True);png_count+=1
        for name in ['receipt.json','restore_receipt.json','progress.json']:add(out/name,arm+'/'+name)
        sources[arm]={'campaign':str(campaign),'source_run':str(run),'optimizer_step_counts':status['optimizer_step_counts'],
            'evaluation_receipt_sha256':digest(out/'receipt.json'),'restore_receipt_sha256':digest(out/'restore_receipt.json')}
    if png_count!=1372 or len(entries)!=1384:raise RuntimeError('exact four-group7channel49 contract differs')
    manifest={'status':'COMPLETE_FOUR_V2_ZERO_UPDATE49_PNG_DELIVERY_ARCHIVE','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'sources':sources,'PNG_count':png_count,'files':entries,'frames':FRAMES,'channels':CHANNELS,'image_wh':[480,320],
        'training_updates':0,'GPU_used_for_packaging':False,'checkpoints_included':False,'NPZ_included':False,'quality_accepted':False}
    if receipt_path.exists():
        old=read(receipt_path)
        if not archive.exists() or digest(archive)!=old['archive_sha256'] or old['files']!=entries:
            raise RuntimeError('preserve existing archive/receipt mismatch')
        return old
    if archive.exists():raise FileExistsError('archive without receipt must be preserved and diagnosed')
    raw=json.dumps(manifest,indent=2,ensure_ascii=False).encode()
    with partial.open('xb') as handle,gzip.GzipFile(fileobj=handle,mode='wb',compresslevel=1) as compressed,tarfile.open(fileobj=compressed,mode='w|') as tar:
        info=tarfile.TarInfo('manifest.json');info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
        for item in entries:
            p=Path(item['source']);s=p.stat()
            if (s.st_size,s.st_mtime_ns)!=(item['bytes'],item['mtime_ns']):raise RuntimeError('source changed during packaging')
            tar.add(p,arcname=item['path'],recursive=False)
            s=p.stat()
            if (s.st_size,s.st_mtime_ns)!=(item['bytes'],item['mtime_ns']):raise RuntimeError('source changed during packaging')
    os.replace(partial,archive)
    receipt={**manifest,'archive_path':str(archive),'archive_bytes':archive.stat().st_size,'archive_sha256':digest(archive)}
    with receipt_partial.open('x',encoding='utf-8') as f:json.dump(receipt,f,indent=2,ensure_ascii=False)
    os.replace(receipt_partial,receipt_path)
    return receipt

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--campaign',type=Path,required=True)
    r=package(p.parse_args().campaign)
    print(json.dumps({k:r[k] for k in ['status','PNG_count','archive_bytes','archive_sha256','training_updates']}))
