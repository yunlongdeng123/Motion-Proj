"""仅取回已核验四组独立49PNG归档；验证hash后安全解压，不下载模型。"""
from pathlib import Path,PurePosixPath
import datetime,hashlib,json,shutil,struct,subprocess,tarfile

W=Path(__file__).resolve().parent
O=W.parent.parent/'outputs/gn11_stage1_v2_20261019'
C='/root/autodl-tmp/drivingeditor_repro/campaign/r15_gn11_stage1_v2_20261019'
ARCHIVE=W/'final_full49_delivery.tar.gz'
DEST=W/'full49_delivery'
ARMS={'full','real_only','prior_only','ownership_only'}
CHANNELS={'gt','full','dynamic','static','delete_all','dynamic_alpha','static_alpha'}
FRAMES={f'0008{i:03d}' for i in range(89,138)}

def digest(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()

def main():
    query="from pathlib import Path;print(Path("+repr(C+'/final_full49_delivery.json')+").read_text())"
    p=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','wm-vgpu-1011','/usr/bin/python3','-'],
        input=query,capture_output=True,text=True,encoding='utf-8',check=True)
    receipt=json.loads(p.stdout)
    if (receipt['status']!='COMPLETE_FOUR_V2_ZERO_UPDATE49_PNG_DELIVERY_ARCHIVE' or receipt['PNG_count']!=1372 or
        set(receipt['sources'])!=ARMS or set(receipt['frames'])!=FRAMES or set(receipt['channels'])!=CHANNELS or
        receipt['training_updates'] or receipt['GPU_used_for_packaging'] or receipt['checkpoints_included'] or receipt['NPZ_included'] or
        receipt['archive_path']!=C+'/final_full49_delivery.tar.gz'):
        raise RuntimeError('actual complete four-group delivery receipt required')
    files={x['path']:x for x in receipt['files']}
    pngs={arm+'/'+fid+'/'+channel+'.png' for arm in ARMS for fid in FRAMES for channel in CHANNELS}
    jsons={arm+'/'+name for arm in ARMS for name in ['receipt.json','restore_receipt.json','progress.json']}
    if set(files)!=pngs|jsons:raise RuntimeError('exact1372 PNGs and12 JSONs required')
    local_receipt=W/'final_full49_download.json'
    if local_receipt.exists():
        old=json.loads(local_receipt.read_text(encoding='utf-8'))
        if old['archive_sha256']!=receipt['archive_sha256']:raise RuntimeError('preserve different existing download')
    partial=ARCHIVE.with_name(ARCHIVE.name+'.partial')
    if partial.exists():raise FileExistsError('preserve partial download and diagnose before retry')
    if not ARCHIVE.exists():
        subprocess.run(['scp','-q','-o','BatchMode=yes','-o','ConnectTimeout=15',
            'wm-vgpu-1011:'+receipt['archive_path'],str(partial)],check=True)
        if partial.stat().st_size!=receipt['archive_bytes'] or digest(partial)!=receipt['archive_sha256']:
            raise RuntimeError('download hash/size differs; preserve partial')
        partial.rename(ARCHIVE)
    if ARCHIVE.stat().st_size!=receipt['archive_bytes'] or digest(ARCHIVE)!=receipt['archive_sha256']:
        raise RuntimeError('preserve existing archive hash/size mismatch')
    with tarfile.open(ARCHIVE,'r:gz') as tar:
        members=tar.getmembers()
        if {m.name for m in members}!=set(files)|{'manifest.json'} or len(members)!=1385:
            raise RuntimeError('archive members differ from receipt')
        embedded=json.load(tar.extractfile('manifest.json'))
        if embedded['files']!=receipt['files'] or embedded['sources']!=receipt['sources']:
            raise RuntimeError('archive manifest differs from source receipt')
        for m in members:
            rel=PurePosixPath(m.name)
            if not m.isfile() or rel.is_absolute() or '..' in rel.parts:raise ValueError('unsafe archive member')
            dest=(DEST/Path(*rel.parts)).resolve();dest.relative_to(DEST.resolve())
            data=tar.extractfile(m).read()
            if m.name in files:
                spec=files[m.name]
                if len(data)!=spec['bytes'] or hashlib.sha256(data).hexdigest()!=spec['sha256']:
                    raise RuntimeError('member hash mismatch')
                if m.name in pngs and (data[:8]!=b'\x89PNG\r\n\x1a\n' or struct.unpack('>II',data[16:24])!=(480,320)):
                    raise RuntimeError('full frame PNG dimensions differ')
            if dest.exists():
                if dest.read_bytes()!=data:raise RuntimeError('preserve conflicting local extracted file')
            else:
                dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
    for arm in ARMS:
        public=O/'final_receipts'/arm;public.mkdir(parents=True,exist_ok=True)
        for name in ['receipt.json','restore_receipt.json','progress.json']:shutil.copyfile(DEST/arm/name,public/name)
    (O/'final_delivery_manifest.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    result={'status':'VERIFIED_FOUR_ZERO_UPDATE49_DOWNLOAD_AND_SAFE_EXTRACTION','PNG_count':1372,'JSON_count':12,
        'archive_bytes':receipt['archive_bytes'],'archive_sha256':receipt['archive_sha256'],
        'all_member_hashes_verified':True,'image_wh':[480,320],'models_downloaded':False,
        'training_updates':0,'verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    local_receipt.write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result))

if __name__=='__main__':main()
