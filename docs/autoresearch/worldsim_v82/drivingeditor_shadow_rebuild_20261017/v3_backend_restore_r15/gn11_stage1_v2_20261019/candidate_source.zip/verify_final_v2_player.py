"""验证真实四组与基线的全部视频解码、全帧来源和实际生成播放器控制器。"""
from pathlib import Path
from html.parser import HTMLParser
import hashlib,json,re,subprocess
import numpy as np
from PIL import Image

W=Path(__file__).resolve().parent
O=W.parent.parent/'outputs/gn11_stage1_v2_20261019'

def main():
    receipt=json.loads((O/'final_full49_media.json').read_text(encoding='utf-8'))
    if receipt['status']!='READY_ACTUAL_FOUR_ZERO_UPDATE49_AND_NATIVE_A_COMPARISON':raise RuntimeError('actual complete media required')
    text=(O/'final_full49_compare.html').read_text(encoding='utf-8')
    class Links(HTMLParser):
        def __init__(self):super().__init__();self.refs=[]
        def handle_starttag(self,tag,attrs):
            for k,v in attrs:
                if k in ['src','href'] and v:self.refs.append(v)
    parser=Links();parser.feed(text)
    for ref in parser.refs:assert (O/ref).is_file(),ref
    for i,script in enumerate(re.findall(r'<script>(.*?)</script>',text,re.S)):
        p=W/f'final_full49_generated_{i}.js';p.write_text(script,encoding='utf-8')
        subprocess.run(['node','--check',str(p)],check=True,capture_output=True)
    p=subprocess.run(['node',str(W/'check_final_full49_player.js'),str(O/'final_full49_compare.html')],capture_output=True,text=True,check=True)
    fixture=json.loads(p.stdout);results={}
    for arm,model in receipt['models'].items():
        for channel,item in model['videos'].items():
            path=O/item['path'];assert hashlib.sha256(path.read_bytes()).hexdigest()==item['sha256']
            pixels=subprocess.run(['ffmpeg','-v','error','-nostdin','-i',str(path),'-f','rawvideo','-pix_fmt','rgb24','-'],capture_output=True,check=True).stdout
            frames=np.frombuffer(pixels,dtype=np.uint8).reshape(-1,320,480,3);assert len(frames)==49
            source=W/'full49_delivery'/arm if arm!='baseline' else W.parent/'baseline_engineering_20261018/GN11_stage1_full49'
            errors=[]
            for n,rgb in enumerate(frames):
                with Image.open(source/f'0008{n+89:03d}'/(channel+'.png')) as im:original=np.asarray(im.convert('RGB'),dtype=np.int16)
                errors.append(float(np.abs(rgb.astype(np.int16)-original).mean()))
            assert max(errors)<8,(arm,channel,max(errors))
            results[arm+'_'+channel]={'decoded_frames':49,'full_frame_wh':[480,320],'source_frame_order_verified':True,
                'mean_encoding_RGB_MAE_255':sum(errors)/49,'max_frame_encoding_RGB_MAE_255':max(errors)}
    assert len(results)==35
    output={'status':'PASSED_FOUR_FINAL49_AND_BASELINE_MEDIA_AND_GENERATED_PLAYER_FIXTURE','videos':results,
        'decoded_frames':1715,'new_videos':28,'baseline_videos_reused':7,'generated_handler_fixture':fixture,
        'full_frame':True,'JS_syntax_checks':1,'local_static_links':len(parser.refs),
        'browser_UI_tested':False,'quality_accepted':False,'human_verdict':None}
    (O/'final_full49_validation.json').write_text(json.dumps(output,indent=2),encoding='utf-8')
    print(json.dumps({'status':output['status'],'decoded_frames':1715,'videos':35,'fixture':fixture}))

if __name__=='__main__':main()
