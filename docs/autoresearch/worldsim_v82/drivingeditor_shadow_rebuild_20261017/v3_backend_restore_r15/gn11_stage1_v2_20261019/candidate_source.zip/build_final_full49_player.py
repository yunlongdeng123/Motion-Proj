"""真实四组zero-update49收齐后编码与原生A对照，不改变既有两组原生视频页。"""
from pathlib import Path
import datetime,hashlib,json,re,shutil,subprocess,uuid
from build_native30k_compare import probe,sha

W=Path(__file__).resolve().parent
O=W.parent.parent/'outputs/gn11_stage1_v2_20261019'
S=W/'full49_delivery'
ARMS={'full':('完整版 · 30K','归属修复＋同世界跨帧真实观测＋左右供体先验'),
      'real_only':('仅跨帧 · 30K','归属修复＋同世界跨帧真实观测；先验权重0'),
      'prior_only':('仅供体 · 30K','归属修复＋左右供体先验；真实道路目标权重0'),
      'ownership_only':('仅归属修复 · 30K','两种道路目标权重均0；归属修复组合保持一致')}
CHANNELS={'static':'静态分支','dynamic':'动态分支','full':'完整重建','delete_all':'删除纳入车辆（动态关闭）',
          'static_alpha':'静态alpha','dynamic_alpha':'动态alpha','gt':'原始观测'}

def main():
    download=json.loads((W/'final_full49_download.json').read_text(encoding='utf-8'))
    manifest=json.loads((S/'manifest.json').read_text(encoding='utf-8'))
    assert download['all_member_hashes_verified'] and download['PNG_count']==1372
    media=O/'final_full49_videos';media.mkdir(exist_ok=True)
    previous=O/'final_full49_media.json';old=json.loads(previous.read_text(encoding='utf-8')) if previous.exists() else {'models':{}}
    models={}
    for arm,(label,description) in ARMS.items():
        result=json.loads((S/arm/'receipt.json').read_text(encoding='utf-8'))
        assert result['frames']==49 and result['parameter_updates']==0
        videos={};models[arm]={'label':label,'description':description,'videos':videos}
        for channel in CHANNELS:
            rows=sorted([e for e in manifest['files'] if e['path'].startswith(arm+'/') and e['path'].endswith('/'+channel+'.png')],key=lambda e:e['path'])
            assert len(rows)==49
            source_hash=hashlib.sha256(json.dumps([(x['path'],x['sha256']) for x in rows],separators=(',',':')).encode()).hexdigest()
            for x in rows:assert sha(S/x['path'])==x['sha256']
            target=media/(arm+'_'+channel+'.mp4');prior=old['models'].get(arm,{}).get('videos',{}).get(channel)
            if target.exists():
                if not prior or prior['source_sha256']!=source_hash or sha(target)!=prior['sha256']:
                    raise RuntimeError('preserve video with different or missing provenance')
            else:
                temp=target.with_name(target.stem+'.encoding_'+uuid.uuid4().hex[:8]+'.mp4')
                subprocess.run(['ffmpeg','-v','error','-nostdin','-framerate','10','-start_number','8089',
                    '-i',str(S/arm/'%07d'/f'{channel}.png'),'-frames:v','49','-an','-c:v','libx264','-preset','slow',
                    '-crf','14','-pix_fmt','yuv420p','-g','1','-keyint_min','1','-sc_threshold','0','-bf','0',
                    '-threads','4','-movflags','+faststart',str(temp)],check=True)
                probe(temp);temp.rename(target)
            contract=probe(target);poster=media/(arm+'_'+channel+'_raw089.png');shutil.copyfile(S/arm/'0008089'/f'{channel}.png',poster)
            videos[channel]={'path':target.relative_to(O).as_posix(),'poster':poster.relative_to(O).as_posix(),
                'source_sha256':source_hash,'sha256':sha(target),'bytes':target.stat().st_size,**contract}
            previous.write_text(json.dumps({'models':{**old['models'],**models}},indent=2),encoding='utf-8')
    baseline_root=O.parent/'baseline_engineering_20261018'
    base_receipt=W.parent/'baseline_engineering_20261018/GN11_stage1_full49/receipt.json'
    base=json.loads(base_receipt.read_text(encoding='utf-8'));assert base['frames']==49 and base['parameter_updates']==0
    baseline={}
    for channel in CHANNELS:
        key='observed' if channel=='gt' else channel
        path=baseline_root/'branch_videos'/('gn11five_'+key+'.mp4')
        baseline[channel]={'path':'../baseline_engineering_20261018/branch_videos/'+path.name,'sha256':sha(path),
            'bytes':path.stat().st_size,'reused_existing_baseline_media':True,**probe(path)}
    models['baseline']={'label':'原生A · 第一阶段30K','description':'同五身份/49帧；原生静动态机制，无本轮归属修复或道路目标','videos':baseline}
    data={'models':models,'channels':CHANNELS,'fps':10,'first':89,'last':137}
    receipt={'status':'READY_ACTUAL_FOUR_ZERO_UPDATE49_AND_NATIVE_A_COMPARISON','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        **data,'new_video_count':28,'baseline_videos_reused':7,'frames_each':49,'image_wh':[480,320],
        'additional_training_updates':0,'all_inputs_are_training_views':True,'individual_actor_assets':False,
        'quality_accepted':False,'human_verdict':None,'browser_UI_tested':False}
    previous.write_text(json.dumps(receipt,indent=2,ensure_ascii=False),encoding='utf-8')
    template=(W/'native30k_compare_template.html').read_text(encoding='utf-8')
    template=template.replace('<title>30K 完整视频对比 · 完整版与仅跨帧</title>','<title>四组30K最终结果 · 与原生A同步对照</title>')
    template=template.replace('两组真实30K · raw89–137 · 49帧 · 完整480×320','四组真实30K＋原生A · raw89–137 · 49帧 · 完整480×320')
    template=template.replace('完整版 与 仅跨帧：完整视频对比','四组30K：完整画面同步对照')
    template=template.replace('切换通道后，两栏保持同一帧。','选择两组对照或四组总览；切换通道后保持同一帧。')
    template=template.replace('素材来自各组30K保存节点已有的原生评估，无新增训练更新。这里提供原图、完整重建、静态、动态四通道；独立删车与alpha评估仍待全部训练结束。全部49帧均在训练窗口内，当前页面不作质量通过判断。',
        '四组均从实际30K终点严格恢复模型、Adam、RNG、采样器和SGCM后做零更新评估；原生A基线复用既有真实评估。七通道包含独立删除纳入车辆与alpha。全部49帧均在训练窗口内；旧初始GPU张量不可逐位核对，额外3D标注框用于本轮归属约束，不能称heldout。实际质量结论见报告。')
    template=template.replace('<div class="row" id="channels"','<div class="row"><label>对照 <select id="comparison"></select></label></div>\n <div class="row" id="channels"')
    template,n=re.subn(r'<div class="grid">.*?</div>\s*<p class="muted">两组输入','<div class="grid" id="modelGrid"></div>\n<p class="muted">各组输入',template,count=1,flags=re.S);assert n==1
    template=template.replace('native30k_compare.svg','ablations/architecture.svg')
    template=template.replace('相同输入，完整版与仅跨帧分别训练30K，导出原生四通道完整49帧的模块箭头图','相同输入与归属修复、跨帧与供体开关构成四组30K对照的模块箭头图')
    template=template.replace('归属修复在两组中相同，差别是先验道路目标是否启用。冻结query、来源类别和目标颜色均未改；仅跨帧组只监督OBSERVED，未把供体区域改成真实曝光。先验区域和未知区域需分别解释；本页可观察两组差异，不能把所有差异自动归为单个组件的因果结论。',
        '四组共同保持归属修复，以真实观测与供体目标组成2×2开关；仅归属组与原生A比较归属修复组合。冻结query、来源类别与颜色未改，UNKNOWN始终无道路目标。真实曝光、先验和未知区域需分别解释；归属模块内部细项没有分别隔离，不能据此归因到单个内部约束。')
    template=template.replace('两组逐帧原始观测PNG的hash完全一致。','四组逐帧原始观测PNG保持同一相机与时间身份。')
    template=template.replace('原生静态/动态分支是已有分解通道，后续独立删车评估另行输出。','删除通道实际关闭五身份动态集合并独立重渲染静态＋环境；静态重复解释和原有阴影仍可能存在，不能称全画面无车。')
    template=template.replace('八个完整视频与验证凭据','完整视频与验证凭据')
    template=template.replace('<thead><tr><th>通道</th><th>完整版</th><th>仅跨帧</th></tr></thead>','<thead id="downloadHead"></thead>')
    template=template.replace('native30k_media.json','final_full49_media.json').replace('native30k_sources.json','final_delivery_manifest.json').replace('392张原生PNG逐文件清单','四组独立评估PNG逐文件清单')
    template=template.replace('@@DATA@@',json.dumps(data,ensure_ascii=False,separators=(',',':')))
    js=(W/'final_full49_player.js').read_text(encoding='utf-8')
    template,n=re.subn(r"<script>\s*'use strict';.*?</script>",lambda _: '<script>\n'+js+'\n</script>',template,count=1,flags=re.S);assert n==1
    (O/'final_full49_compare.html').write_text(template,encoding='utf-8')
    print(json.dumps({'report':str(O/'final_full49_compare.html'),'new_videos':28,'baseline_videos':7,'additional_updates':0}))

if __name__=='__main__':main()
