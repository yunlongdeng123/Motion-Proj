# Semantic actor5 identity metadata package

This is a frozen engineering candidate, not an adoption or quality-pass claim.
The original v44 remains the baseline. The strict raw94 photometric failures remain in the reports.

calibration49/ is the current explicit BUILD-all49 identity estimate. It contains the full
inside/total visible-mass arrays and exact static/dynamic row IDs. The predicate is fixed:
total_mass > 0 and inside_mass / total_mass > 0.5. No Gaussian position, colour, opacity,
time, velocity, scale, original source actor or lineage was changed. Unknown/unobserved rows
are not guessed. historical_calibration4/ preserves the preceding four-view candidate.
Both folders retain original_owner_and_lineage.npz separately from semantic selections.

Weights are NOT copied here. Restore the referenced Full5 inference10k package and the
original formal v44 dependencies listed in dependency_references.json. Full5 weights must
match the two manifest SHA256 values. The original v44 static/env/road/gates/fine/C2 and its
native a37 path remain frozen. Original v44 data/code paths must satisfy its input contract;
this is not a standalone CUDA environment or a relocation of that baseline.

The full inside/total NPZ is deliberately retained: the current loader rechecks the exact
majority predicate. Do not replace it with only row IDs. Full5 transform metadata is copied
here so QUERY need not read its old source PLY tree. Original BUILD actor masks are used for
calibration, not for query-frame clipping. The original v44 runtime retains its existing
camera/pose/asset dependencies. Native CUDA extensions are still required.

In a fresh worker, add PACKAGE/api_source and the formal v44 source directory to PYTHONPATH:

    from pathlib import Path
    from v44_runtime import V44Runtime
    from drivingeditor_dynamic_edit.v44_integration import SemanticActor5V44Integration
    package = Path('/path/to/semantic_identity_package49')
    base = V44Runtime('/root/autodl-tmp/drivingeditor_repro/campaign/scene008_v44_rgb_asset_20261107_r1/contract/input_contract.json')
    runtime = SemanticActor5V44Integration(
        base, semantic_sidecar_path=package/'calibration49/semantic_actor5_manifest.json',
        full5_model='/path/to/restored/inference10k',
        full5_transform_path=package/'full5_transform_matrix.txt')
    keep = runtime.render_scene(94, delete=False)
    delete_a37 = runtime.render_scene(94, delete=True)
    receipt = runtime.receipt()

Only the selected Full5 static/dynamic rows are appended under semantic group5. Source37
rows selected as semantic5 keep their original source ancestry in the separate table.
This does not mean all source37 rows were deleted. The v44 target a37 follows its original
edit path; there is no static-source retirement in this mode. All components participate
in one native depth sort, with no pixel compositing or colour fitting. No optimizer exists.

Architecture: Full5 frozen weights + BUILD masks -> visible alphaT masses -> fixed semantic
row sidecar -> selected static/dynamic rows + original v44 -> joint native KEEP / DELETE37.
Full49 calibration statistics do not authorize full49 candidate image rendering.
