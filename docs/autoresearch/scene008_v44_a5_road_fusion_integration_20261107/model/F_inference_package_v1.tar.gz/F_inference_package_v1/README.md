# F 固定几何道路外观推理元数据

本包保存完整贡献矩阵、原域像素数、固定203932行RGB残差及精确源代码快照。它是候选F的可重放元数据，不是独立完整模型包；质量与采纳状态以主报告为准。

![Components](architecture.svg)

必须继续提供 parent_dependencies.json 中的原V44 frozen依赖、Full5身份检查点、固定语义sidecar及transform副本。原完整训练Adam/RNG现场仍在AutoDL原目录。本包不包含原大模型或原GT输入。

通过已安装repo使用 `BoundedRoadAppearanceV44Integration(semantic_runtime, package/qualification/qualification_manifest.json, package/material/appearance_manifest.json)`，然后 `scene(raw, delete=False)` / `render(raw, scene)`。可读快照位于 source/；不要把source快照目录直接当另一套冻结V44替换。

`global_branch_row_ids` 是 native_static1042776 + oldroad143248 的拼接行号，不能直接当实际joint packet行号。公开loader按原branch映射，KEEP/DELETE复用同一固定残差。导出和载入都从完整矩阵重新计算w与weighted L1成本；不允许只删除矩阵留一个w缓存。

预算只对记录的4个BUILD视角成立，不保证未测49帧。新δ行选择不使用QUERY当帧掩码/GT；原V44的观测输入读取依赖保持。原SH、geometry、opacity、identity和环境不更新；新增残差先加在原SH/fine颜色之后再clamp_min0，不截断HDR上界。

source中的AA/C新增几何、源身份退休等旧路径是历史快照，不是F默认入口。所有原始失败记录和旧方法现场保留。
