'use strict';
const D=window.SCENE_DATA,IA=window.IDENTITY_AUDIT,$=id=>document.getElementById(id),H=320,W=480;
const categories={v43:'V43 身份与结构实验',reconstruction:'原生重建 · 六档检查点',benchmark:'八类物理编辑',motion:'运动与相机诊断',continuous:'连续编辑修订',control:'因果诊断 / 工程控制'};
const channels={semantic_2d:'GPU 二维语义预测（原始观测）',rgb:'原生 RGB',sensor_overlay:'同帧实拍＋原始车辆框 / LiDAR 核对',generated:'固定 ProPainter 输出',gt:'原相机实拍 RGB（场景参照）',static:'静态分支独立输出（可能含车辆残影）',dynamic:'动态分支独立输出（仅已建目标）',mask:'视频修补区域',alpha:'原生合成 alpha',isolated_alpha:'车身独立 alpha（覆盖率）',visibility_ratio:'合成贡献 / 独立 alpha（可见比例）',dynamic_weight:'合成中的动态贡献',foreign_weight:'合成中的外来资产贡献',depth_m:'原生期望深度 [m]',residual:'未编辑重建 / 实拍误差',alpha_image:'动态独立 alpha'};
const allGroups=Object.fromEntries(D.groups.map(g=>[g.id,g]));
const raws=Object.keys(D.frames).map(Number).sort((a,b)=>a-b);
const S={raw:raws[Math.min(32,raws.length-1)],group:'reconstruction_30000',channel:'rgb',pixel:[240,200],category:'reconstruction',maps:null,lidar:null,baseImage:null,sensorImage:null,playing:false,epoch:0,clouds:null,projection:[],selected:null,orbit:{yaw:-.16,pitch:.48,distance:42,cx:40,cy:0,cz:0,panX:0,panY:0},cameraView:false,cameraReference:'current'};
const imageCache=new Map(),scriptCache=new Map(),mapCache=new Map(),lidarCache=new Map();
const fmt=(v,n=3)=>Number.isFinite(v)?v.toFixed(n):'—';
function el(tag,attrs={},text=''){const e=document.createElement(tag);for(const [k,v] of Object.entries(attrs))e[k]=v;if(text)e.textContent=text;return e;}
function option(sel,value,text){sel.append(el('option',{value},text));}
function loadScript(path){if(!scriptCache.has(path))scriptCache.set(path,new Promise((resolve,reject)=>{const n=document.createElement('script');n.src=path;n.onload=()=>resolve();n.onerror=()=>{scriptCache.delete(path);reject(Error('无法加载 '+path));};document.head.append(n);}));return scriptCache.get(path);}
function loadImage(path){if(!imageCache.has(path)){const p=(async()=>{await loadScript(path+'.js');const uri=window.IMAGE_DATA[path];delete window.IMAGE_DATA[path];scriptCache.delete(path+'.js');if(!uri)throw Error('图像包缺失 '+path);return new Promise((resolve,reject)=>{const im=new Image();im.evidencePath=path;im.onload=()=>resolve(im);im.onerror=()=>{imageCache.delete(path);reject(Error('图像解码失败 '+path));};im.src=uri;});})();imageCache.set(path,p);if(imageCache.size>80)imageCache.delete(imageCache.keys().next().value);}return imageCache.get(path);}
function half(n){const sign=(n&0x8000)?-1:1,e=(n>>10)&31,m=n&1023;return e===31?(m?NaN:sign*Infinity):sign*(e?Math.pow(2,e-15)*(1+m/1024):m*Math.pow(2,-24));}
async function unpack(p){const compressed=Uint8Array.from(atob(p.data),x=>x.charCodeAt(0));if(typeof DecompressionStream==='undefined')throw Error('数值地图需新版 Chrome / Edge 的 DecompressionStream；原 PNG 仍可查看');const b=await new Response(new Blob([compressed]).stream().pipeThrough(new DecompressionStream('deflate'))).arrayBuffer();const out={};for(const [k,a] of Object.entries(p.arrays)){const buffer=b.slice(a.offset,a.offset+a.bytes);let v;if(a.dtype==='<f2')v=Float32Array.from(new Uint16Array(buffer),half);else{const Type={'<f4':Float32Array,'<f8':Float64Array,'<i4':Int32Array,'<u2':Uint16Array,'|u1':Uint8Array}[a.dtype];if(!Type)throw Error('Unsupported '+a.dtype);v=new Type(buffer);}out[k]=v;}return out;}
async function maps(f){if(!f?.maps)return null;const path=f.maps;if(!mapCache.has(path)){const promise=(async()=>{await loadScript(path);const value=await unpack(window.EVIDENCE_MAPS[path]);delete window.EVIDENCE_MAPS[path];return value;})();mapCache.set(path,promise);if(mapCache.size>12){const old=mapCache.keys().next().value;mapCache.delete(old);scriptCache.delete(old);}}return mapCache.get(path);}
async function lidar(raw){if(!lidarCache.has(raw))lidarCache.set(raw,(async()=>{await loadScript(D.frames[raw].lidar);const value=await unpack(window.LIDAR_DATA[raw]);delete window.LIDAR_DATA[raw];return value;})());return lidarCache.get(raw);}
function empty(canvas,text){const x=canvas.getContext('2d');x.fillStyle='#08111d';x.fillRect(0,0,canvas.width,canvas.height);x.fillStyle='#a1b1c7';x.font=`${canvas.width>600?18:14}px Microsoft YaHei`;x.textAlign='center';const pieces=text.match(/.{1,28}/g)||[text];pieces.forEach((t,i)=>x.fillText(t,canvas.width/2,canvas.height/2+i*23));x.textAlign='left';}
function cross(x,w,h){const px=(S.pixel[0]+.5)/W*w,py=(S.pixel[1]+.5)/H*h;x.strokeStyle='#ff8dbd';x.lineWidth=1;x.beginPath();x.moveTo(px-7,py);x.lineTo(px+7,py);x.moveTo(px,py-7);x.lineTo(px,py+7);x.stroke();}
function imageOn(canvas,im,mark=true){const x=canvas.getContext('2d');x.clearRect(0,0,canvas.width,canvas.height);x.drawImage(im,0,0,canvas.width,canvas.height);if(mark)cross(x,canvas.width,canvas.height);}
function heat(value,depth=false){const v=Math.min(1,Math.max(0,depth?value/80:value));return [Math.round(255*Math.max(0,1.5-Math.abs(v*4-3))),Math.round(255*Math.max(0,1.5-Math.abs(v*4-2))),Math.round(255*Math.max(0,1.5-Math.abs(v*4-1)))];}
function drawMap(canvas,data,key){const x=canvas.getContext('2d'),a=data?.[key];if(!a){empty(canvas,'本组没有保存这个数值通道');return;}const img=x.createImageData(W,H);for(let i=0;i<W*H;i++){const value=key==='depth_m'?a[i]:a[i]/255,c=Number.isFinite(value)?heat(value,key==='depth_m'):[7,12,20];img.data.set([...c,255],i*4);}x.putImageData(img,0,0);cross(x,W,H);}
function selected(){return allGroups[S.group];}
function applyGroupView(){if(['benchmark','motion','continuous','v43'].includes(selected().category)){S.cameraView=true;S.cameraReference='current';$('geometryState').value='current';}S.selected=null;}
function setCategory(value,keep){S.category=value;$('category').value=value;$('arm').replaceChildren();D.groups.filter(g=>g.category===value).forEach(g=>option($('arm'),g.id,g.title));S.group=keep||$('arm').value;$('arm').value=S.group;fillChannels();applyGroupView();}
function fillChannels(){const g=selected();const available=new Set(['rgb','gt','semantic_2d']);if(IA)available.add('sensor_overlay');Object.values(g.frames).forEach(f=>{Object.keys(f.channels).forEach(k=>available.add(k));if(f.maps)['alpha','dynamic_weight',...(String(f.maps).includes('v43_review_maps')?[]:['depth_m']),...(/v43_(badcase|review)_maps/.test(String(f.maps))?['isolated_alpha','visibility_ratio']:[])].forEach(k=>available.add(k));});if(g.id==='benchmark_vehicle_insertion')available.add('foreign_weight');if(g.kind==='reconstruction')available.add('residual');$('channel').replaceChildren();Object.keys(channels).filter(k=>available.has(k)).forEach(k=>option($('channel'),k,channels[k]));if(!available.has(S.channel))S.channel='rgb';$('channel').value=S.channel;}
function metric(label,value){const d=el('div',{className:'metric'});d.append(el('small',{},label),el('strong',{},value));$('pixelMetrics').append(d);}
function sampleImage(im,x,y){if(!im)return null;const c=document.createElement('canvas');c.width=W;c.height=H;const a=c.getContext('2d',{willReadFrequently:true});a.drawImage(im,0,0,W,H);return Array.from(a.getImageData(x,y,1,1).data).slice(0,3);}
async function drawPixels(epoch){const [px,py]=S.pixel,i=py*W+px,m=S.maps;$('pixelLabel').textContent=`p = (${px}, ${py})`;$('pixelMetrics').replaceChildren();const rgb=sampleImage(S.baseImage,px,py);metric(S.channel==='semantic_2d'?'原始实拍 RGB · PNG8':'当前显示 RGB · PNG8',rgb?rgb.join(' / '):'—');if(S.channel==='semantic_2d'){const a=S.gpuSemanticFrames?.get(S.raw),k=a?.semantic_image[i];metric('二维语义预测',k===undefined?'未加载':k+' '+GPU_SEMANTIC_NAMES[k]);metric('二维预测概率',a?fmt(a.confidence_image[i]):'未加载');}metric('原生合成 alpha',m?fmt(m.alpha?.[i]/255):'未导出');metric('合成动态贡献',m?fmt(m.dynamic_weight?.[i]/255):'未导出');if(m?.isolated_alpha){metric('车身独立 alpha',fmt(m.isolated_alpha[i]/255));metric('合成可见比例',fmt(m.visibility_ratio[i]/255));}metric('原生期望深度 / 米',m?fmt(m.depth_m?.[i]):'未导出');let z=null;if(S.lidar)for(let j=0;j<S.lidar.depth.length;j++)if(S.lidar.uv[2*j]===px&&S.lidar.uv[2*j+1]===py){z=S.lidar.depth[j];break;}metric('原相机 LiDAR z / 米',z===null?'该采样像素无回波':fmt(z));metric('源图相对时间 / 秒',fmt(D.frames[S.raw].physical_seconds,2));const x=$('zoomCanvas').getContext('2d');x.imageSmoothingEnabled=false;if(S.baseImage){x.drawImage(S.baseImage,Math.max(0,Math.min(W-60,px-30)),Math.max(0,Math.min(H-40,py-20)),60,40,0,0,240,160);}else empty($('zoomCanvas'),'当前通道无 RGB 裁片');$('pixelNote').textContent='RGB 是保存的显示图；alpha/权重为量化显示值。深度来自原生三维输出，未经过视频修补。LiDAR 只对应原相机，稀疏采样缺值不代表没有道路。';}
async function show(){const epoch=++S.epoch,g=selected(),f=g.frames[S.raw];S.maps=null;S.baseImage=null;S.selected=null;$('status').className='';$('frame').value=S.raw;const availableRaws=Object.keys(g.frames).map(Number).sort((a,b)=>a-b);$('frame').min=availableRaws[0];$('frame').max=availableRaws.at(-1);$('frameLabel').textContent=`raw${S.raw} · ${availableRaws.indexOf(S.raw)+1}/${availableRaws.length}`;$('status').textContent=`${g.title} · raw${S.raw} · 读取证据…`;$('mapLegend').textContent=S.channel==='rgb'?g.title+' · 原生渲染 RGB':channels[S.channel];$('overlayTools').hidden=!IA||S.channel!=='sensor_overlay';
  try{
    let im=null,md=null;const mapFrame=S.channel==='sensor_overlay'?allGroups.reconstruction_30000.frames[S.raw]:f;if(mapFrame){md=await maps(mapFrame);if(epoch!==S.epoch)return;S.maps=md;}
    let path=['gt','sensor_overlay','semantic_2d'].includes(S.channel)?D.gt[S.raw]:f?.channels[S.channel];
    if(path){im=await loadImage(path);if(epoch!==S.epoch)return;S.baseImage=im;imageOn($('renderCanvas'),im);}
    else if(S.channel==='residual'&&f){const a=await loadImage(f.channels.rgb),b=await loadImage(D.gt[S.raw]);if(epoch!==S.epoch)return;const c=document.createElement('canvas');c.width=W;c.height=H;const cx=c.getContext('2d');cx.drawImage(a,0,0);const aa=cx.getImageData(0,0,W,H);cx.drawImage(b,0,0);const bb=cx.getImageData(0,0,W,H);for(let i=0;i<aa.data.length;i+=4){const e=(Math.abs(aa.data[i]-bb.data[i])+Math.abs(aa.data[i+1]-bb.data[i+1])+Math.abs(aa.data[i+2]-bb.data[i+2]))/3/255;aa.data.set([...heat(Math.min(1,e*5)),255],i);}cx.putImageData(aa,0,0);imageOn($('renderCanvas'),c);$('mapLegend').textContent='PNG 显示误差 · 色标饱和于平均绝对差 0.2；原始浮点分数见评价表';}
    else if(f&&md)drawMap($('renderCanvas'),md,S.channel);else empty($('renderCanvas'),f?'此通道未导出':'本组无此帧；编辑范围为中央 31 帧');
    const l=await lidar(S.raw),sensor=S.channel==='sensor_overlay'?await loadImage(D.gt[S.raw]):null;if(epoch!==S.epoch)return;S.lidar=l;S.sensorImage=sensor;await ensureSemantic();if(epoch!==S.epoch)return;if(S.channel==='semantic_2d')drawSemanticImage();if(S.channel==='sensor_overlay'){drawSensorOverlay();$('mapLegend').textContent='同一原相机实拍：橙色 TARGET 为所选独立动态资产；蓝色为其他原始标注框；绿色为训练目标轮廓；青色为实测 LiDAR。框不代表独立资产已建立；此通道固定原相机，不跟随编辑请求。';}await drawPixels(epoch);draw3D();drawBEV();
    await Promise.all([pair(g,f,epoch),comparisons(epoch)]);if(epoch!==S.epoch)return;
    const met=f?.metrics?.full;$('frameMetrics').textContent=g.category==='v43'?'V43 重点核对：车身空间结构、编辑后是否拉散，以及原静态层的残影。像素分数保存在执行记录中。':met?`本帧完整重建 PSNR ${fmt(met.composite_psnr_db,3)} dB · 原生 float 指标；目标区 ${fmt(f.metrics.actor?.composite_psnr_db,3)} dB`:'编辑画面没有配对反事实 RGB 真值；不显示伪 PSNR。';
    const valid=Object.keys(g.frames).map(Number);$('status').textContent=`${g.title} · raw${S.raw} · 本组 ${valid.length} 帧（raw${Math.min(...valid)}—${Math.max(...valid)}）${f?'':' · 当前帧不可用'} · 已保存结果`;
    const links=$('sourceLinks');links.replaceChildren();[['summary','原生执行凭据'],['backend','视频后端凭据']].forEach(([k,label])=>{if(g[k])links.append(el('a',{href:g[k],target:'_blank'},label));});
    const common=g.category==='reconstruction'?'evidence/'+g.id+'_event.json':g.category==='benchmark'?'evidence/benchmark_status.json':g.category==='continuous'?'evidence/continuous_summary.json':g.category==='v43'?'evidence/'+g.id+'_metrics.json':'evidence/motion_summary.json';links.append(el('a',{href:common,target:'_blank'},'完整执行记录'),el('a',{href:'scene.json',target:'_blank'},'数据与原始路径'));
  }catch(e){if(epoch===S.epoch){$('status').textContent='加载失败：'+e.message;$('status').className='bad';}}
}
async function pair(g,f,epoch){for(const [ch,id] of [['rgb','nativeCanvas'],['generated','generatedCanvas']]){const path=f?.channels[ch];if(path){const im=await loadImage(path);if(epoch!==S.epoch)return;imageOn($(id),im);}else empty($(id),ch==='generated'?'该请求没有视频修补输出':'此帧未执行');}if(epoch!==S.epoch)return;$('backendInfo').textContent=f?.channels.generated?'这组保存了相同输入与固定 ProPainter 的逐帧输出。可在上方切换修补区域；黑色表示未请求修补。':g.category==='reconstruction'?'原生完整重建，未接视频修补。':g.id.startsWith('benchmark_ego')?'自车视角未知域掩码尚未建立，目前仅有原生输出。':g.id==='benchmark_vehicle_insertion'?'跨场景资产直接插入，没有原位删车洞；本组未调用视频后端。':'该组未执行或未保存对应视频修补；保持为空。';}
const compareSlots=[];
function createComparisons(){for(let i=0;i<6;i++){const a=el('article'),sel=el('select',{'ariaLabel':'对照组 '+(i+1)});option(sel,'gt','原相机实拍（场景参照）');D.groups.forEach(g=>{option(sel,g.id,g.title);if(Object.values(g.frames).some(f=>f.channels.generated))option(sel,g.id+'::generated',g.title+' / ProPainter');});const c=el('canvas',{width:480,height:320}),n=el('div',{className:'note'});a.append(sel,c,n);$('comparison').append(a);compareSlots.push({select:sel,canvas:c,note:n});sel.onchange=()=>comparisons(S.epoch);c.onclick=e=>pickPixel(e,c);}}
function editingCompare(){const g=selected();let ids=['gt','reconstruction_30000',g.id,g.id+'::generated','motion_delete_target','benchmark_vehicle_insertion'];if(!Object.values(g.frames).some(f=>f.channels.generated))ids[3]='motion_no_edit';ids.forEach((v,i)=>compareSlots[i].select.value=v);comparisons(S.epoch);}
function trainingCompare(){compareSlots.forEach((s,i)=>s.select.value='reconstruction_'+((i+1)*5000));comparisons(S.epoch);}
async function comparisons(epoch){await Promise.all(compareSlots.map(async s=>{const [id,ch='rgb']=s.select.value.split('::'),g=allGroups[id],f=g?.frames[S.raw];const path=id==='gt'?D.gt[S.raw]:f?.channels[ch];if(!path){empty(s.canvas,'本组没有此帧/输出');s.note.textContent='不替换帧号、不填充结果';return;}const im=await loadImage(path);if(epoch!==S.epoch)return;imageOn(s.canvas,im);s.note.textContent=`raw${S.raw} · ${id==='gt'?'原相机实拍；不是编辑后真值':g.title+(ch==='generated'?' / 视频修补':'')}`;}));}
function pickPixel(e,canvas){const r=canvas.getBoundingClientRect();S.pixel=[Math.min(W-1,Math.max(0,Math.floor((e.clientX-r.left)/r.width*W))),Math.min(H-1,Math.max(0,Math.floor((e.clientY-r.top)/r.height*H)))];show();}
function matp(M,p){return [0,1,2].map(i=>M[i][0]*p[0]+M[i][1]*p[1]+M[i][2]*p[2]+M[i][3]);}
function cameraProject(p,c,w,h){const d=p.map((x,i)=>x-c[i][3]);const q=[0,1,2].map(j=>d.reduce((sum,x,i)=>sum+x*c[i][j],0));if(q[2]<.1)return null;const K=D.frames[S.raw].K;return [(q[0]/q[2]*K[0]+K[2])/W*w,(q[1]/q[2]*K[1]+K[3])/H*h,q[2]];}
function projection(p){const c=$('sceneCanvas');if(S.cameraView)return cameraProject(p,currentCamera(),c.width,c.height);const o=S.orbit,x=p[0]-o.cx,y=p[1]-o.cy,z=p[2]-o.cz;const right=Math.sin(o.yaw)*x-Math.cos(o.yaw)*y,forward=Math.cos(o.yaw)*x+Math.sin(o.yaw)*y,depth=forward*Math.cos(o.pitch)-z*Math.sin(o.pitch)+o.distance;if(depth<.1)return null;const down=-forward*Math.sin(o.pitch)-z*Math.cos(o.pitch),focal=c.width*.8;return [c.width/2+right*focal/depth+o.panX,c.height/2+down*focal/depth+o.panY,depth];}
function line3(x,points,color,width=1){x.strokeStyle=color;x.lineWidth=width;x.beginPath();let started=false;for(const p of points){const v=projection(p);if(!v){started=false;continue;}if(!started)x.moveTo(v[0],v[1]);else x.lineTo(v[0],v[1]);started=true;}x.stroke();}
function boxPoints(fr){const c=fr.target_center,R=fr.target_rotation,size=fr.target_size;return Array.from({length:8},(_,n)=>c.map((v,k)=>v+[0,1,2].reduce((sum,j)=>sum+R[k][j]*size[j]/2*((n>>j)&1?1:-1),0)));}
function cloudPoint(data,j,cycle,t=D.frames[S.raw].model_time){const delta=t-data.t[j],marginal=Math.exp(-.5*delta*delta/(data.sigma_t[j]**2)),angular=2*Math.PI/cycle,factor=Math.sin(delta*angular)/angular;return {p:[0,1,2].map(k=>data.xyz[3*j+k]+data.velocity[3*j+k]*factor),opacity:data.opacity[j]*marginal,marginal};}


function drawSensorOverlay(){
 const canvas=$('renderCanvas'),x=canvas.getContext('2d');if(!S.sensorImage||!IA)return;imageOn(canvas,S.sensorImage,false);
 if($('overlayLidar').checked&&S.lidar){x.fillStyle='#3ef5eb';for(let i=0;i<S.lidar.depth.length;i++)x.fillRect(S.lidar.uv[i*2],S.lidar.uv[i*2+1],1,1);}
 const fr=IA.frames[S.raw];if($('overlayBody').checked){x.fillStyle='#7aff66';for(const p of fr.body_outline)x.fillRect(p[0],p[1],1,1);}
 if($('overlayBoxes').checked)for(const b of fr.vehicle_boxes){if(!b.in_front_image||!b.uv_sensor)continue;const p=b.uv_sensor;x.strokeStyle=b.target?'#ffbf47':'#59a9ff';x.lineWidth=b.target?1.5:.6;x.beginPath();for(let n=0;n<8;n++)for(let j=0;j<3;j++)if(!(n&(1<<j))){x.moveTo(...p[n]);x.lineTo(...p[n|(1<<j)]);}x.stroke();const xx=Math.max(0,Math.min(W-48,Math.min(...p.map(v=>v[0])))),yy=Math.max(10,Math.min(...p.map(v=>v[1]))-3);x.fillStyle='#07101b';x.fillRect(xx,yy-10,b.target?44:23,11);x.fillStyle=b.target?'#ffbf47':'#59a9ff';x.font='10px monospace';x.fillText(b.label,xx,yy);}
 cross(x,W,H);
}

function resetView3D(){const fr=D.frames[S.raw],center=fr.target_center;S.cameraView=false;S.orbit={yaw:-.16,pitch:.48,distance:42,cx:center[0]-7,cy:center[1]+1,cz:0,panX:0,panY:0};}
// Saved camera, clock and rigid transforms used by the native edit renderer.
// Loaded after scene_viewer.js declarations and before init (combined at build).
function editState(raw=S.raw){
 const source=$('geometryState').value==='baseline'||['gt','sensor_overlay','semantic_2d'].includes(S.channel);
 const key=source?'reconstruction_30000':S.group;
 return window.EDIT_GEOMETRY?.groups[key]?.[raw]||null;
}
function currentCamera(){return S.cameraReference==='original'?D.frames[S.raw].c2w:(editState()?.camera||D.frames[S.raw].c2w);}
function geometryInstances(){
 const st=editState();if(!st?.supported)return [];
 const list=st.static_visible?[{key:'static',cloud:'static',query_time:st.world_time,transform:null,label:'STATIC',suppressed_rows:st.static_suppressed_rows||null,static_adapter:st.static_adapter||null}]:[];
 return [...list,...st.objects];
}
function editedPoint(instance,j){
 const cloud=S.clouds[instance.cloud],pt=cloudPoint(cloud.data,j,cloud.cycle,instance.query_time);
 if(instance.transform)pt.p=matp(instance.transform,pt.p);
 /* target-unknown-adapter */
 const a=S.staticAdapters?.[instance.static_adapter],idx=a?sparseIndex(a.ids,cloud.data.ids[j]):-1;
 if(idx>=0){const ti=a.raws?a.raws.indexOf(S.raw):-1,phi=a.time_phi&&ti>=0?a.time_phi[ti*a.ids.length+idx]:1;pt.opacity*=1-(1-a.opacity_factor[idx])*phi;pt.rgb=[0,1,2].map(k=>Math.round(Math.max(0,Math.min(255,cloud.data.rgb[j*3+k]+255*phi*a.dc_rgb_delta[idx*3+k]))));}
 if(cloud.opacity_density_scale)pt.opacity=1-Math.pow(1-pt.opacity,cloud.opacity_density_scale);return pt;
}
function currentBoxes(){
 const st=editState();if(!st?.supported)return [];
 const source=$('geometryState').value==='baseline'||['gt','sensor_overlay','semantic_2d'].includes(S.channel)||S.group==='reconstruction_30000'||S.group==='motion_no_edit';
 if(source)return IA?IA.frames[S.raw].vehicle_boxes:[{target:true,track:D.target_track,label:'TARGET',corners_local:boxPoints(D.frames[S.raw])}];
 const others=IA?IA.frames[S.raw].vehicle_boxes.filter(b=>!b.target):[];
 return [...others,...(st.reference_boxes||[]),...st.objects.filter(o=>!o.render_only).map(o=>({target:true,track:o.key==='target'?D.target_track:o.key,label:o.label,corners_local:o.corners_local,imported:o.cloud.startsWith('foreign:')}))];
}
function draw3D(){
 const canvas=$('sceneCanvas'),x=canvas.getContext('2d'),st=editState();
 x.fillStyle='#08111c';x.fillRect(0,0,canvas.width,canvas.height);S.projection=[];
 const source=$('geometryState').value==='baseline'||['gt','sensor_overlay','semantic_2d'].includes(S.channel);
 $('geometryTitle').textContent=source?'30K 原场景参照 · Gaussian / LiDAR':'当前请求 · Gaussian / LiDAR';
 $('geometryStateInfo').textContent=source?'已选择原场景参照；与编辑结果不同。':selected().title+' · 与左侧共用请求、时刻和相机。';
 if(!st?.supported){empty(canvas,st?.note||'本组没有此帧的编辑几何');$('cloudInfo').textContent='未拿原场景替代当前请求。';$('boxInfo').textContent='';$('viewMode').textContent='';return;}
 if(!S.clouds){empty(canvas,'几何加载中');return;}
 if(!S.cameraView)for(let v=-60;v<=100;v+=10){line3(x,[[v,-60,0],[v,60,0]],'#182c40');line3(x,[[-40,v,0],[100,v,0]],'#182c40');}
 const mode=$('cloudColor').value,instances=geometryInstances(),counts={};S.semanticFilterStats={considered:0,hidden:0,unknown:0,vehicle:0,contour:0,static_vehicle:0,base_unknown:0,road_to_unknown:0};
 for(const instance of instances){
  const part=instance.cloud==='static'||S.clouds[instance.cloud]?.branch==='static'?'static':'dynamic';if(!$(part+'3d').checked)continue;
  const cloud=S.clouds[instance.cloud];if(!cloud){empty(canvas,'外来资产几何加载中');return;}
  const {data}=cloud;let count=0;const suppressed=instance.suppressed_rows?new Set(instance.suppressed_rows):null;
  for(let j=0;j<data.ids.length;j++){
   if(suppressed?.has(data.ids[j]))continue;
   const own=ownershipRow(instance,data.ids[j]);if(mode==='ownership'&&own&&!$('owner'+(own.state===2?'U':own.state)).checked)continue;
   const baseSample=sampleBase(cloud,part,j)||(mode==='ownership'&&own?.state===1&&$('allPositive').checked);if(!baseSample&&(!S.sampling||S.sampling.boost==='none'))continue;
   const pt=editedPoint(instance,j);if(!baseSample&&!sampleBoost(pt.p,data.ids[j]))continue;if(pt.marginal<=.05||pt.opacity<.005)continue;
   const p=projection(pt.p);if(!p||p[0]<0||p[0]>=canvas.width||p[1]<0||p[1]>=canvas.height)continue;
   const e=(mode.startsWith('semantic')||st.semantic_render_filter||($('semanticAblation')?.value||'all')!=='all')?semanticRow(instance,j):null;
   if(e){const q=S.semanticFilterStats;q.considered++;if(e.class_id===0)q.unknown++;if(e.class_id>=14&&e.class_id<=19)q.vehicle++;if(e.boundary_abstained)q.contour++;if(e.static_vehicle_quarantined)q.static_vehicle++;if(e.base_class_id===0)q.base_unknown++;if(e.base_class_id===1&&e.class_id===0)q.road_to_unknown++;if(semanticFilterReject(e)){q.hidden++;continue;}}
   const foreign=instance.cloud.startsWith('foreign:');
   x.fillStyle=mode==='target_unknown_v2'?targetUnknownColor(instance,data.ids[j]):mode.startsWith('semantic')?semanticColor(e,mode):mode==='ownership'?(own?['#63b3ff','#4bea9b','#ffb347'][own.state]:'#787f89'):mode==='rgb'?`rgb(${(pt.rgb||Array.from(data.rgb.slice(j*3,j*3+3))).join(',')})`:mode==='branch'?(part==='static'?'#78b0f4':foreign?'#68f2bd':'#ffa85d'):`rgb(${heat(pt.opacity).join(',')})`;
   x.globalAlpha=$('opaquePoints').checked?1:Math.max(0,Math.min(1,pt.opacity));
   const size=Number($('pointSize').value)||2.5;x.fillRect(p[0]-size/2,p[1]-size/2,size,size);
   S.projection.push({x:p[0],y:p[1],part,j,p:pt.p,opacity:pt.opacity,instance:instance.key,cloud:instance.cloud});count++;
  }
  counts[instance.key]=count;
 }
 x.globalAlpha=1;
 // Observed LiDAR is never moved/deleted to impersonate a simulated sensor.
 if($('lidar3d').checked&&S.lidar){x.fillStyle='#54e2e9';for(let j=0;j<S.lidar.depth.length;j++){
  const p=projection(Array.from(S.lidar.xyz.slice(j*3,j*3+3)));if(p&&p[0]>=0&&p[0]<canvas.width&&p[1]>=0&&p[1]<canvas.height){const size=Math.max(1,(Number($('pointSize').value)||2.5)*.65);x.fillRect(p[0]-size/2,p[1]-size/2,size,size);}
 }}
 for(const b of currentBoxes()){
  if(!($('boxes3d').checked&&b.target)&&!($('otherBoxes3d').checked&&!b.target))continue;
  const ps=b.corners_local,color=b.imported?'#68f2bd':b.target?'#ffbf47':'#59a9ff';
  for(let n=0;n<8;n++)for(let j=0;j<3;j++)if(!(n&(1<<j)))line3(x,[ps[n],ps[n|(1<<j)]],color,b.target?2:1);
  const projected=ps.map(projection).filter(Boolean);if(projected.length===8){const xx=Math.min(...projected.map(p=>p[0])),yy=Math.min(...projected.map(p=>p[1]));if(xx<canvas.width&&yy<canvas.height&&Math.max(...projected.map(p=>p[0]))>=0&&Math.max(...projected.map(p=>p[1]))>=0){x.fillStyle=color;x.font='13px monospace';x.fillText(b.label,Math.max(0,xx),Math.max(15,yy-3));}}
 }
 const fr=D.frames[S.raw],cam=st.camera;
 if(!S.cameraView){
  line3(x,raws.map(r=>D.frames[r].c2w.slice(0,3).map(row=>row[3])),'#597794',1);
  const key=source?'reconstruction_30000':S.group,states=Object.values(window.EDIT_GEOMETRY.groups[key]||{}).filter(s=>s.supported);
  line3(x,states.map(s=>s.camera.slice(0,3).map(row=>row[3])),'#5fdfb0',2.5);
  function frustum(c,color){const origin=c.slice(0,3).map(r=>r[3]),k=fr.K,corners=[[0,0],[W,0],[W,H],[0,H]].map(([u,v])=>matp(c,[(u-k[2])/k[0]*3,(v-k[3])/k[1]*3,3]));for(let i=0;i<4;i++){line3(x,[origin,corners[i]],color,2);line3(x,[corners[i],corners[(i+1)%4]],color,2);}}
  frustum(fr.c2w,'#597794');frustum(cam,'#5fdfb0');
  for(const instance of st.objects){const ps=states.map(s=>s.objects.find(o=>o.key===instance.key)?.center_local).filter(Boolean);line3(x,ps,instance.cloud.startsWith('foreign:')?'#68f2bd':'#e4ba73',1.3);}
 }
 // Depth rays follow the same edited optical camera as the saved map.
 if(S.maps&&!source&&selected().frames[S.raw]?.maps){const z=S.maps.depth_m?.[S.pixel[1]*W+S.pixel[0]];if(Number.isFinite(z)){const k=fr.K,p=matp(cam,[(S.pixel[0]+.5-k[2])/k[0]*z,(S.pixel[1]+.5-k[3])/k[1]*z,z]);line3(x,[cam.slice(0,3).map(r=>r[3]),p],'#ff92ba',2);}}
 const inst=S.selected&&instances.find(o=>o.key===S.selected.instance);
 if(inst){
  const {j}=S.selected,d=S.clouds[inst.cloud].data,pt=editedPoint(inst,j),p=projection(pt.p);
  if(p){x.strokeStyle='#ff8cbd';x.lineWidth=2;x.beginPath();x.arc(p[0],p[1],7,0,Math.PI*2);x.stroke();}
  for(const axes of [[0,1],[0,2],[1,2]]){const pts=[];for(let t=0;t<=48;t++){const a=t/48*2*Math.PI,offset=[0,1,2].map(k=>d.rotation[j*9+k*3+axes[0]]*d.scales[j*3+axes[0]]*Math.cos(a)+d.rotation[j*9+k*3+axes[1]]*d.scales[j*3+axes[1]]*Math.sin(a));const v=inst.transform?[0,1,2].map(k=>offset.reduce((s,x,i)=>s+inst.transform[k][i]*x,0)):offset;pts.push(pt.p.map((p,k)=>p+v[k]));}line3(x,pts,'#ff8cbd');}
  $('gaussianInfo').textContent=`${inst.label} · ${inst.source_context||D.context} · checkpoint 行 ${d.ids[j]} · 当前编辑位置米 (${pt.p.map(v=>fmt(v,2)).join(', ')}) · opacity ${fmt(pt.opacity)} · 时间 ${fmt(inst.query_time,3)}。椭球方向使用相同刚体旋转；不是像素贡献排名。`+(mode==='ownership'?(()=>{const v=ownershipRow(inst,d.ids[j]);return v?` 候选 ${v.state===2?'unknown':v.state}；目标证据 ${v.target_hits} 帧，非目标证据 ${v.other_hits} 帧（候选需要 ≥3 帧、覆盖 ≥2 时间段且无反证）。`:' 候选未加载';})():'');
  /* target-unknown-selected */
  if(mode==='target_unknown_v2'){const a=S.targetUnknown,k=inst.cloud==='static'&&a?sparseIndex(a.ids,d.ids[j]):-1,ad=S.staticAdapters?.[inst.static_adapter],ai=ad?sparseIndex(ad.ids,d.ids[j]):-1;$('gaussianInfo').textContent+=k>=0?` V2证据状态 ${['背景深度支持（未核验静止）','车辆候选','目标unknown','混合支撑'][a.role[k]]}；目标支持 ${a.target_frames[k]} 帧，背景深度支持 ${a.background_frames[k]} 帧。`:' V2：此目标之外，或新增实证背景补层（语义仍unknown）。';if(ai>=0)$('gaussianInfo').textContent+=` 实际学习保留率 ${fmt(ad.opacity_factor[ai])}，不是身份概率。`;}
  if(mode.startsWith('semantic'))$('gaussianInfo').textContent+=' 语义观测：'+JSON.stringify(semanticRow(inst,j));
 }else $('gaussianInfo').textContent='点击几何点查看真实 checkpoint 行号、编辑后位置和查询时间。';
 x.fillStyle='#9fb5d1';x.font='12px monospace';x.fillText('EDIT STATE · grid 10 m · Gaussian samples · no RGB backdrop',12,canvas.height-13);
 $('pointSizeValue').textContent=Number($('pointSize').value).toFixed(1)+' px';
 $('viewMode').textContent=S.cameraView?(S.cameraReference==='original'?'原相机观察当前几何（显式对照）':'当前请求相机 · 与左侧原生输出同投影'):'三维总览 · 绿线/视锥为当前请求相机 · 蓝灰为原相机';
 if(mode==='target_unknown_v2')$('ownershipStatus').textContent='V2目标专属证据：橙=目标相关但未分清；紫=目标与真实背景混合；蓝=重复背景深度支持（未核验静止）；灰=此目标之外。青=新增实证背景补层（语义仍unknown）。渲染保留率不是身份概率。';if(mode==='ownership')$('ownershipStatus').textContent='1 绿色：目标候选；0 蓝色：非目标候选；unknown 橙色。灰色：尚未加载证据。以当前查询帧显示中心；标签来自全49帧证据。不是像素贡献真值。';
 if($('semanticFilterStatus')){const q=S.semanticFilterStats;$('semanticFilterStatus').textContent=`当前画内抽样中心：unknown ${q.unknown}（基础低置信/混合 ${q.base_unknown}，轮廓规则 ${q.contour}，静态车影候选 ${q.static_vehicle}；原因可重叠），车辆类 ${q.vehicle}，本开关隐藏 ${q.hidden}。road→unknown ${q.road_to_unknown}。不是全模型比例。仅右侧几何预览；左侧RGB未重渲染，不能据此判定残影已剥离。`;}
 semanticLegend();if($('geometryColorLegend'))$('geometryColorLegend').textContent=mode==='target_unknown_v2'?'V2颜色：橙=目标相关未分清；紫=目标/背景混合；蓝=重复背景深度支持（未核验静止）；灰=此目标之外；青=新增背景补层。保留率不是身份概率。':mode==='semantic_unknown_reason'?'unknown来源：灰=基础低置信/混合；黄=额外轮廓带；橙=跨帧静态车影候选；蓝=本帧无贡献证据。多原因优先显示橙/黄，其余类别暗显。':mode.startsWith('semantic')?'语义：亮绿=car×dynamic，深绿=car×static，浅灰=unknown；紫=road。static是原渲染分支，不是背景语义。橙框=所选目标，蓝框=其他原始车辆。':mode==='opacity'?'色标为有效opacity；关闭不透明标记时按实际点opacity显示。点opacity不等于像素alpha*T，可切换二维覆盖率与可见比例。':mode==='ownership'?'归属候选：绿1，蓝0，橙unknown；原branch与语义分别保留。':'蓝=原static分支，橙=目标dynamic分支，青=原LiDAR；橙框目标，蓝框其他原始车辆。';const count=IA?.frames[S.raw].visible_count;
 $('boxInfo').textContent=`当前有效资产框 ${st.objects.length} 个${count!==undefined?'；原帧 '+count+' 个车辆标注与前视相交':''}。目标框随资产平移、旋转或删除；其他蓝框是原始观测标注，不代表独立资产。`;
 const sampling=instances.map(o=>{const c=S.clouds[o.cloud];return c?`${o.label}：${c.sample.toLocaleString()}/${c.total.toLocaleString()} 行（${(100*c.sample/c.total).toFixed(2)}%）`:'';}).filter(Boolean).join('；');
 $('cloudInfo').textContent=`当前组几何加载量：${sampling}。加载量不等于显示量；显示采样见上方配置。中心点不是完整高斯表面。当前画内 ${Object.entries(counts).map(([k,n])=>k+': '+n).join(' / ')}。${$('lidar3d').checked?'青色 LiDAR 保持原始实测状态，不是编辑后传感器输出。':''} ${st.note||''}${S.channel==='generated'?' 右侧是视频后处理之前的三维状态。':''}`;
}

// Exact checkpoint population, streamed only when the user applies rates.
window.CLOUD_CHUNKS=window.CLOUD_CHUNKS||{};
const fullCloudCache=new Map();
function rowFraction(id){return ((id+1)*0.6180339887498949)%1;} // Stable low-discrepancy row sampling; same subset at the same rate.
async function fullCloud(context,part){
 const key=context+':'+part;if(fullCloudCache.has(key))return fullCloudCache.get(key);
 const promise=(async()=>{
  const prefix=context===D.context?'':'../'+context+'/';
  await loadScript(prefix+'cloud_full_manifest.js');
  const meta=window.FULL_CLOUD_MANIFEST[part],out={};
  for(let i=0;i<meta.chunks.length;i++){
   const chunk=meta.chunks[i];$('samplingStatus').textContent=`加载 ${context.slice(0,6)} ${part}：${i+1}/${meta.chunks.length} 块`;
   await loadScript(prefix+chunk.path);const data=await unpack(window.CLOUD_CHUNKS[chunk.path]);delete window.CLOUD_CHUNKS[chunk.path];
   for(const [k,v] of Object.entries(data)){const stride=v.length/chunk.rows;if(!out[k])out[k]=new v.constructor(meta.total*stride);out[k].set(v,chunk.start*stride);}
  }
  return {...meta,sample:meta.total,data:out,fullPopulation:true};
 })();fullCloudCache.set(key,promise);try{return await promise;}catch(e){fullCloudCache.delete(key);throw e;}
}
async function applySampling(){
 if(S.samplingLoading)return;S.samplingLoading=true;$('applySampling').disabled=true;
 try{
  const settings={static:Number($('staticRate').value),dynamic:Number($('dynamicRate').value),target:Number($('targetRate').value),boost:$('targetBoost').value};
  for(const k of ['static','dynamic','target'])if(!Number.isFinite(settings[k])||settings[k]<0||settings[k]>100)throw Error('采样率须在 0—100% 内');
  for(const part of ['static','dynamic'])S.clouds[part]=await fullCloud(D.context,part);
  for(const instance of geometryInstances())if(instance.cloud.startsWith('foreign:'))S.clouds[instance.cloud]=await fullCloud(instance.source_context,'dynamic');
  S.sampling=settings;S.selected=null;draw3D();
  $('samplingStatus').textContent=`已应用全模型确定性采样：静态 ${settings.static}% · 动态 ${settings.dynamic}% · ${settings.boost==='none'?'不单独加密':'框邻域 '+settings.target+'%'}。100% 不抽行；时间/opacity 门限仍生效。`;
 }catch(e){$('samplingStatus').textContent='未应用：'+e.message;}finally{S.samplingLoading=false;$('applySampling').disabled=false;}
}
function sampleBase(cloud,part,j){
 if(!S.sampling||!cloud.fullPopulation)return true;
 return rowFraction(cloud.data.ids[j])<S.sampling[part]/100;
}
function sampleBoost(pt,id){
 if(!S.sampling||S.sampling.boost==='none'||rowFraction(id)>=S.sampling.target/100)return false;
 // Display-only oriented target-box neighborhood, never ownership or point removal.
 for(const b of currentBoxes().filter(b=>b.target)){
  const q=b.corners_local,delta=pt.map((v,k)=>v-q[0][k]);let inside=true;
  for(const i of [1,2,4]){const e=q[i].map((v,k)=>v-q[0][k]),len=Math.hypot(...e);const d=delta.reduce((s,v,k)=>s+v*e[k],0)/len;if(d< -1||d>len+1){inside=false;break;}}
  if(inside)return true;
 }
 return false;
}
function ownershipRow(instance,id){
 if(!instance)return null;
 if(instance.cloud.startsWith('v43:'))return null; // Different row namespace; never reuse old 30K labels.
 const context=instance.cloud.startsWith('foreign:')?instance.source_context:D.context;
 const part=instance.cloud==='static'?'static':'dynamic',a=S.ownership?.[context]?.[part];
 return a?{state:a[id*3],target_hits:a[id*3+1],other_hits:a[id*3+2],context,row:id}:null;
}
async function loadOwnership(){
 try{
  S.ownership=S.ownership||{};window.OWNERSHIP_DATA=window.OWNERSHIP_DATA||{};
  const contexts=new Set([D.context,...geometryInstances().filter(o=>o.cloud.startsWith('foreign:')).map(o=>o.source_context)]);
  for(const context of contexts){if(S.ownership[context])continue;await loadScript((context===D.context?'':'../'+context+'/')+'ownership_candidates.js');
   const raw=window.OWNERSHIP_DATA[context];S.ownership[context]={};for(const part of ['static','dynamic'])S.ownership[context][part]=(await unpack(raw[part])).values;
  }
  $('cloudColor').value='ownership';await applySampling();draw3D();
 }catch(e){$('ownershipStatus').textContent='候选未加载：'+e.message;}
}

// Same observed pixels, separate original/new row namespaces. Abstention is a prior.
async function ensureBoundarySemantic(){
 if(!window.V43_BADCASE_AVAILABLE)return;
 if(!window.BOUNDARY_INDEX)await loadScript('gpu_semantics/boundary_index.js');
 if(window.BOUNDARY_INDEX.unknown_candidates&&!window.STATIC_UNKNOWN_CANDIDATES)await loadScript(window.BOUNDARY_INDEX.unknown_candidates);
 const raw=S.raw;S.boundaryFrames=S.boundaryFrames||new Map();
 if(!S.boundaryFrames.has(raw)){
  await loadScript(window.BOUNDARY_INDEX.frames[raw]);const b=window.BOUNDARY_FRAMES[raw],value={};
  for(const key of ['original','actor10k','image'])value[key]=await unpack(b[key]);
  delete window.BOUNDARY_FRAMES[raw];S.boundaryFrames.set(raw,value);if(S.boundaryFrames.size>4){const old=S.boundaryFrames.keys().next().value;S.boundaryFrames.delete(old);scriptCache.delete(window.BOUNDARY_INDEX.frames[old]);}
 }
}
function boundarySemanticRow(instance,j){
 const frame=S.boundaryFrames?.get(S.raw);if(!frame)return null;
 const newer=instance.cloud.startsWith('v43:')||(instance.cloud==='static'&&S.group.startsWith('v43_')&&S.group!=='v43_main_noedit');
 const variant=newer?'actor10k':'original',a=frame[variant],ns=window.BOUNDARY_INDEX.branch_sizes[variant][0],part=instance.cloud==='static'?'static':'dynamic';
 if(!['static','dynamic'].includes(instance.cloud)&&!instance.cloud.startsWith('v43:'))return null;
 const row=S.clouds[instance.cloud].data.ids[j],id=row+(part==='dynamic'?ns:0),idx=sparseIndex(a.ids,id);
 if(idx<0)return {class_id:0,branch:part,map_version:window.BOUNDARY_INDEX.version,unknown_reasons:['no_visible_evidence'],evidence_state:'no_visible_evidence',reason:'当前原始观测帧没有足够可见贡献，保留 unknown'};
 const pinned=editState()?.semantic_render_filter,radius=pinned?pinned.radius:Number($('semanticBoundary')?.value||0),col=window.BOUNDARY_INDEX.radii.indexOf(radius),fraction=col<0?0:a.boundary_fraction[idx*3+col],threshold=pinned?pinned.fraction:Number($('semanticBoundaryMass')?.value||.2),abstain=col>=0&&fraction>=threshold,base=a.class_id[idx];
 const candidates=window.STATIC_UNKNOWN_CANDIDATES,ci=part==='static'&&candidates?sparseIndex(candidates.ids,row):-1,quarantine=ci>=0&&(pinned?true:!!$('semanticStaticUnknown')?.checked);
 const dep=S.gpuDepthFrames?.get(S.raw),di=dep&&variant==='original'?sparseIndex(dep.ids,id):-1,rms=di>=0?dep.rms_depth_m[di]:null;
 const reasons=[];if(base===0)reasons.push('low_confidence_or_mixed');if(abstain)reasons.push('contour_band');if(quarantine)reasons.push('static_vehicle_appearance');const k=reasons.length?0:base;
 return {class_id:k,base_class_id:base,class_name:GPU_SEMANTIC_NAMES[k],branch:part,motion_model:part==='static'?'original_static_batch_SHM_and_temporal_opacity':newer?'rigid_ActorTrack':'time_weighted_per_Gaussian_motion',evidence_state:reasons.length?reasons.join('+'):'prediction_and_visible_contribution',unknown_reasons:reasons,map_version:window.BOUNDARY_INDEX.version,row_namespace:variant==='actor10k'&&part==='dynamic'?'V43 measured Actor-local':'V42 original static/dynamic',semantic_source_checkpoint:newer?'V43 Actor10K no-edit observation':'V42 30K no-edit observation',contribution_alpha_mass:a.mass[idx],semantic_evidence_purity:a.purity[idx],target_mask_fraction:a.target_fraction[idx],vehicle_semantic_fraction:a.vehicle_fraction[idx],boundary_px:radius,boundary_contribution_fraction:fraction,boundary_abstained:abstain,static_vehicle_quarantined:quarantine,static_vehicle_support_frames:ci>=0?candidates.evidence[ci].frames:[],assigned_instance_id:part==='dynamic'?D.target_track:'unknown / 原static批次混合支撑',assignment_source:part==='static'?'原static批次，车辆外观候选未确认实例':newer?'核验实测目标点重建资产':'原dynamic批次标签，不等于逐行物理归属证明',target_LiDAR_RMS_depth_m:rms,depth_status:rms===null?'missing':rms<=.5?'compatible':rms>1?'incompatible':'uncertain',conflict_candidate:part==='static'&&a.target_fraction[idx]>.05&&rms!==null&&rms<=.5,vehicle_appearance_candidate:ci>=0,reason:quarantine?'跨49帧发现静态行参与目标车辆外观，先暂缓为unknown；不是纯车辆身份或安全删除证明':abstain?'可见贡献进入所有车辆轮廓内外带（包括路面一侧）；原owner不变':base===0?'二维置信或跨类别混合支撑不足，关闭额外轮廓带仍保留unknown':'观测语义随行携带到编辑；不是编辑后新权重或语义GT'};
}
function semanticFilterReject(e){
 const mode=$('semanticAblation')?.value||'all',unknown=!e||e.class_id===0,vehicle=!!e&&(e.map_version?e.class_id>=14&&e.class_id<=19:e.class_id===1);
 const pinned=editState()?.semantic_render_filter?.mode;return [mode,pinned].some(m=>(['hide_unknown','hide_both'].includes(m)&&unknown)||(['hide_vehicle','hide_both'].includes(m)&&vehicle));
}

// Read-only observational semantics. Never change renderer branch or owner.
const SEMANTIC_MAP={0:'unknown / 未取得类别证据',1:'vehicle / 车辆（当前仅目标车掩码）',2:'road / 道路',3:'sidewalk / 人行道',4:'building / 建筑',5:'vegetation / 植被',6:'sky / 天空',7:'pole-sign / 杆与标牌',8:'person-cycle / 行人与骑行者'};
const GPU_SEMANTIC_NAMES=['unknown','road / 道路','sidewalk / 人行道','building / 建筑','wall / 墙','fence / 围栏','pole / 杆','traffic light / 信号灯','traffic sign / 标牌','vegetation / 植被','terrain / 地形','sky / 天空','person / 行人','rider / 骑行者','car / 小汽车','truck / 卡车','bus / 客车','train / 轨道车','motorcycle / 摩托车','bicycle / 自行车'];
const GPU_SEMANTIC_COLORS=['#c8cdd4','#804080','#f423e8','#7e7e7e','#66669c','#be9999','#b2b2b2','#faaa1e','#dcdc00','#6b8e23','#98fb98','#4682b4','#dc143c','#ff0000','#2de5aa','#3c42ba','#0084a0','#008064','#0000e6','#770b20'];
async function ensureGPUSemantic(){
 if(!window.GPU_SEMANTIC_INDEX)await loadScript('gpu_semantics/index.js');
 S.gpuSemanticFrames=S.gpuSemanticFrames||new Map();const raw=S.raw;
 if(!S.gpuSemanticFrames.has(raw)){
  const entry=window.GPU_SEMANTIC_INDEX.frames[raw];if(!entry)throw Error('该源帧没有 GPU 贡献证据');
  await loadScript(entry.path);const value=await unpack(window.GPU_SEMANTIC_FRAMES[raw]);
  S.gpuSemanticFrames.set(raw,value);if(S.gpuSemanticFrames.size>6)S.gpuSemanticFrames.delete(S.gpuSemanticFrames.keys().next().value);
 }
 if(window.GPU_SEMANTIC_INDEX.depth_available){
  if(!window.GPU_DEPTH_INDEX)await loadScript('gpu_semantics/depth_index.js');
  S.gpuDepthFrames=S.gpuDepthFrames||new Map();if(!S.gpuDepthFrames.has(raw)){await loadScript(window.GPU_DEPTH_INDEX.frames[raw]);S.gpuDepthFrames.set(raw,await unpack(window.GPU_DEPTH_FRAMES[raw]));if(S.gpuDepthFrames.size>6)S.gpuDepthFrames.delete(S.gpuDepthFrames.keys().next().value);}
 }
}
function sparseIndex(ids,id){let lo=0,hi=ids.length-1;while(lo<=hi){const mid=(lo+hi)>>1;if(ids[mid]===id)return mid;if(ids[mid]<id)lo=mid+1;else hi=mid-1;}return -1;}
function gpuSemanticRow(instance,j){
 const boundary=boundarySemanticRow(instance,j);if(boundary)return boundary;
 const part=instance.cloud==='static'?'static':'dynamic',a=S.gpuSemanticFrames?.get(S.raw),index=window.GPU_SEMANTIC_INDEX;
 if(instance.cloud.startsWith('v43:'))return {class_id:0,class_name:'unknown / 新资产逐行贡献语义尚未加载',branch:'dynamic',map_version:'measured-actor-seed-v1',instance_id:D.target_track,source_status:'原始实测点及已核验目标掩码；局部刚体结构组',reason:'新行空间，原30K unknown标签不复用；不是unknown学习结果'};
 if(!a||!index||!['static','dynamic'].includes(instance.cloud))return {class_id:0,branch:part,reason:'没有此资产的原始 GPU 贡献观测',map_version:'cityscapes19-plus-unknown-v1'};
 const row=S.clouds[instance.cloud].data.ids[j],id=row+(part==='dynamic'?index.branch_sizes[0]:0),found=sparseIndex(a.ids,id);
 if(found<0)return {class_id:0,branch:part,reason:'该源帧没有足够可见贡献；不能当非车辆',map_version:index.version};
 const k=a.class_id[found],target=a.target_fraction[found],dep=S.gpuDepthFrames?.get(S.raw),jdep=dep?sparseIndex(dep.ids,id):-1,rms=jdep>=0?dep.rms_depth_m[jdep]:null;
 return {class_id:k,class_name:GPU_SEMANTIC_NAMES[k],branch:part,map_version:index.version,contribution_alpha_mass:a.mass[found],semantic_evidence_purity:a.purity[found],target_mask_fraction:target,vehicle_semantic_fraction:a.vehicle_fraction[found],target_LiDAR_RMS_depth_m:rms,target_return_alpha_mass:jdep>=0?dep.return_mass[jdep]:null,depth_status:rms===null?'missing':rms<=.5?'compatible':rms>1?'incompatible':'uncertain',conflict_candidate:part==='static'&&target>.05&&rms!==null&&rms<=.5,reason:'原V42 30K、原相机原时刻的 alpha*T 证据；同像素实测深度只作支持，不是三维身份真值或当前编辑权重'};
}
function drawSemanticImage(){
 const a=S.gpuSemanticFrames?.get(S.raw);if(!a){empty($('renderCanvas'),'GPU 语义图未加载');return;}
 const x=$('renderCanvas').getContext('2d'),image=x.createImageData(W,H);
 for(let i=0;i<W*H;i++){const band=S.boundaryFrames?.get(S.raw)?.image,rad=Number($('semanticBoundary')?.value||0),bi=[3,5,8].indexOf(rad),unknown=band&&bi>=0&&band.bands[bi*W*H+i];const color=GPU_SEMANTIC_COLORS[unknown?0:a.semantic_image[i]],rgb=[1,3,5].map(k=>parseInt(color.slice(k,k+2),16));image.data.set([...rgb,255],i*4);}
 x.putImageData(image,0,0);cross(x,W,H);$('mapLegend').textContent='原始实拍的 SegFormer-B0 语义预测；置信门限0.65；标签不是 GT，也不随反事实编辑移动。';
}
async function ensureSemantic(){
 if(S.channel==='semantic_2d'||editState()?.semantic_render_filter||($('semanticProfile').value==='gpu'&&($('cloudColor').value.startsWith('semantic')||($('semanticAblation')?.value||'all')!=='all'))){await ensureGPUSemantic();await ensureBoundarySemantic();return;}
 if(!['semantic','semantic_branch','semantic_conflict'].includes($('cloudColor').value))return;
 if(!window.SEMANTIC_OBSERVATIONS)await loadScript('semantic_observations.js');
 S.semanticFrames=S.semanticFrames||new Map();
 const raw=S.raw;if(!S.semanticFrames.has(raw)){
  const a=await unpack(window.SEMANTIC_OBSERVATIONS[raw]);
  // Nearest observed return inside a configurable pixel neighborhood, not filled depth GT.
  const nearest=new Float32Array(W*H);nearest.fill(NaN);const distance=new Uint8Array(W*H);distance.fill(255);
  for(let i=0;i<W*H;i++)if(Number.isFinite(a.lidar_z[i])){const u=i%W,v=(i/W)|0;for(let dy=-5;dy<=5;dy++)for(let dx=-5;dx<=5;dx++){const d=dx*dx+dy*dy;if(d>25||u+dx<0||u+dx>=W||v+dy<0||v+dy>=H)continue;const q=i+dy*W+dx;if(d<distance[q]){distance[q]=d;nearest[q]=a.lidar_z[i];}}}
  S.semanticFrames.set(raw,{...a,nearest,distance});
 }
}
function semanticRow(instance,j){
 if(S.clouds[instance.cloud]?.row_namespace==='v43_measured_background')return {class_id:0,branch:'static',map_version:'measured-world-background-v1',reason:'跨帧实证背景或受限表面插值补层；没有重新语义归因，保留unknown。'};
 if(instance.cloud.startsWith('v43:'))return gpuSemanticRow(instance,j);
 if($('semanticProfile').value==='gpu'||editState()?.semantic_render_filter)return gpuSemanticRow(instance,j);
 const part=instance.cloud==='static'?'static':'dynamic',a=S.semanticFrames?.get(S.raw);
 if(!a||instance.cloud.startsWith('foreign:'))return {class_id:0,branch:part,reason:'无此资产的语义观测，保留 unknown'};
 // Evaluate original geometry with original observed camera. Carry the evidence with the row into edits.
 const c=S.clouds[instance.cloud],p=cloudPoint(c.data,j,c.cycle,D.frames[S.raw].model_time),fr=D.frames[S.raw],M=fr.c2w,d=p.p.map((v,k)=>v-M[k][3]);
 const cam=[0,1,2].map(k=>d.reduce((s,v,n)=>s+v*M[n][k],0));
 if(cam[2]<=.1)return {class_id:0,branch:part,reason:'原始观测相机背后'};
 const K=fr.K,u=Math.floor(K[0]*cam[0]/cam[2]+K[2]),v=Math.floor(K[1]*cam[1]/cam[2]+K[3]);
 if(u<0||u>=W||v<0||v>=H)return {class_id:0,branch:part,reason:'原始观测视野外'};
 const i=v*W+u,mask=!!a.mask[i],sigma=Math.max(...c.data.scales.slice(j*3,j*3+3)),radius=Number($('semanticRadius').value),tol=Number($('semanticDepth').value),maxSigma=Number($('semanticSigma').value),profile=$('semanticProfile').value;
 const depth=radius===0?a.lidar_z[i]:(a.distance[i]<=radius*radius?a.nearest[i]:NaN),depthOK=Number.isFinite(depth)&&Math.abs(cam[2]-depth)<=tol;
 const accepted=mask&&(profile==='projection'||(sigma<=maxSigma&&depthOK));
 return {class_id:accepted?1:0,branch:part,mask_hit:mask,depth_consistent:depthOK,depth_delta_m:Number.isFinite(depth)?cam[2]-depth:null,max_sigma_m:sigma,profile,reason:accepted?(profile==='projection'?'目标车掩码中心投影；遮挡与深度未核验':'掩码与稀疏 LiDAR 深度候选一致；贡献仍待 GPU 核验'):(mask?'掩码投影命中但深度/尺度证据不足':'无此点类别证据；不自动归背景'),conflict_candidate:accepted&&part==='static'};
}
function semanticColor(e,mode){
 if(mode==='semantic_unknown_reason'){if(e.class_id)return '#24384a';if(e.static_vehicle_quarantined)return '#ffa64d';if(e.boundary_abstained)return '#f5dc62';return e.base_class_id===0?'#c8cdd4':'#77b7ff';}
 if(mode==='semantic_conflict'){if(e.conflict_candidate)return '#ff4fd2';if(e.branch==='static'&&e.target_mask_fraction>.05)return e.depth_status==='incompatible'?'#56c7e8':'#f0b64b';return '#374658';}
 if(e.map_version){if(!e.class_id)return '#c8cdd4';const c=GPU_SEMANTIC_COLORS[e.class_id];if(mode==='semantic')return c;const rgb=[1,3,5].map(k=>parseInt(c.slice(k,k+2),16)),factor=e.branch==='static'?.65:1;return `rgb(${rgb.map(v=>Math.round(v*factor)).join(',')})`;}
 if(!e.class_id)return '#c8cdd4';
 return mode==='semantic'?'#4df3c4':e.branch==='static'?'#ff4fd2':'#42e8a2';
}
function semanticLegend(){
 const mode=$('cloudColor').value;if(!mode.startsWith('semantic'))return;
 if($('semanticProfile').value==='gpu'){$('semanticStatus').textContent='GPU map v2（与旧 CPU map 编码分开）：'+GPU_SEMANTIC_NAMES.map((n,i)=>i+' '+n).join('；')+'。联合着色：同类别静态较暗、动态较亮；浅灰 unknown；绿色 car，静态car为深绿、动态car为亮绿。同一高斯可以是car语义＋原static分支，不能把分支当语义。目标支持模式：洋红=静态参与目标且实测深度相容（候选）；青=与实测车深差>1m；黄=缺测/未定，不能整颗直接删。证据源为原V42 30K，不是当前编辑重新计算的权重；原 owner 不变。';return;}
 $('semanticStatus').textContent='当前模式：'+($('semanticProfile').value==='projection'?'仅二维掩码中心投影（弱候选）':'掩码＋LiDAR 邻域深度＋尺度（候选）')+'。绿=vehicle×原动态分支；洋红=vehicle×原静态分支，提示目标表达跨分支；灰蓝=unknown×静态；灰白=unknown×动态。静态车辆可为停放车，不能只凭 vehicle×static 判错。当前只有已审阅目标车掩码，其他车辆/道路等尚无密集语义；框不生成语义。';
}
async function enableSemantics(){try{if(($('semanticAblation')?.value||'all')!=='all')$('semanticProfile').value='gpu';await ensureSemantic();S.selected=null;if(S.channel==='semantic_2d')drawSemanticImage();draw3D();semanticLegend();}catch(e){$('semanticStatus').textContent='语义观测未加载：'+e.message;}}

function targetUnknownColor(instance,row){
 if(S.clouds[instance.cloud]?.row_namespace==='v43_measured_background')return '#55ddd5';
 if(instance.cloud!=='static')return '#35dc98';
 const a=S.targetUnknown,i=a?sparseIndex(a.ids,row):-1;return i<0?'#465568':['#559bdf','#35dc98','#ffad45','#df6bc7'][a.role[i]];
}

function drawBEV(){
 const c=$('bevCanvas'),x=c.getContext('2d'),g=selected(),base=raws.map(r=>D.frames[r]),states=Object.values(window.EDIT_GEOMETRY?.groups[S.group]||{}).filter(s=>s.supported);
 const points=base.flatMap(f=>[f.target_center,f.c2w.slice(0,3).map(r=>r[3])]);states.forEach(s=>{points.push(s.camera.slice(0,3).map(r=>r[3]));s.objects.forEach(o=>points.push(o.center_local));});
 const xmin=Math.min(...points.map(p=>p[0]))-8,xmax=Math.max(...points.map(p=>p[0]))+8,ymin=Math.min(...points.map(p=>p[1]))-8,ymax=Math.max(...points.map(p=>p[1]))+8,k=Math.min((c.height-45)/(xmax-xmin),(c.width-60)/(ymax-ymin));
 const pr=p=>[c.width/2-(p[1]-(ymin+ymax)/2)*k,c.height-22-(p[0]-xmin)*k];x.fillStyle='#08111c';x.fillRect(0,0,c.width,c.height);x.strokeStyle='#1d344b';x.fillStyle='#6885a2';x.font='11px monospace';
 for(let v=Math.ceil(xmin/10)*10;v<xmax;v+=10){const p=pr([v,ymin]);x.beginPath();x.moveTo(0,p[1]);x.lineTo(c.width,p[1]);x.stroke();x.fillText(v+'m',5,p[1]-4);}
 function line(ps,color){x.strokeStyle=color;x.lineWidth=2;x.beginPath();ps.forEach((p,i)=>{const q=pr(p);i?x.lineTo(...q):x.moveTo(...q);});x.stroke();}
 function dot(p,color){const q=pr(p);x.fillStyle=color;x.beginPath();x.arc(...q,4,0,Math.PI*2);x.fill();}
 line(base.map(f=>f.target_center),'#f8b467');line(base.map(f=>f.c2w.slice(0,3).map(r=>r[3])),'#79baff');
 line(states.map(s=>s.camera.slice(0,3).map(r=>r[3])),'#5fdfb0');
 const keys=new Set(states.flatMap(s=>s.objects.map(o=>o.key)));for(const key of keys)line(states.map(s=>s.objects.find(o=>o.key===key)?.center_local).filter(Boolean),'#5fdfb0');
 const st=window.EDIT_GEOMETRY?.groups[S.group]?.[S.raw],fr=D.frames[S.raw];dot(fr.target_center,'#f8b467');dot(fr.c2w.slice(0,3).map(r=>r[3]),'#79baff');
 let msg='首帧车体系，米。';if(st?.supported){dot(st.camera.slice(0,3).map(r=>r[3]),'#5fdfb0');st.objects.forEach(o=>dot(o.center_local,'#5fdfb0'));const delta=Math.hypot(...st.camera.slice(0,3).map((r,i)=>r[3]-fr.c2w[i][3]));msg+=`当前相机离原轨迹 ${fmt(delta,3)} m；世界时间 ${fmt(st.world_time,3)}，资产查询时间 ${st.objects.map(o=>fmt(o.query_time,3)).join(' / ')||'已删除'}。`;}
 const audit=window.EDIT_GEOMETRY?.benchmark_camera_audit.find(a=>a.group===S.group);if(audit)msg+=`整段相机路程 ${fmt(audit.camera_path_length_m,2)} m，最大改道 ${fmt(audit.max_camera_offset_from_original_m,2)} m，最大朝向差 ${fmt(audit.max_camera_rotation_from_original_deg,2)}°。`;
 $('requestInfo').textContent=msg+' 轨迹为已执行的几何请求；未验证车辆运动学、道路支撑和完整避碰。';
}
function trainTable(){const table=el('table'),head=el('thead'),tr=el('tr');['节点','完整图 PSNR','完整图 SSIM','完整图 LPIPS','评价图'].forEach(t=>tr.append(el('th',{},t)));head.append(tr);table.append(head);const body=el('tbody');for(const cp of D.checkpoints){const row=el('tr');row.append(el('td',{},(cp.iteration/1000)+'K'));const m=cp.metrics;for(const key of ['psnr','ssim','lpips']){let val=m[key]??m[key.toUpperCase()];if(typeof val!=='number')val=null;row.append(el('td',{},fmt(val,key==='psnr'?3:5)));}const td=el('td'),a=el('a',{href:'evidence/reconstruction_'+cp.iteration+'_metrics.json',target:'_blank'},'49 帧原始指标');td.append(a);row.append(td);body.append(row);}table.append(body);$('trainingTable').append(table);}
function selectGroup(id){if(!allGroups[id])return;setCategory(allGroups[id].category,id);show();if(S.sampling){if($('cloudColor').value==='ownership')loadOwnership();else applySampling();}}
function persist(){const data={schema:'scene-diagnostic-v1',context:D.context,group:S.group,channel:S.channel,raw:S.raw,pixel:S.pixel,note:$('caseNote').value,sampling:S.sampling||null,color_mode:$('cloudColor').value,semantic_parameters:{boundary_px:Number($('semanticBoundary').value),boundary_fraction:Number($('semanticBoundaryMass').value),static_vehicle_unknown:$('semanticStaticUnknown').checked,geometry_ablation:$('semanticAblation').value,profile:$('semanticProfile').value,radius_px:Number($('semanticRadius').value),depth_m:Number($('semanticDepth').value),max_sigma_m:Number($('semanticSigma').value)},selected_gaussian:S.selected?{cloud:S.selected.cloud,row:S.clouds[S.selected.cloud].data.ids[S.selected.j],instance:S.selected.instance,position_m:S.selected.p}:null,ownership_candidate:S.selected?ownershipRow(geometryInstances().find(o=>o.key===S.selected.instance),S.clouds[S.selected.cloud].data.ids[S.selected.j]):null,semantic_observation:S.selected?semanticRow(geometryInstances().find(o=>o.key===S.selected.instance),S.selected.j):null,ownership_review:$('ownershipReview').value,exported_utc:new Date().toISOString(),quality_accepted:false,human_verdict:null};const a=el('a',{href:URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'})),download:`diagnostic_${D.context}_raw${S.raw}.json`});a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);}
function step(delta){const valid=Object.keys(selected().frames).map(Number).sort((a,b)=>a-b),i=valid.indexOf(S.raw);S.raw=valid[(Math.max(0,i)+delta+valid.length)%valid.length];show();}
function initV43Focus(){
 if($('boundaryTools'))$('boundaryTools').hidden=!window.V43_BADCASE_AVAILABLE;
 const panel=$('v43Focus');if(!panel||!allGroups.v43_actor_10000)return;panel.hidden=false;
 const actions=[['默认无编辑主通路','v43_main_noedit','rgb'],['新车身 10K','v43_actor_10000','rgb'],['旧资产 30K','reconstruction_30000','rgb'],['新车身独立','v43_actor_10000','dynamic'],['新转向','v43_motion_turn_left15','rgb'],['旧转向','motion_turn_left15','rgb'],['新横移','v43_motion_translate_lateral_1m','rgb'],['旧横移','motion_translate_lateral_1m','rgb'],['横移3米','v43_shift_3m','rgb'],['不透明度对照','v43_density2_turn','rgb'],['静态车影抑制对照','v43_static_affinity_20','rgb'],['删除后残影','v43_motion_delete_target','rgb'],['原静态车辆支持','reconstruction_30000','rgb','semantic_conflict']];
 for(const [label,id,channel,color] of actions){if(!allGroups[id])continue;const button=el('button',{},label);button.onclick=async()=>{S.channel=channel;S.cameraView=true;S.cameraReference='current';$('geometryState').value='current';$('static3d').checked=channel!=='dynamic';$('dynamic3d').checked=true;$('cloudColor').value=color||'branch';setCategory(allGroups[id].category,id);const valid=Object.keys(allGroups[id].frames).map(Number);if(!valid.includes(S.raw))S.raw=valid.reduce((a,b)=>Math.abs(a-S.raw)<Math.abs(b-S.raw)?a:b);await show();if(color)await enableSemantics();};$('v43Actions').append(button);}
 const opacityButton=el('button',{},'查看真实opacity');opacityButton.onclick=()=>{$('opaquePoints').checked=false;$('cloudColor').value='opacity';draw3D();};$('v43Actions').append(opacityButton);
 $('v43FocusStatus').textContent='选择下方按钮切换实验，再通过时间轴逐帧核对影像与几何。';
 if($('v43FirstContact'))$('v43FirstContact').hidden=!D.context.startsWith('147053');
 if(!D.context.startsWith('147053'))$('v43FocusStatus').textContent='选择下方按钮切换实验，再通过时间轴逐帧核对影像与几何。';
}
function selectFromHash(){const params=new URLSearchParams(location.hash.replace(/^#workspace[?&]?/,''));if(params.has('group')&&allGroups[params.get('group')])setCategory(allGroups[params.get('group')].category,params.get('group'));if(params.has('raw')&&raws.includes(Number(params.get('raw'))))S.raw=Number(params.get('raw'));if(params.has('channel')&&[...$('channel').options].some(o=>o.value===params.get('channel'))){S.channel=params.get('channel');$('channel').value=S.channel;}}
async function init(){document.title=`场景 ${D.scene_number} · 场景诊断`;$('title').textContent=`场景 ${D.scene_number} · 场景诊断`;$('context').textContent='影像与三维几何共享帧号';Object.entries(categories).forEach(([k,v])=>{if(D.groups.some(g=>g.category===k))option($('category'),k,v);});$('frame').min=raws[0];$('frame').max=raws.at(-1);$('frame').step=1;setCategory('reconstruction','reconstruction_30000');createComparisons();trainTable();editingCompare();initV43Focus();$('exportInfo').textContent=`导出于 ${D.exported_utc}。${D.groups.length} 个可选实验/诊断条目；原 V42 只读导出与 V43 新实验分组记录。来源与文件哈希见总入口 export_manifest.json。`;
 $('category').onchange=()=>{setCategory($('category').value);show();};$('arm').onchange=()=>{S.group=$('arm').value;fillChannels();applyGroupView();show();};$('channel').onchange=()=>{S.channel=$('channel').value;show();};$('frame').oninput=()=>{S.raw=Number($('frame').value);show();};$('prev').onclick=()=>step(-1);$('next').onclick=()=>step(1);$('play').onclick=()=>{S.playing=!S.playing;$('play').textContent=S.playing?'暂停':'播放';if(S.playing)play();};async function play(){while(S.playing){step(1);await new Promise(r=>setTimeout(r,1000/Number($('fps').value)));}}
 $('renderCanvas').onclick=e=>pickPixel(e,$('renderCanvas'));$('compareTraining').onclick=trainingCompare;$('compareEditing').onclick=editingCompare;$('saveCase').onclick=persist;$('loadCase').onclick=()=>$('caseFile').click();$('caseFile').onchange=async()=>{try{const j=JSON.parse(await $('caseFile').files[0].text());if(j.context!==D.context)throw Error('诊断记录属于其他场景');if(!raws.includes(j.raw)||!allGroups[j.group])throw Error('帧或实验组无效');S.raw=j.raw;S.pixel=j.pixel.map((v,i)=>Math.max(0,Math.min(i?H-1:W-1,Number(v)|0)));S.channel=j.channel;$('caseNote').value=j.note||'';if(j.semantic_parameters){const v=j.semantic_parameters;for(const [key,id] of [['boundary_px','semanticBoundary'],['boundary_fraction','semanticBoundaryMass'],['geometry_ablation','semanticAblation'],['profile','semanticProfile'],['radius_px','semanticRadius'],['depth_m','semanticDepth'],['max_sigma_m','semanticSigma']])if(v[key]!==undefined)$(id).value=String(v[key]);if(v.static_vehicle_unknown!==undefined)$('semanticStaticUnknown').checked=v.static_vehicle_unknown;}/* j.semantic_parameters?.boundary_px restored before display */selectGroup(j.group);$('ownershipReview').value=j.ownership_review||'unreviewed';if(j.sampling){$('staticRate').value=j.sampling.static;$('dynamicRate').value=j.sampling.dynamic;$('targetRate').value=j.sampling.target;$('targetBoost').value=j.sampling.boost;await applySampling();}if(j.selected_gaussian){const q=j.selected_gaussian,c=S.clouds?.[q.cloud],i=c?.data.ids.indexOf(q.row);if(i>=0){S.selected={cloud:q.cloud,instance:q.instance,part:q.cloud==='static'?'static':'dynamic',j:i,p:q.position_m};draw3D();}}}catch(e){$('status').textContent='载入失败：'+e.message;}};
 ['static3d','dynamic3d','lidar3d','boxes3d','otherBoxes3d','opaquePoints','geometryState'].forEach(id=>$(id).onchange=()=>{S.selected=null;draw3D();});['overlayBoxes','overlayBody','overlayLidar'].forEach(id=>$(id).onchange=()=>{if(S.channel==='sensor_overlay')drawSensorOverlay();});$('sensorCheck').onclick=()=>{if(!IA)return;setCategory('reconstruction','reconstruction_30000');S.channel='sensor_overlay';$('channel').value=S.channel;show();};if(!IA){$('sensorCheck').hidden=true;$('overlayTools').hidden=true;$('otherBoxesLabel').hidden=true;}$('identityInfo').textContent=IA?'当前目标 track：'+D.target_track+'。仅该目标有独立动态资产；蓝框为其他原始车辆标注。静态分支可能包含车辆表达，语义候选与渲染分支分别显示。':'本场景只有所选目标的独立动态资产；静态分支不等于没有车辆的干净背景。';if(IA&&D.context.startsWith('147053')){$('identityLink').href='identity_audit/index.html';}else{$('identityLink').hidden=true;}$('pointSize').oninput=draw3D;$('fit3d').onclick=()=>{resetView3D();draw3D();};$('camera3d').onclick=()=>{S.cameraView=true;S.cameraReference='current';draw3D();};$('originalCamera3d').onclick=()=>{S.cameraView=true;S.cameraReference='original';draw3D();};const canvas=$('sceneCanvas');let drag=null;canvas.onpointerdown=e=>{drag={x:e.clientX,y:e.clientY,moved:0};canvas.setPointerCapture(e.pointerId);};canvas.onpointermove=e=>{if(!drag)return;const dx=e.clientX-drag.x,dy=e.clientY-drag.y;drag.moved+=Math.abs(dx)+Math.abs(dy);drag.x=e.clientX;drag.y=e.clientY;S.cameraView=false;if(e.shiftKey){S.orbit.panX+=dx;S.orbit.panY+=dy;}else{S.orbit.yaw+=dx*.008;S.orbit.pitch=Math.max(.05,Math.min(1.52,S.orbit.pitch+dy*.006));}draw3D();};canvas.onpointerup=e=>{if(drag&&drag.moved<4){const r=canvas.getBoundingClientRect(),x=(e.clientX-r.left)/r.width*canvas.width,y=(e.clientY-r.top)/r.height*canvas.height;const nearest=S.projection.reduce((best,p)=>{const d=(p.x-x)**2+(p.y-y)**2;return d<best.d?{d,p}:best;},{d:144,p:null});if(nearest.p){S.selected=nearest.p;draw3D();}}drag=null;};canvas.addEventListener('wheel',e=>{e.preventDefault();S.cameraView=false;S.orbit.distance=Math.max(6,Math.min(250,S.orbit.distance*Math.exp(e.deltaY*.001)));draw3D();},{passive:false});
 selectFromHash();window.addEventListener('hashchange',()=>{selectFromHash();show();});
 $('cloudColor').onchange=()=>enableSemantics();$('loadSemantic').onclick=()=>{$('cloudColor').value='semantic_branch';$('semanticProfile').value='gpu';enableSemantics();};['semanticProfile','semanticRadius','semanticDepth','semanticSigma','semanticBoundary','semanticBoundaryMass','semanticStaticUnknown','semanticAblation'].forEach(id=>$(id).onchange=enableSemantics);$('applySampling').onclick=applySampling;$('loadOwnership').onclick=loadOwnership;['owner1','owner0','ownerU','allPositive'].forEach(id=>$(id).onchange=draw3D);resetView3D();applyGroupView();show();try{const loaded={};for(const part of ['static','dynamic'])loaded[part]={...window.CLOUD_DATA[part],data:await unpack(window.CLOUD_DATA[part].data)};for(const [key,cloud] of Object.entries(window.FOREIGN_CLOUDS||{}))loaded[key]={...cloud,data:await unpack(cloud.data)};S.clouds=loaded;S.staticAdapters={};for(const [k,a] of Object.entries(window.V43_DELIVERY?.static_adapters||{}))S.staticAdapters[k]=await unpack(a);if(window.V43_DELIVERY?.target_unknown_evidence)S.targetUnknown=await unpack(window.V43_DELIVERY.target_unknown_evidence);draw3D();}catch(e){empty($('sceneCanvas'),e.message);}
}
window.SceneViewer={S,D,half,unpack,selectGroup,show,step,trainingCompare,editingCompare,projection,cloudPoint,currentBoxes,drawSensorOverlay,cameraProject,draw3D,resetView3D,editState,currentCamera,geometryInstances,editedPoint,applySampling,rowFraction,sampleBase,sampleBoost,loadOwnership,ownershipRow,ensureSemantic,semanticRow,enableSemantics};init();
