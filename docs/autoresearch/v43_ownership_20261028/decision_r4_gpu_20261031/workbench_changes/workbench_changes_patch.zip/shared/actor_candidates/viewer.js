(function(){
  const scenes=Array.isArray(window.ACTOR_CANDIDATES)?window.ACTOR_CANDIDATES:[];
  const el=id=>document.getElementById(id), scene=el('scene'),actor=el('actor');
  function option(select,value,label){const node=document.createElement('option');node.value=value;node.textContent=label;select.append(node);}
  function fact(label,value){const wrap=document.createElement('div'),dt=document.createElement('dt'),dd=document.createElement('dd');dt.textContent=label;dd.textContent=value;wrap.append(dt,dd);el('facts').append(wrap);}
  const display=x=>x==null?'暂无':String(x);
  function showActor(){const data=scenes[Number(scene.value)];if(!data)return;const row=data.actors[Number(actor.value)];if(!row)return;
    el('sceneTitle').textContent='Waymo · '+data.context_id;el('actorTitle').textContent='轨迹 ID：'+row.track_id;
    const has=!!row.preview_image;el('preview').hidden=!has;el('missingImage').hidden=has;if(has){el('preview').src=row.preview_image;el('frameInfo').textContent='原始帧 '+row.preview_frame+' · 方框为该轨迹的原始标注';}else{el('preview').removeAttribute('src');el('frameInfo').textContent='暂无对应预览帧';}
    el('facts').replaceChildren();fact('全片标注帧数',display(row.labelled_frames));fact('前向相机投影帧数',display(row.front_projected_frames));fact('前向标注框面积中位比例',row.median_front_bbox_area_ratio==null?'暂无':(100*row.median_front_bbox_area_ratio).toFixed(2)+'%');fact('框内激光点数中位值',display(row.median_front_lidar_annotation_count));fact('车身掩码',row.body_mask_frames==null?'暂无':row.body_mask_frames+' 帧');fact('已观察方位',row.front_view_sector_count==null?'暂无':row.front_view_sector_count+'/12 个粗扇区（代理）');fact('背景显露支持','待测');fact('当前模型范围',row.window_label||'暂无');const state={'existing_dynamic_target_ready_for_validation':'已有动态目标，可进一步核验','prepared_dynamic_asset_restore_validation_needed':'已有动态资产，需核验恢复','existing_static_gs_candidate_preparation_needed':'有场景模型，需准备该车辆候选','existing_gs_no_front_projection_in_current_window':'当前模型范围内无前向投影','hf_prepare_inputs':'需准备车身掩码、场景模型和逐车候选'};fact('车辆输入',state[row.editable_status]||'待核对');
  }
  function showScene(){actor.replaceChildren();const data=scenes[Number(scene.value)];if(!data)return;data.actors.forEach((r,i)=>option(actor,i,r.track_id));showActor();}
  scenes.forEach((d,i)=>option(scene,i,d.display_label||('Waymo · '+d.context_id)));scene.addEventListener('change',showScene);actor.addEventListener('change',showActor);showScene();
})();
