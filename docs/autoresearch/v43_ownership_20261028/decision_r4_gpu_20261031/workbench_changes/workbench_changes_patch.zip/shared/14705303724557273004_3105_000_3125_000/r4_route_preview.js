(function(){
 const select=document.getElementById('r4RouteEdit');
 function render(){const name=select.value;document.getElementById('r4Route0').src='r4_route_raw101/h000/'+name+'/9001101_final.png';document.getElementById('r4Route7').src='r4_route_raw101/h007/'+name+'/9001101_final.png';}
 select.addEventListener('change',render);render();
})();
