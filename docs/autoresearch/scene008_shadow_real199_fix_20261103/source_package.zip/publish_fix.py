"""Stage only the requested scientific review, leave unrelated repository work alone."""
from pathlib import Path
import shutil,json
ROOT=Path(__file__).resolve().parents[2]
STAGE=Path(__file__).resolve().parent/'publication'
OUT=ROOT/'outputs/shadow_a5_a37_199_20261103_fix'
NAME='scene008_shadow_real199_fix_20261103'
DEST=STAGE/NAME

def write(p,s):p.write_bytes(s.encode('utf-8'))
def main():
    DEST.mkdir(exist_ok=True)
    for pattern in ['*.html','*.json','*.png','*.jpg','*.svg','source_package.zip']:
        for p in OUT.glob(pattern):
            if p.name in ['full_extract_receipt.json','local_retrieval_receipt.json']:continue
            shutil.copy2(p,DEST/p.name)
    r4='shadow_a5_a37_199_20261103_r4';r2='shadow_a5_a37_199_20261103_r2';r3='shadow_a5_a37_199_20261103_r3'
    folders=[f'{r4}/evaluation',f'{r4}/source',f'{r4}/formal/step001000',f'{r2}/source',f'{r3}/source']
    files=[f'{r4}/formal/checkpoint001000.pt',f'{r4}/formal/contract.json',f'{r4}/formal/training.jsonl',f'{r4}/formal/receipt.json',
        f'{r4}/inputs/receipt.json',f'{r4}/result_summary.json',f'{r4}/delete5_before_after49.mp4',
        f'{r2}/legacy_a5_replay/replay_receipt.json',f'{r2}/formal_native/all49/metrics.json',f'{r3}/evaluation/all49/metrics.json']
    for rel in folders:shutil.copytree(OUT/'runs'/rel,DEST/'runs'/rel,dirs_exist_ok=True)
    for rel in files:
        target=DEST/'runs'/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(OUT/'runs'/rel,target)
    p=DEST/'result_report.html';s=p.read_text(encoding='utf-8').replace('<a href="scene008_shadow_fix_20261103.tar.gz">R2/R3/R4完整快照</a>','R2/R3/R4完整快照已另行保存在用户本地与远端（约478MiB）');write(p,s)
    write(DEST/'README.md','# scene-008 a5/a37 道路去影修正版\n\n![组件图](architecture.svg)\n\n[修正版结果、bug证据、49帧对比](result_report.html)。\n\n最终R4为1000更新，旧R1/R2/R3各1000失败更新单列，合计4000。完整199帧道路证据；只稳定恢复道路分支，保留原静态时间状态，不加阴影层。固定原生代理域的阴影MAE：a5 0.08083→0.00870，a37 0.07945→0.01069。中央车形彩色残影仍在，human_verdict=null。完整原始派生输入与失败现场保存在独立约478MiB快照。\n')
    s=json.loads((OUT/'result_summary.json').read_text())
    status='''# 当前研究状态

2026-11-03用户要求重新修复scene-008 v41 B30k的a5/a37道路去影实验，并授权重新开机、工程定位与重放。最终R4从原生B出发，完整199帧构建道路证据，仍删a5/a26/a18/a6/a37；只稳定道路恢复分支，保留原静态当前位置和时间显隐，没有全局时间冻结或独立阴影层。[修正版报告、组件图与49帧对比](autoresearch/scene008_shadow_real199_fix_20261103/result_report.html)。

已经坐实的迁移bug包括：“其他车辆”掩码在形态膨胀后重新覆盖待删五车（49帧136840个重叠像素样本，修正后0）；参考资格与原图保护耦合，恢复道路被优化成透明；R1遗漏残影opacity优化且有硬路由，单锚候选也未覆盖原生B各时刻贡献。最终使用全49帧真实光栅贡献选择的局部opacity门控，固定恢复道路覆盖与颜色；这些是编辑启发式，没有高斯归属真值或精确语义结论，各项独立收益未单独消融。

最终R4为1000步，固定原生有效阴影代理域按像素加权MAE：a5 0.080826→0.008703（18有效帧3712样本）；a37 0.079450→0.010695（49帧20813样本）。两处大块车底黑影在raw105已明显消退，中央车形彩色残影及部分道路边缘细节仍未解决，不能宣称删五车全部静态外观已消除。所有199帧均为BUILD输入，不主张独立测试泛化。

旧a5历史checkpoint零更新精确重放：MAE=0.006653157528489828，差值0；其915840行父模型不是本次2022726行原生B，不能混作同权重比较。原失败R1/R2/R3各1000步分别保留，最终R4另1000步，累计实际优化4000；无smoke、无恢复更新。用户明确取消本有界1k实验的smoke要求。

道路固定相机时间差为0，原静态仍有0.033073/0.040060时间变化；关闭修复旁路与当前B逐像素相同，原B权重未写回。最终checkpoint在新进程完整重载参数/Adam/RNG，三锚PNG逐字节一致，49帧视频解码通过。修复范围外sRGB平均MAE=0.001375，不是严格零变化。完整现场、权重、源代码、输入证据和结果已取回校验，远端原件保留；完成推送验证后按长期授权收尾GPU资源。human_verdict=null，quality_accepted=false，failure_ledger_refs=[V82-F01,V82-F06]，failure_ledger_delta=none。

2026-11-01用户停止的V43五例方向保持停止；本次为独立授权的有界道路修复，没有恢复其控制器或扩大研究范围。[原R1失败报告](autoresearch/scene008_shadow_real199_20261103/result_report.html)继续保留。
'''
    write(STAGE/'RESEARCH_STATUS.fix.md',status)
    index=(STAGE/'EXPERIMENTS.current.md').read_text(encoding='utf-8')
    row='| SCENE008_V41_B30K_A5_A37_SHADOW_REAL199_FIX_20261103 | 修正保护域与道路覆盖接线；旧a5零更新精确复现；原生B最终1k，a5/a37阴影代理MAE降89.2%/86.5%；失败3k单列、累计4k；保留中央车形残影限制 | [修正版证据、组件图与49帧对比](autoresearch/scene008_shadow_real199_fix_20261103/result_report.html) |'
    assert NAME not in index;write(STAGE/'EXPERIMENTS.fix.md',index.replace('|---|---|---|','|---|---|---|\n'+row,1))
    # Consistent LF on text only; binary artifacts untouched.
    for p in DEST.rglob('*'):
        if p.is_file() and p.suffix in ['.py','.md','.json','.jsonl','.html','.svg']:
            p.write_bytes(p.read_bytes().replace(b'\r\n',b'\n'))
    print('Publication:',DEST,sum(p.stat().st_size for p in DEST.rglob('*') if p.is_file()))

if __name__=='__main__':main()
