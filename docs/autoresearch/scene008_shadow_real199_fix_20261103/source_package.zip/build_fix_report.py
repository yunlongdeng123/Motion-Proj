"""Portable evidence report and correction ledger; never overwrite the R1 report."""
import hashlib,json,tarfile,shutil,zipfile,sys
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'outputs/shadow_a5_a37_199_20261103_fix'
STAGE=Path(__file__).resolve().parent
R4=OUT/'runs/shadow_a5_a37_199_20261103_r4'
R2=OUT/'runs/shadow_a5_a37_199_20261103_r2'
R3=OUT/'runs/shadow_a5_a37_199_20261103_r3'

def font(size):return ImageFont.truetype('C:/Windows/Fonts/msyh.ttc',size)
def write(path,text):path.write_bytes(text.encode('utf-8'))
def pairpanel():
    frames=R4/'evaluation/all49'
    sources=[('原 B · 删五车',frames/'105_baseline_delete5.png'),('上一版 R1 · 1k',ROOT/'outputs/shadow_a5_a37_199_20261103/run/final_evaluation/all49/105_repaired_delete5.png'),('修正版 R4 · 1k',frames/'105_repaired_delete5.png')]
    canvas=Image.new('RGB',(1440,368),'#142638');d=ImageDraw.Draw(canvas)
    for i,(title,p) in enumerate(sources):
        d.text((i*480+12,9),title,font=font(20),fill='white');canvas.paste(Image.open(p),(i*480,48))
    canvas.save(OUT/'raw105_comparison.png')
    im=Image.new('RGB',(1260,590),'#142638');d=ImageDraw.Draw(im)
    for row,(alias,box) in enumerate([('a5',(0,240,140,315)),('a37',(205,265,325,320))]):
        for col,(title,p) in enumerate(sources):
            image=Image.open(p).crop(box).resize(((box[2]-box[0])*3,(box[3]-box[1])*3),Image.Resampling.NEAREST)
            d.text((col*420+8,row*295+8),alias+' · '+title,font=font(18),fill='white');im.paste(image,(col*420,row*295+50))
    im.save(OUT/'target_crops.png')

def architecture():
    svg='''<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="380" viewBox="0 0 1080 380"><defs><marker id="arrow" markerWidth="10" markerHeight="10" refX="8" refY="3" orient="auto"><path d="M0 0L8 3L0 6" fill="#4c6480"/></marker></defs><rect width="1080" height="380" fill="#f0f5fa"/><g fill="white" stroke="#6c88a0" stroke-width="2"><rect x="25" y="30" width="215" height="100" rx="12"/><rect x="300" y="30" width="260" height="100" rx="12"/><rect x="25" y="220" width="215" height="110" rx="12"/><rect x="300" y="220" width="260" height="110" rx="12"/><rect x="650" y="115" width="180" height="140" rx="12"/><rect x="890" y="115" width="165" height="140" rx="12"/></g><g fill="none" stroke="#4c6480" stroke-width="2" marker-end="url(#arrow)"><path d="M240 80H300"/><path d="M240 275H300"/><path d="M560 80H600V155H650"/><path d="M560 275H600V215H650"/><path d="M830 185H890"/></g><g font-family="Microsoft YaHei,sans-serif" font-size="18" text-anchor="middle" fill="#203c54"><text x="132" y="66">原 v41 B30k</text><text x="132" y="95" font-size="15">实际时刻 S(t) · 权重只读</text><text x="430" y="63">局部 opacity 门控</text><text x="430" y="90" font-size="15">保留原位置、时间显隐</text><text x="430" y="114" font-size="14">49帧真实贡献选择 · 1k优化</text><text x="132" y="252">完整199帧 RGB + LiDAR</text><text x="132" y="280" font-size="15">实测颜色 / 弱证据分别记录</text><text x="132" y="305" font-size="15">插值域明确标记</text><text x="430" y="252">稳定道路修复分支</text><text x="430" y="280" font-size="15">固定道路几何、颜色、覆盖</text><text x="430" y="305" font-size="15">只有此分支没有时间自由度</text><text x="740" y="155">原生高斯光栅</text><text x="740" y="187" font-size="15">统一深度排序</text><text x="740" y="215" font-size="15">+ 原 EnvMap</text><text x="972" y="160">删同样五车</text><text x="972" y="192" font-size="15">恢复 a5 / a37 道路</text><text x="972" y="220" font-size="15">无独立阴影层</text></g></svg>'''
    write(OUT/'architecture.svg',svg)

def aggregate(path):
    rows=json.loads(path.read_text())['rows'];out={}
    for alias in ['5','37']:
        a=[x['actors'][alias] for x in rows if x['actors'][alias]['shadow_MAE'] is not None]
        out[alias]=sum(x['shadow_MAE']*x['shadow_samples'] for x in a)/sum(x['shadow_samples'] for x in a)
    return out

def main():
    archive=OUT/'scene008_shadow_fix_20261103.tar.gz'
    preview='--preview' in sys.argv
    digest=None
    if not preview:
        digest=hashlib.sha256(archive.read_bytes()).hexdigest();assert digest=='8dc9be0b971a461c1f6821bc788306079dcf03e802556d95512261d6ed2e3b00'
    runs=OUT/'runs';runs.mkdir(exist_ok=True)
    if not preview and not (OUT/'full_extract_receipt.json').exists():
        with tarfile.open(archive) as t:
            members=t.getmembers()
            assert all((runs/m.name).resolve().is_relative_to(runs.resolve()) for m in members)
            external=[dict(path=m.name,target=m.linkname) for m in members if m.issym() or m.islnk()]
            t.extractall(runs,members=[m for m in members if not m.issym() and not m.islnk()],filter='data')
        write(OUT/'full_extract_receipt.json',json.dumps(dict(all_regular_files_extracted=True,sha256=digest,
            unmaterialized_original_input_sidecar_links=external),indent=2))
    s=json.loads((R4/'result_summary.json').read_text());m=json.loads((R4/'evaluation/all49/metrics.json').read_text())
    assert len(m['rows'])==49;pairpanel();architecture()
    experiments=[('原 B',{'5':s['actors']['5']['shadow_MAE']['before'],'37':s['actors']['37']['shadow_MAE']['before']}),
        ('R1：错误迁移',{'5':.04846986,'37':.06098653}),('R2：原生选择迁移',aggregate(R2/'formal_native/all49/metrics.json')),
        ('R3：修复覆盖，保护掩码仍有冲突',aggregate(R3/'evaluation/all49/metrics.json')),('R4：最终修正',aggregate(R4/'evaluation/all49/metrics.json'))]
    table=''.join(f'<tr><td>{name}</td><td>{v["5"]:.5f}</td><td>{v["37"]:.5f}</td></tr>' for name,v in experiments)
    stats=''
    for alias in ['5','37']:
        a=s['actors'][alias];x=a['shadow_MAE'];road=a['road_MAE']
        stats+=f'<tr><td>a{alias}</td><td>{x["before"]:.5f} → <b>{x["after"]:.5f}</b></td><td>{x["reduction"]:.1%}</td><td>{x["frames"]}/49帧 · {x["samples"]:,}样本</td><td>{road["before"]:.5f} → {road["after"]:.5f}</td></tr>'
    page='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>scene-008 a5/a37 · 去影修正版与bug证据</title><style>
    body{margin:0;background:#edf2f7;color:#203548;font:16px/1.7 "Microsoft YaHei",sans-serif}main{max-width:1180px;margin:auto;padding:24px}section{background:white;padding:22px;border-radius:12px;margin:18px 0}h1{font-size:28px}h2{font-size:21px}img,video{max-width:100%}.notice{background:#dfefe9;border-left:5px solid #43886b;padding:15px}.small{font-size:14px;color:#536c82}table{width:100%;border-collapse:collapse}th,td{text-align:left;padding:9px;border-bottom:1px solid #dce4eb}.grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}.controls{display:flex;gap:10px;align-items:center;flex-wrap:wrap}button{padding:7px 14px;border-radius:6px;border:1px solid #a9bdce;cursor:pointer}input{width:100%}a{color:#1768a8}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f0f4f8;padding:12px}figure{margin:0}@media(max-width:700px){.grid{grid-template-columns:1fr}main{padding:10px}section{padding:14px}table{font-size:13px}}</style>
    <main><h1>scene-008 · a5 / a37 去影修正版</h1><p>2026-11-03 · 远端原生 v41 B30k · 完整199帧道路证据 · 删除 a5/a26/a18/a6/a37</p>
    <p class="notice"><b>上一版确实存在工程错误。</b>修正后，raw105 的 a5/a37 大块车底黑影明显消退。沿用上一版固定有效参考域，阴影代理 MAE 分别降至 <b>0.00870 / 0.01069</b>。旧 a5 历史结果也已零更新精确重放。道路仍有少量纹理和边缘残留，中央车形彩色残影尚在；不能宣称删五车的全部静态外观都已清除。</p>
    <section><h2>直接看 raw105</h2><img src="raw105_comparison.png" alt="原B、上一版和修正版对比"><img src="target_crops.png" alt="a5和a37车底局部放大"><p class="small">同一相机、时刻、删车集合。上一版 R1 保留原结果，没有覆盖。a5 左侧大块暗影和 a37 近处车底暗块是本次重点；中央车形残影属于仍存在的问题。</p></section>
    <section><h2>已经坐实的bug</h2><p><b>其他车辆保护域重新覆盖了待删车辆。</b>旧定义先用 all_vehicles &amp; labels==0 扣掉待删五车，再对身体/边缘掩码做形态膨胀；本实验又把它直接当作“其他车辆”保护域。最终49帧中，与待删五车标签重叠达 <b>136,840 个像素样本</b>。raw105 的 (40,280) 明明标签为 a5，却被要求维持原 B 的黑色外观。修正后重叠为0，并为选中车的边缘留出缓冲。该缓冲仍是编辑启发式，不是精确语义真值。</p>
    <p><b>恢复道路和保持原图的损失相互冲突。</b>把参考资格不足、保护掩码中的小孔都当作范围外，会迫使恢复道路透明化。R3 在 raw105 的 (60,275) 道路独立alpha被优化到约0.00494；在参考道路应覆盖的地方，实际上又露回了旧残影。最终版将“允许修复的连贯道路范围”与“哪些像素有可信颜色监督”分开，并固定恢复道路的颜色及覆盖，使其不能通过消失来满足错误锚定。</p>
    <p><b>旧路径迁移还有遗漏。</b>R1 只学习新增道路，没有接入旧方法的残影 opacity 优化，还使用硬输出路由；R2 又只在单个锚帧选高斯，覆盖不了原生 B 各时刻的贡献者。最终版从原生49帧的真实光栅 alpha·T 选出480,282行局部门控，只乘原模型当前时刻的opacity，不强制原静态高斯跨时刻显现。<a href="runs/shadow_a5_a37_199_20261103_r4/inputs/receipt.json">掩码与选择原始收据</a> · <a href="r3_checkpoint_pixel_audit.json">R3零更新像素检查</a></p>
    <p class="small">以上属于本次迁移和实验接线错误。各项修正的独立收益没有单独做消融；这些门控不是“车辆/道路归属真值”，不能拿来证明归属分类问题已经解决。边缘膨胀后不相交、目标道路覆盖不消失，是后续入口必须核验的具体条件。</p></section>
    <section><h2>固定口径的结果</h2><table><tr><th>对象</th><th>阴影 MAE · B → R4</th><th>下降</th><th>有效分母</th><th>道路 MAE · B → R4</th></tr>STATS</table><p>线性RGB、按像素样本加权，使用与R1相同的强参考及阴影代理掩码。a5有18个有效阴影帧，a37有49帧，空参考不计为0；全部有效帧均改善。a5道路域25帧，其余无有效分母。所有199帧均为BUILD输入，49个梯度相机属于这些输入，不是独立测试集。</p>
    <table><tr><th>版本</th><th>a5 阴影 MAE</th><th>a37 阴影 MAE</th></tr>TABLE</table><p class="small">此表各版使用同一原生 B、同一固定代理指标。历史旧 a5 的0.00665316来自更早的915,840行静态模型，原生 B有2,022,726行，不能将两者当成同权重同口径实验。原生 raw105 的 a5阴影MAE为0.07821 → 0.00597，a37为0.07060 → 0.01167。</p>
    <p>按帧等权而非像素加权，最终阴影 MAE 为 a5 0.01580、a37 0.02010。a5最差raw113为0.03382但只有1个有效像素；a37最差raw91为0.03068、61像素。查看完整分母比只报汇总更重要。<a href="r4_metrics.json">全部逐帧原值</a> · <a href="result_summary.json">完整执行与汇总</a></p></section>
    <section><h2>完整49帧同步检查</h2><div class="controls"><button id="prev">←</button><button id="play">播放</button><button id="next">→</button><button data-raw="91">raw91</button><button data-raw="105">关注 raw105</button><button data-raw="113">raw113</button><b id="frame-label"></b></div><input id="timeline" type="range" min="0" max="48" value="16"><div class="grid"><figure><figcaption>原 B · 删五车</figcaption><img id="before" alt="原B删五车"></figure><figure><figcaption>修正后 R4 · 删五车</figcaption><img id="after" alt="修正版删五车"></figure></div><p id="frame-metric" class="small"></p><video controls preload="metadata" src="runs/shadow_a5_a37_199_20261103_r4/delete5_before_after49.mp4"></video><details><summary>49帧总览</summary><img src="all49_contact.jpg" alt="完整49帧修复后总览"></details></section>
    <section><h2>199帧证据与时间约束</h2><img src="architecture.svg" alt="原B当前时间及稳定道路恢复组件图"><p>两车道路证据都检索了 raw0–198 共199帧。最终26,489个恢复格点中，21,068格有至少3个颜色一致的真实观测（含原强资格18,773格、短跨度2,295格）；另5,421格使用8邻域空间插值，最近实测点≤1.2m且局部线性RGB范围&lt;0.10。插值格明确标记，未用于实测真值指标。8,648个几何范围内格点仍未获得恢复资格，没有假称全路面已观测。原生B相机与时间支持仍为raw89–137的49帧。</p>
    <p><b>只稳定道路恢复分支。</b>固定 raw105 相机，切到raw89/105/137时间，道路自身RGB最大差均为0；原静态RGB相对首时刻仍变化0.033073 / 0.040060。原模型的位置、时间显隐沿用实际时刻，四份原始权重不写回；关闭插件逐像素复原B（最大差0）。无独立阴影层，无图像硬路由。</p>
    <p>修复范围外相对当前 B 的sRGB平均MAE为0.001375，最差帧均值0.001637；修正后“其他车辆”域平均MAE为0.001469。由于高斯支撑跨边界，这里不是严格零变化。<a href="runs/shadow_a5_a37_199_20261103_r4/evaluation/invariants.json">时间/旁路核验</a> · <a href="runs/shadow_a5_a37_199_20261103_r4/formal/contract.json">最终执行合同</a></p></section>
    <section><h2>复现与计算记账</h2><p>旧a5的原始checkpoint与addon零更新重放：期望和实际 MAE 均为 <b>0.006653157528489828</b>，差值0；其权重不是v41 B。<a href="runs/shadow_a5_a37_199_20261103_r2/legacy_a5_replay/replay_receipt.json">精确复现原值</a>。</p><p>最终R4正式优化1,000步，约129.1秒。按用户要求无smoke；旧结果重放、诊断与恢复验收均0更新。此前R1/R2/R3各1,000步均保留，合计实际优化4,000步，不能把工程试错隐去或称为只计算一次。最终只训练原静态opacity门控；原B只读，道路几何/颜色/opacity固定。</p>
    <p>保存的Adam步数为1,000；新进程恢复修复参数、优化器与全部随机状态后，raw101/105/113 PNG逐字节一致，49帧视频完整解码。训练CUDA分配峰值4.06GiB、保留11.53GiB，整个监测窗口NVML峰值19.77GiB（含进程交接期间的重叠）。人工 verdict 保持空，quality_accepted=false，供用户验收。</p>
    <p><a href="runs/shadow_a5_a37_199_20261103_r4/formal/checkpoint001000.pt">最终addon checkpoint</a> · <a href="runs/shadow_a5_a37_199_20261103_r4/formal/training.jsonl">逐步日志</a> · <a href="runs/shadow_a5_a37_199_20261103_r4/evaluation/restore.json">完整恢复收据</a> · <a href="source_package.zip">全部入口源码</a> · <a href="scene008_shadow_fix_20261103.tar.gz">R2/R3/R4完整快照</a></p>
    <p>快照已在本地与远端保留，包含真实199帧派生数组、49帧资格图、各次checkpoint、结果和失败现场。仍依赖原始B四份权重、旧历史模型（仅历史重放）、V3坐标bundle及原场景输入。R1完整快照已单独取回。本报告独立存放，不覆盖旧诊断平台或badcase表。</p><pre>远端最终目录：/root/autodl-tmp/drivingeditor_repro/campaign/shadow_a5_a37_199_20261103_r4
    完整快照 SHA256：8dc9be0b971a461c1f6821bc788306079dcf03e802556d95512261d6ed2e3b00</pre><p class="small">failure_ledger_refs=[V82-F01,V82-F06]；failure_ledger_delta=none。此次结果说明修复覆盖、保护域接线、跨时刻贡献覆盖会直接决定去影结果，没有证明仅靠身份重标注即可解决。</p></section></main>
    <script id="frame-data" type="application/json">FRAME_DATA</script><script>
    const rows=JSON.parse(document.getElementById('frame-data').textContent),$=id=>document.getElementById(id);let i=16,timer=null;
    const fmt=x=>x===null?'无有效参考':x.toFixed(5);
    function stop(){if(timer)clearInterval(timer);timer=null;$('play').textContent='播放'}
    function draw(){const r=rows[i],raw=String(r.raw).padStart(3,'0'),p='runs/shadow_a5_a37_199_20261103_r4/evaluation/all49/';$('timeline').value=i;$('frame-label').textContent=`raw${r.raw} · ${i+1}/49`;$('before').src=p+`${raw}_baseline_delete5.png`;$('after').src=p+`${raw}_repaired_delete5.png`;$('frame-metric').textContent=['5','37'].map(a=>`a${a} 阴影MAE ${fmt(r.actors[a].baseline_shadow_MAE)} → ${fmt(r.actors[a].shadow_MAE)}；${r.actors[a].shadow_samples}样本`).join(' | ')}
    $('prev').onclick=()=>{stop();i=Math.max(0,i-1);draw()};$('next').onclick=()=>{stop();i=Math.min(48,i+1);draw()};$('timeline').oninput=e=>{stop();i=+e.target.value;draw()};document.querySelectorAll('[data-raw]').forEach(b=>b.onclick=()=>{stop();i=+b.dataset.raw-89;draw()});$('play').onclick=()=>{if(timer){stop();return}if(i===48)i=0;$('play').textContent='暂停';draw();timer=setInterval(()=>{if(i===48){stop();return}i++;draw()},100)};draw();
    </script></html>'''
    page=page.replace('STATS',stats).replace('TABLE',table).replace('FRAME_DATA',json.dumps(m['rows'],ensure_ascii=False))
    write(OUT/'result_report.html',page)
    with zipfile.ZipFile(OUT/'source_package.zip','w',zipfile.ZIP_DEFLATED) as z:
        for root in [R2,R3,R4]:
            for p in (root/'source').glob('*.py'):z.write(p,root.name+'/source/'+p.name)
        z.write(Path(__file__),Path(__file__).name)
        for name in ['check_fix_review.mjs','audit_r3_checkpoint.py','publish_fix.py']:
            z.write(STAGE/name,name)
    receipt=dict(bundle_bytes=archive.stat().st_size,bundle_sha256=digest,remote_hash_matched=not preview,
        full_trial_directories_preserved=True,final_frame_pairs=49,checkpoint_present=(R4/'formal/checkpoint001000.pt').exists())
    if not preview:write(OUT/'local_retrieval_receipt.json',json.dumps(receipt,indent=2))
    print('Built',OUT/'result_report.html');print(json.dumps(experiments,ensure_ascii=False))

if __name__=='__main__':main()
