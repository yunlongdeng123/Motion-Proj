"""Zero-update remeasurement of the preserved failed R3 surface, no file overwrite."""
import sys,json
from pathlib import Path
sys.path.insert(0,'/root/autodl-tmp/drivingeditor_repro/campaign/shadow_a5_a37_199_20261103_r3/source')
import torch
from r3_runtime import Experiment,RUN,road_kwargs,raster

@torch.no_grad()
def main():
    e=Experiment();ck=torch.load(RUN/'formal/checkpoint001000.pt',map_location='cuda',weights_only=False);e.repair.load_state_dict(ck['repair'])
    c=e.camera(105);road=raster(c,e.n.args,0,road_kwargs(c,e.repair.road,e.n.args,precomputed_color=True),e.n.bg)
    out=e.render(105);v=e.view(105);rows=[]
    for x,y in [(20,275),(40,280),(60,275),(80,285),(90,255),(255,300)]:
        rows.append(dict(x=x,y=y,repair=bool(v['repair_mask'][y,x]),guard=bool(v['other_vehicle_guard'][y,x]),
            label=int(v['actor_labels'][y,x]),standalone_road_alpha=float(road['alpha'][0,y,x]),joint_road_alpha_T=float(out['extra'][0,y,x])))
    p=Path('/root/autodl-tmp/codex_tmp/r3_checkpoint_pixel_audit.json')
    p.write_text(json.dumps(dict(optimizer_updates=0,preserved_checkpoint=str(RUN/'formal/checkpoint001000.pt'),rows=rows),indent=2))
    print(p)

if __name__=='__main__':main()
