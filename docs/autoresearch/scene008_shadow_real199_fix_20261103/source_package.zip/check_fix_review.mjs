import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
const report=path.resolve('outputs/shadow_a5_a37_199_20261103_fix/result_report.html');
const html=fs.readFileSync(report,'utf8');
const data=html.match(/<script id="frame-data" type="application\/json">([\s\S]*?)<\/script>/)[1];
const source=html.match(/<\/script><script>([\s\S]*?)<\/script>/)[1];
const elements=Object.fromEntries(['frame-data','before','after','timeline','frame-label','frame-metric','prev','next','play'].map(id=>[id,{}]));
elements['frame-data'].textContent=data;
const buttons=[91,105,113].map(raw=>({dataset:{raw:String(raw)}}));
let tick=null;
const context={document:{getElementById:id=>elements[id],querySelectorAll:()=>buttons},
 setInterval:cb=>{tick=cb;return 1},clearInterval:()=>{tick=null}};
vm.runInNewContext(source,context);
function expectRaw(raw){
 for(const name of ['before','after']){
  if(!elements[name].src.includes(String(raw).padStart(3,'0')+'_'))throw Error('Wrong frame '+raw);
  if(!fs.existsSync(path.resolve(path.dirname(report),elements[name].src)))throw Error('Missing frame');
 }
}
expectRaw(105);elements.next.onclick();expectRaw(106);elements.prev.onclick();expectRaw(105);
elements.timeline.oninput({target:{value:'0'}});expectRaw(89);
buttons[2].onclick();expectRaw(113);elements.timeline.oninput({target:{value:'48'}});expectRaw(137);elements.play.onclick();expectRaw(89);tick();expectRaw(90);elements.play.onclick();
if(tick!==null)throw Error('Playback did not stop');
buttons[0].onclick();expectRaw(91);
console.log('Review logic passed: initial105, next/prev, timeline, worst-frame buttons, playback/end reset, and frame-file existence.');
